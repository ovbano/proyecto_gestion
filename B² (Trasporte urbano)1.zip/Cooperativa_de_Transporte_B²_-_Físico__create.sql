-- tables
-- Table: User

CREATE TABLE Usuario (
	ID_USUARIO varchar(10) NOT NULL,
	USUARIO VARCHAR(50) NOT NULL,
	CONTRASE�A varchar(20)
	CONSTRAINT pk_ID_USUARIO PRIMARY KEY (ID_USUARIO)
);

INSERT INTO Usuario VALUES('U-001','ovbano','1234')
INSERT INTO Usuario VALUES('U-002','msbeltran','1234')

-- Table: COLOR
CREATE TABLE COLOR (
    ID_color int  identity(1,1) NOT NULL,
    Color varchar(20)  NOT NULL,
    CONSTRAINT COLOR_pk PRIMARY KEY  (ID_color)
);

-- Table: CONDUCTOR
CREATE TABLE CONDUCTOR (
    ID_conductor varchar(7)  NOT NULL,
    ID_Licencia int  NOT NULL,
    ID_persona varchar(7)  NOT NULL,
    CONSTRAINT CONDUCTOR_pk PRIMARY KEY  (ID_conductor)
);

-- Table: DETALLE_MANTENIMIENTO
CREATE TABLE DETALLE_MANTENIMIENTO (
    ID_detalle int identity(1,1) NOT NULL,
    Costo_Total decimal(7,2)  NOT NULL,
    Detalle varchar(255)  NOT NULL,
    ID_vehiculo int  NOT NULL,
    ID_mantenimiento int  NOT NULL,
    CONSTRAINT DETALLE_MANTENIMIENTO_pk PRIMARY KEY  (ID_detalle)
);

-- Table: DIRECCION
CREATE TABLE DIRECCION (
    ID_direccion int identity(1,1) NOT NULL,
    Detalle varchar(255)  NOT NULL,
    CONSTRAINT DIRECCION_pk PRIMARY KEY  (ID_direccion)
);

-- Table: HORARIO
CREATE TABLE HORARIO (
    ID_horario int identity(1,1) NOT NULL,
    Hora_salida time  NOT NULL,
    Hora_llegada time  NOT NULL,
    ID_ruta int  NOT NULL,
    ID_vehiculo int  NOT NULL,
    CONSTRAINT HORARIO_pk PRIMARY KEY  (ID_horario)
);

-- Table: MANTENIMIENTO
CREATE TABLE MANTENIMIENTO (
    ID_mantenimiento int identity(1,1) NOT NULL,
    Tipo_mantenimiento varchar(100)  NULL,
    Descripcion varchar(255)  NULL,
    Costo_mantenimiento decimal(7,2)  NOT NULL,
    CONSTRAINT MANTENIMIENTO_pk PRIMARY KEY  (ID_mantenimiento)
);

-- Table: MARCA
CREATE TABLE MARCA (
    ID_marca int identity(1,1) NOT NULL,
    Marca varchar(30)  NOT NULL,
    Detalle varchar(255)  NULL,
    CONSTRAINT MARCA_pk PRIMARY KEY  (ID_marca)
);

-- Table: MATRICULA
CREATE TABLE MATRICULA (
    ID_matricula int identity(1,1) NOT NULL,
    Placa_vehicular varchar(10)  NOT NULL,
    Nombre_propietario varchar(50)  NOT NULL,
    Capacidad_pasajeros int  NOT NULL,
    ID_marca int  NOT NULL,
    ID_color int  NOT NULL,
    ID_modelo int  NOT NULL,
    CONSTRAINT MATRICULA_pk PRIMARY KEY  (ID_matricula)
);

-- Table: MODELO
CREATE TABLE MODELO (
    ID_modelo int identity(1,1) NOT NULL,
    Modelo varchar(30)  NOT NULL,
    Detalle varchar(255)  NULL,
    CONSTRAINT MODELO_pk PRIMARY KEY  (ID_modelo)
);

-- Table: PAGO
CREATE TABLE PAGO (
    ID_pago int identity(1,1) NOT NULL,
    Fecha_pago datetime DEFAULT GETDATE() NOT NULL,
    Metodo_pago varchar(50)  NOT NULL,
	Monto_Pagado decimal(7,2) NOT NULL,
    ID_Pasajero varchar(7)  NOT NULL,
    ID_ruta int  NOT NULL,
    CONSTRAINT PAGO_pk PRIMARY KEY  (ID_pago),
	CONSTRAINT METODO_PAGO_chek check(Metodo_pago = 'Tarjeta' or Metodo_pago = 'Efectivo')
);

-- Table: PASAJERO
CREATE TABLE PASAJERO (
    ID_Pasajero varchar(7)  NOT NULL,
    Tipo_Pasajero varchar(30)  NOT NULL,
    ID_tarifa int  NOT NULL,
    ID_persona varchar(7)  NOT NULL,
    CONSTRAINT PASAJERO_pk PRIMARY KEY  (ID_Pasajero),
	CONSTRAINT PASAJERO_check 
	check(Tipo_Pasajero = 'Estudiante' or Tipo_Pasajero = 'Normal' or Tipo_Pasajero = 'Discapacitado' or Tipo_Pasajero = 'Adulto mayor')
);

-- Table: PERSONA
CREATE TABLE PERSONA (
    ID_persona varchar(7)  NOT NULL,
    Cedula varchar(10)  NOT NULL,
    Nombre varchar(50)  NULL,
    Apellido varchar(50)  NULL,
    Edad int  NULL,
    Sexo varchar(3)  NOT NULL,
    Telefono varchar(10)  NOT NULL,
    Tipo_persona varchar(30)  NOT NULL,
    ID_direccion int  NOT NULL,
    CONSTRAINT PERSONA_pk PRIMARY KEY  (ID_persona),
	CONSTRAINT SEXO_check check(Sexo = 'H' or Sexo = 'M' or Sexo = 'P'),
	CONSTRAINT PERSONA_check check(Tipo_persona = 'Conductor' or Tipo_persona= 'Pasajero')
);

-- Table: RUTA
CREATE TABLE RUTA (
    ID_ruta int identity(1,1) NOT NULL,
    Nombre_ruta varchar(100)  NOT NULL,
    Monto_pagado decimal(7,2)  NOT NULL,
    Descripcion varchar(255)  NOT NULL,
    CONSTRAINT RUTA_pk PRIMARY KEY  (ID_ruta)
);

-- Table: TARIFA
CREATE TABLE TARIFA (
    ID_tarifa int identity(1,1) NOT NULL,
    Nombre_tarifa varchar(50)  NOT NULL,
    Monto decimal(7,2)  NOT NULL,
    Detalle varchar(255)  NULL,
    CONSTRAINT TARIFA_pk PRIMARY KEY  (ID_tarifa),
	CONSTRAINT NOM_TARIFA_check 
	check(Nombre_tarifa = 'Estudiante' or Nombre_tarifa = 'Normal' or Nombre_tarifa = 'Discapacitado' or Nombre_tarifa = 'Adulto mayor')
);

-- Table: TIPO_LICENCIA
CREATE TABLE TIPO_LICENCIA (
    ID_Licencia int identity(1,1) NOT NULL,
    Tipo_licencia varchar(3)  NOT NULL,
    Descripcion varchar(255)  NULL,
    CONSTRAINT TIPO_LICENCIA_pk PRIMARY KEY  (ID_Licencia),
	CONSTRAINT LICENCIA_TIPO_check 
	check(
		Tipo_licencia = 'A' 
		or Tipo_licencia = 'B' 
		or Tipo_licencia = 'C' 
		or Tipo_licencia = 'D' 
		or Tipo_licencia = 'E' 
		or Tipo_licencia = 'F')
);

-- Table: VEHICULO
CREATE TABLE VEHICULO (
    ID_vehiculo int identity(1,1) NOT NULL,
    Nombre_vehiculo varchar(50)  NOT NULL,
    ID_conductor varchar(7)  NOT NULL,
    ID_matricula int  NOT NULL,
    CONSTRAINT VEHICULO_pk PRIMARY KEY  (ID_vehiculo)
);

-- foreign keys
-- Reference: CONDUCTOR_PERSONA (table: CONDUCTOR)
ALTER TABLE CONDUCTOR ADD CONSTRAINT CONDUCTOR_PERSONA
    FOREIGN KEY (ID_persona)
    REFERENCES PERSONA (ID_persona);

-- Reference: CONDUCTOR_TIPO_LICENCIA (table: CONDUCTOR)
ALTER TABLE CONDUCTOR ADD CONSTRAINT CONDUCTOR_TIPO_LICENCIA
    FOREIGN KEY (ID_Licencia)
    REFERENCES TIPO_LICENCIA (ID_Licencia);

-- Reference: DETALLE_MANTENIMIENTO_MANTENIMIENTO (table: DETALLE_MANTENIMIENTO)
ALTER TABLE DETALLE_MANTENIMIENTO ADD CONSTRAINT DETALLE_MANTENIMIENTO_MANTENIMIENTO
    FOREIGN KEY (ID_mantenimiento)
    REFERENCES MANTENIMIENTO (ID_mantenimiento);

-- Reference: DETALLE_MANTENIMIENTO_VEHICULO (table: DETALLE_MANTENIMIENTO)
ALTER TABLE DETALLE_MANTENIMIENTO ADD CONSTRAINT DETALLE_MANTENIMIENTO_VEHICULO
    FOREIGN KEY (ID_vehiculo)
    REFERENCES VEHICULO (ID_vehiculo);

-- Reference: HORARIO_RUTA (table: HORARIO)
ALTER TABLE HORARIO ADD CONSTRAINT HORARIO_RUTA
    FOREIGN KEY (ID_ruta)
    REFERENCES RUTA (ID_ruta);

-- Reference: HORARIO_VEHICULO (table: HORARIO)
ALTER TABLE HORARIO ADD CONSTRAINT HORARIO_VEHICULO
    FOREIGN KEY (ID_vehiculo)
    REFERENCES VEHICULO (ID_vehiculo);

-- Reference: MATRICULA_COLOR (table: MATRICULA)
ALTER TABLE MATRICULA ADD CONSTRAINT MATRICULA_COLOR
    FOREIGN KEY (ID_color)
    REFERENCES COLOR (ID_color);

-- Reference: MATRICULA_MARCA (table: MATRICULA)
ALTER TABLE MATRICULA ADD CONSTRAINT MATRICULA_MARCA
    FOREIGN KEY (ID_marca)
    REFERENCES MARCA (ID_marca);

-- Reference: MATRICULA_MODELO (table: MATRICULA)
ALTER TABLE MATRICULA ADD CONSTRAINT MATRICULA_MODELO
    FOREIGN KEY (ID_modelo)
    REFERENCES MODELO (ID_modelo);

-- Reference: PAGO_PASAJERO (table: PAGO)
ALTER TABLE PAGO ADD CONSTRAINT PAGO_PASAJERO
    FOREIGN KEY (ID_Pasajero)
    REFERENCES PASAJERO (ID_Pasajero);

-- Reference: PAGO_RUTA (table: PAGO)
ALTER TABLE PAGO ADD CONSTRAINT PAGO_RUTA
    FOREIGN KEY (ID_ruta)
    REFERENCES RUTA (ID_ruta);

-- Reference: PASAJERO_PERSONA (table: PASAJERO)
ALTER TABLE PASAJERO ADD CONSTRAINT PASAJERO_PERSONA
    FOREIGN KEY (ID_persona)
    REFERENCES PERSONA (ID_persona);

-- Reference: PASAJERO_TARIFA (table: PASAJERO)
ALTER TABLE PASAJERO ADD CONSTRAINT PASAJERO_TARIFA
    FOREIGN KEY (ID_tarifa)
    REFERENCES TARIFA (ID_tarifa);

-- Reference: PERSONA_DIRECCION (table: PERSONA)
ALTER TABLE PERSONA ADD CONSTRAINT PERSONA_DIRECCION
    FOREIGN KEY (ID_direccion)
    REFERENCES DIRECCION (ID_direccion);

-- Reference: VEHICULO_CONDUCTOR (table: VEHICULO)
ALTER TABLE VEHICULO ADD CONSTRAINT VEHICULO_CONDUCTOR
    FOREIGN KEY (ID_conductor)
    REFERENCES CONDUCTOR (ID_conductor);

-- Reference: VEHICULO_MATRICULA (table: VEHICULO)
ALTER TABLE VEHICULO ADD CONSTRAINT VEHICULO_MATRICULA
    FOREIGN KEY (ID_matricula)
    REFERENCES MATRICULA (ID_matricula);

-- Inserci�n de datos...

-- Tabla: Color
INSERT INTO COLOR (Color) VALUES
('Rojo'),
('Azul'),
('Verde'),
('Amarillo'),
('Naranja'),
('Morado'),
('Cyan'),
('Marr�n'),
('Rosa'),
('Gris'),
('Negro'),
('Blanco'),
('Turquesa'),
('Ocre'),
('Violeta');

-- Tabla: Marca

INSERT INTO MARCA (Marca, Detalle) VALUES
('Mercedes-Benz', 'Marca alemana especializada en veh�culos comerciales, incluyendo autobuses.'),
('Volvo', 'Compa��a sueca conocida por fabricar una variedad de veh�culos, incluyendo autobuses.'),
('MAN', 'Fabricante alem�n de veh�culos comerciales, incluyendo autobuses y camiones.'),
('Scania', 'Marca sueca que produce camiones y autobuses de alta calidad.'),
('Irizar', 'Empresa espa�ola especializada en la fabricaci�n de carrocer�as para autobuses.'),
('Van Hool', 'Compa��a belga que fabrica autobuses y veh�culos de transporte p�blico.'),
('Neoplan', 'Marca alemana de autobuses y autocares, parte del grupo MAN.'),
('Marcopolo', 'Empresa brasile�a l�der en la producci�n de carrocer�as para autobuses.'),
('Setra', 'Fabricante alem�n de autobuses y autocares de lujo.'),
('BYD', 'Compa��a china que produce veh�culos el�ctricos, incluyendo autobuses.'),
('Solaris', 'Fabricante polaco de autobuses y veh�culos el�ctricos.'),
('Prevost', 'Marca canadiense especializada en la fabricaci�n de autocares de lujo.'),
('MCI', 'Empresa estadounidense de autobuses y autocares, parte del grupo New Flyer.'),
('Nova Bus', 'Fabricante canadiense de autobuses y veh�culos de tr�nsito.'),
('Temsa', 'Compa��a turca que produce una variedad de veh�culos, incluyendo autobuses.'),
('Ayats', 'Empresa espa�ola dedicada a la fabricaci�n de autocares y autobuses.'),
('Jonckheere', 'Marca belga de carrocer�as de autobuses y autocares.'),
('Jelcz', 'Fabricante polaco de veh�culos, incluyendo autobuses y camiones.'),
('CaetanoBus', 'Empresa portuguesa especializada en la producci�n de carrocer�as de autobuses.'),
('Wrightbus', 'Compa��a brit�nica conocida por fabricar carrocer�as de autobuses y autocares.');

-- Tabla: Modelo

INSERT INTO MODELO (Modelo, Detalle) VALUES
('Citaro', 'Modelo de autob�s urbano fabricado por Mercedes-Benz.'),
('Sprinter City', 'Modelo de minib�s producido por Mercedes-Benz.'),
('9900', 'Autocar de lujo fabricado por Setra, conocido por su dise�o elegante.'),
('Enviro500', 'Modelo de autob�s de dos pisos fabricado por Alexander Dennis.'),
('Travego', 'Modelo de autob�s de larga distancia producido por Mercedes-Benz.'),
('Crossway', 'Modelo de autocar vers�til fabricado por Iveco.'),
('TDX27', 'Autob�s de tr�nsito articulado fabricado por Van Hool.'),
('Urbino 12', 'Modelo de autob�s urbano fabricado por Solaris.'),
('Double-Decker', 'Modelo de autob�s de dos pisos, com�n en muchas marcas.'),
('Citymood', 'Modelo de autob�s de tr�nsito producido por Temsa.'),
('Trident', 'Modelo de autob�s de dos pisos fabricado por Alexander Dennis.'),
('Intouro', 'Modelo de autocar de turismo producido por Mercedes-Benz.'),
('Estrada', 'Autocar de la marca Ayats conocido por su dise�o moderno.'),
('Enviro200', 'Modelo de autob�s de un solo piso fabricado por Alexander Dennis.'),
('Mega Low Entry', 'Autob�s urbano con piso bajo producido por Van Hool.'),
('Citadis', 'Modelo de autob�s el�ctrico fabricado por CaetanoBus.'),
('Aerocity', 'Modelo de minib�s producido por Ashok Leyland.'),
('Nova LFS', 'Modelo de autob�s de un solo piso fabricado por Nova Bus.'),
('Urbanway', 'Autob�s urbano producido por Iveco Bus.'),
('Eclipse Gemini', 'Modelo de autob�s de dos pisos producido por Wrightbus.'),
('CrossTourismo', 'Modelo de autob�s de turismo producido por Neoplan.'),
('Transit', 'Modelo de minib�s de tr�nsito producido por Ford.'),
('Avenio', 'Modelo de autob�s el�ctrico producido por Siemens.'),
('Unvi Voyager', 'Modelo de autocar de turismo producido por Unvi.'),
('Citadelle', 'Modelo de autob�s tur�stico fabricado por Bova.'),
('Masterline', 'Autocar de lujo fabricado por Jonckheere.'),
('Sunlong SLK6129', 'Modelo de autocar de tr�nsito producido por Sunlong.'),
('Dolphin', 'Modelo de autob�s de dos pisos fabricado por Jelcz.'),
('Gran Viale', 'Autob�s de tr�nsito fabricado por Volvo Buses.'),
('Higer', 'Fabricante chino de autobuses y autocares.');

-- Tabla: Tipo_Licencia

INSERT INTO TIPO_LICENCIA (Tipo_licencia, Descripcion) VALUES
('A', 'Licencia para conducir motocicletas y triciclos motorizados.'),
('B', 'Licencia para conducir veh�culos de motor, excepto motocicletas.'),
('C', 'Licencia para conducir veh�culos pesados con remolque.'),
('D', 'Licencia para conducir veh�culos de transporte p�blico de pasajeros.'),
('E', 'Licencia para conducir veh�culos pesados con remolque de transporte p�blico.'),
('F', 'Licencia para conducir veh�culos especiales.');

-- Tabla: Tarifa

INSERT INTO TARIFA (Nombre_tarifa, Monto, Detalle) VALUES
('Estudiante', 0.40, 'Tarifa reducida para estudiantes.'),
('Normal', 0.75, 'Tarifa est�ndar para pasajeros adultos.'),
('Discapacitado', 0.40, 'Tarifa reducida para pasajeros con discapacidad.'),
('Adulto mayor', 0.40, 'Tarifa reducida para adultos mayores.');

-- Tabla: Matenimiento

INSERT INTO MANTENIMIENTO (Tipo_mantenimiento, Descripcion, Costo_mantenimiento) VALUES
('Preventivo', 'Mantenimiento planificado para prevenir fallas.', 10.00),
('Correctivo', 'Mantenimiento para corregir fallas o aver�as.', 30.00),
('Inspecci�n', 'Inspecci�n rutinaria para evaluar el estado general.', 5.00),
('Reparaci�n motor', 'Reparaci�n del motor del veh�culo.', 800.00),
('Cambio de aceite', 'Sustituci�n del aceite del motor y filtro.', 40.00),
('Alineaci�n', 'Ajuste de la alineaci�n de las ruedas del veh�culo.', 35.00),
('Frenos', 'Revisi�n y mantenimiento del sistema de frenos.', 50.00),
('Lubricaci�n', 'Aplicaci�n de lubricantes a componentes clave.', 12.50),
('filtro de aire', 'Sustituci�n del filtro de aire del veh�culo.', 100.00),
('Mantenimiento el�ctrico', 'Revisi�n y reparaci�n de componentes el�ctricos.', 180.00);

-- Tabla: Direccion

INSERT INTO DIRECCION (Detalle) VALUES
('Calle Amapola, Colonia Primavera'),
('Avenida Roble, Barrio San Jos�'),
('Carrera Tulip�n, Urbanizaci�n Los Pinos'),
('Pasaje Girasol, Residencial El Carmen'),
('Calle Magnolia, Sector Las Acacias'),
('Avenida del Sol, Barrio Centro'),
('Calle Azalea, Urbanizaci�n La Floresta'),
('Carrera Orqu�dea, Residencial Los Alamos'),
('Km 5, Sector El Bosque'),
('Calle Violeta, Colonia La Aurora'),
('Avenida Primavera, Residencial Los Olivos'),
('Calle Jazm�n, Barrio San Marcos'),
('Carrera Girasol, Urbanizaci�n Las Rosas'),
('Pasaje Lirio, Sector El Prado'),
('Calle Peonia, Colonia San Francisco'),
('Avenida de las Flores, Barrio El Para�so'),
('Calle Almendro, Urbanizaci�n Los Alamos'),
('Barrio Alulema, Avenida Principal, Sector La Esperanza'),
('Pasaje Tulip�, Barrio San Juan'),
('Avenida del Bosque, Residencial La Quinta'),
('Calle Pedro Aguilar, Avenida Libertador, Barrio Los Pinos'),
('Avenida del R�o, Urbanizaci�n Las Palmas'),
('Pasaje Violeta, Barrio La Victoria'),
('Carrera Neva Luz, Avenida Bol�var, Residencial El Carmen'),
('Calle 15, Barrio Los Olivos'),
('Avenida Bol�var, Barrio La Victoria'),
('Sector Norte, Barrio San Mart�n'),
('Sector Este, Urbanizaci�n Los Alamos'),
('Sector Oeste, Residencial Las Acacias'),
('Sector Central, Barrio El Carmen'),
('Sector Sur, Residencial La Quinta'),
('Sector Noroeste, Barrio San Marcos'),
('Sector Suroeste, Urbanizaci�n Las Rosas'),
('Barrio Eloy Alfaro, Sector Este'),
('Barrio Las Palmas, Sector Oeste'),
('Barrio San Isidro, Sector Norte'),
('Barrio El Bosque, Sector Sur'),
('Barrio La Floresta, Sector Noroeste'),
('Barrio La Victoria, Sector Suroeste'),
('Barrio El Carmen, Sector Sureste'),
('Barrio Los Alamos, Sector Noreste'),
('Barrio La Aurora, Sector Centro'),
('Barrio Los Olivos, Sector Norte'),
('Barrio San Francisco, Sector Oeste'),
('Barrio Los Pinos, Sector Este'),
('Barrio El Prado, Sector Sur'),
('Barrio San Jos�, Sector Noroeste'),
('Barrio San Marcos, Sector Suroeste'),
('Barrio Primavera, Sector Sureste'),
('Barrio El Para�so, Sector Noreste'),
('Barrio Los Cerezos, Sector Centro'),
('Barrio Santa Rosa, Sector Norte'),
('Barrio El Milagro, Sector Oeste');

-- Tabla: Ruta

INSERT INTO RUTA (Nombre_ruta, Monto_pagado, Descripcion) VALUES
('Ruta del Sol', 0.20, 'Recorrido principal por la ciudad.'),
('Km 23', 0.65, 'Recorrido hacia la periferia de la ciudad.'),
('El Esfuerzo', 0.50, 'Recorrido por zonas industriales y residenciales.'),
('La Primavera', 0.40, 'Recorrido por zonas con �reas verdes.'),
('El Mirador', 0.75, 'Recorrido con vistas panor�micas.'),
('La Tranquilidad', 0.55, 'Recorrido por zonas residenciales tranquilas.'),
('La Moderna', 0.45, 'Recorrido por �reas con arquitectura moderna.'),
('El Progreso', 0.30, 'Recorrido hacia zonas en desarrollo.'),
('La Colina', 0.60, 'Recorrido por zonas elevadas con vistas.'),
('El Descanso', 0.70, 'Recorrido hacia �reas recreativas y de ocio.'),
('Ruta del Bosque', 0.35, 'Recorrido por �reas boscosas y parques.'),
('Camino del Arco Iris', 0.80, 'Recorrido con nombres de colores a lo largo del trayecto.'),
('Avenida de las Estrellas', 0.25, 'Recorrido nocturno con iluminaci�n destacada.'),
('Ruta del Arte', 0.90, 'Recorrido por zonas con galer�as de arte y murales.'),
('Sendero del Silencio', 0.55, 'Recorrido por zonas tranquilas sin mucho tr�fico.'),
('V�a de la Historia', 0.65, 'Recorrido por zonas hist�ricas y monumentos.'),
('Circuito del Deporte', 0.70, 'Recorrido cerca de instalaciones deportivas.'),
('Avenida de las Mariposas', 0.45, 'Recorrido por �reas con jardines de mariposas.'),
('Ruta del Comercio', 0.60, 'Recorrido por zonas comerciales y mercados.'),
('Paseo del Atardecer', 0.75, 'Recorrido con vistas pintorescas del atardecer.'),
('Circuito del Coral', 0.40, 'Recorrido por zonas cercanas al mar con ambiente costero.'),
('Ruta de la Luna', 1.00, 'Recorrido nocturno con iluminaci�n lunar especial.'),
('Sendero del Valle', 0.30, 'Recorrido por valles y paisajes naturales.'),
('Paseo del Cielo', 0.85, 'Recorrido elevado con vistas panor�micas al cielo.'),
('V�a del Flamenco', 0.50, 'Recorrido por zonas con presencia de flamencos.'),
('Camino del Desierto', 0.95, 'Recorrido a trav�s de �reas des�rticas y arenosas.'),
('Ruta del Tango', 0.65, 'Recorrido por zonas culturales con m�sica de tango.'),
('Avenida de los Sue�os', 0.75, 'Recorrido por �reas con nombres de sue�os y fantas�a.'),
('Ruta del Futuro', 0.55, 'Recorrido por zonas modernas y futuristas.'),
('Callej�n de los Recuerdos', 0.45, 'Recorrido nost�lgico por zonas hist�ricas.'),
('V�a de la Diversidad', 0.60, 'Recorrido por zonas diversas y ecl�cticas.'),
('Ruta del Caf�', 0.70, 'Recorrido por zonas cafetaleras y aroma a caf�.'),
('Paseo del Eco', 0.25, 'Recorrido ecol�gico por �reas verdes y sostenibles.'),
('Avenida del Misterio', 0.80, 'Recorrido por zonas con nombres misteriosos.'),
('Circuito del Amanecer', 0.35, 'Recorrido temprano con vistas al amanecer.'),
('Ruta del Viento', 0.90, 'Recorrido por zonas ventosas y con corrientes de aire.'),
('Sendero del Arco Iris', 0.58, 'Recorrido por zonas con colores vibrantes como el arco iris.'),
('V�a de la Imaginaci�n', 0.73, 'Recorrido inspirado en nombres imaginativos.'),
('Ruta del Coralillo', 0.43, 'Recorrido por zonas con nombres de flores y plantas.'),
('Paseo del Jazz', 0.67, 'Recorrido por zonas culturales con influencia del jazz.');

-- Tabla: Persona

INSERT INTO PERSONA (ID_persona, Cedula, Nombre, Apellido, Edad, Sexo, Telefono, Tipo_persona, ID_direccion) VALUES
('P-0001', '1723456789', 'Juan', 'P�rez', 28, 'H', '0998765432', 'Conductor', 1), -- Conductor
('P-0002', '2300166101', 'Ana', 'G�mez', 35, 'M', '0987654321', 'Pasajero', 2), -- Normal
('P-0003', '1712345678', 'Carlos', 'Ram�rez', 42, 'H', '0976543210', 'Pasajero', 44), -- Normal
('P-0004', '1201234567', 'Elena', 'Herrera', 29, 'M', '0965432109', 'Pasajero', 4), -- Normal
('P-0005', '0923456789', 'Luis', 'Mart�nez', 33, 'H', '0954321098', 'Conductor', 43), -- Conductor
('P-0006', '1312345678', 'Mar�a', 'Cruz', 38, 'M', '0943210987', 'Pasajero', 1), -- Normal
('P-0007', '2300987654', 'Javier', 'L�pez', 27, 'H', '0932109876', 'Pasajero', 7), -- Estudiante
('P-0008', '0921098765', 'Laura', 'D�az', 31, 'M', '0921098765', 'Pasajero', 8), -- Estudiante
('P-0009', '1209876543', 'Pedro', 'Alvarez', 71, 'H', '0910987654', 'Pasajero', 9), -- Adulto mayor
('P-0010', '1712345671', 'Silvia', 'S�nchez', 26, 'M', '0909876543', 'Pasajero', 11), -- Estudiante
('P-0011', '1310123456', 'Gabriel', 'Garc�a', 71, 'H', '0998305432', 'Pasajero', 11), -- Adulto mayor
('P-0012', '2201234567', 'Ver�nica', 'Lara', 34, 'M', '0987231121', 'Pasajero', 23), -- Discapacitado
('P-0013', '1312345671', 'Fernando', 'Ochoa', 41, 'H', '0971543210', 'Pasajero', 3), -- Normal
('P-0014', '1212109876', 'Daniela', 'Mendoza', 67, 'M', '0965632109', 'Pasajero', 50), -- Adulto mayor
('P-0015', '0923142310', 'Ra�l', 'Guzm�n', 32, 'H', '0954301098', 'Conductor', 40), --Conductor
('P-0016', '2300987651', 'Isabel', 'Hern�ndez', 37, 'M', '0943510987', 'Pasajero', 18), -- Normal
('P-0017', '0921098761', 'Mart�n', 'Su�rez', 26, 'H', '0932109326', 'Pasajero', 17), -- Estudiante
('P-0018', '1312345673', 'Renata', 'Moreno', 30, 'M', '0921098771', 'Pasajero', 14), -- Discapacitado 
('P-0019', '1209871543', 'H�ctor', 'Casta�eda', 39, 'H', '0910187654', 'Conductor', 7), -- Conductor
('P-0020', '2201098765', 'Camila', 'G�ngora', 25, 'M', '0909876143', 'Pasajero', 37), -- Estudiante
('P-0021', '1310178456', 'Luisa', 'Fern�ndez', 25, 'M', '0998764732', 'Pasajero', 21), -- Normal
('P-0022', '2202134567', 'Rodrigo', 'Guzm�n', 40, 'H', '0887654321', 'Pasajero', 15), -- Normal
('P-0023', '1752345671', 'Eva', 'L�pez', 22, 'M', '0976547210', 'Pasajero', 9), -- Estudiante
('P-0024', '1212109124', 'Francisco', 'Herrera', 66, 'H', '0900432109', 'Pasajero', 12), -- Adulto mayor
('P-0025', '0927856789', 'Paula', 'Mart�nez', 28, 'M', '0954320098', 'Pasajero', 40), -- Normal
('P-0026', '2300167651', 'Roberto', 'Ram�rez', 37, 'H', '0943210981', 'Pasajero', 5), -- Normal
('P-0027', '0921098461', 'Sof�a', 'D�az', 19, 'M', '0932109846', 'Pasajero', 8), -- Estudiante
('P-0028', '1312345612', 'Jorge', 'Moreno', 33, 'H', '0921030771', 'Pasajero', 9), -- Discapacitado 
('P-0029', '1200871543', 'Ana', 'Casta�eda', 42, 'M', '0910187154', 'Pasajero', 6), -- Normal
('P-0030', '2201098147', 'Martina', 'G�ngora', 30, 'M', '0901876143', 'Pasajero', 13), -- Normal
('P-0031', '1723456701', 'Miguel', 'Hern�ndez', 37, 'H', '0987654323', 'Conductor', 17), -- Conductor
('P-0032', '2300166201', 'Sandra', 'G�mez', 33, 'M', '0987654324', 'Conductor', 22), -- Conductor
('P-0033', '1712345601', 'Federico', 'Ram�rez', 29, 'H', '0976543220', 'Conductor', 27), -- Conductor
('P-0034', '1201234501', 'Carmen', 'Herrera', 37, 'M', '0965432110', 'Conductor', 34), -- Conductor
('P-0035', '1723456710', 'Fernando', 'Garc�a', 34, 'H', '0998765433', 'Conductor', 30), -- Conductor
('P-0036', '2300166301', 'Sof�a', 'Hern�ndez', 28, 'M', '0987654325', 'Pasajero', 45), -- Normal
('P-0037', '1712345602', 'Roberto', 'Loor', 44, 'H', '0976543221', 'Pasajero', 53), -- Normal
('P-0038', '1201234502', 'Elena', 'Campos', 31, 'M', '0965432111', 'Pasajero', 28), -- Normal
('P-0039', '2300166101', 'Oswaldo', 'Ba�o', 23, 'H', '0985671523', 'Pasajero', 34); -- Normal

-- Tabla: Conductor

INSERT INTO CONDUCTOR (ID_conductor, ID_Licencia, ID_persona) VALUES
('C-0001', 5, 'P-0001'), -- Conductor con Licencia tipo 'E'
('C-0002', 5, 'P-0005'), -- Conductor con Licencia tipo 'E'
('C-0003', 4, 'P-0015'), -- Conductor con Licencia tipo 'D'
('C-0004', 5, 'P-0019'), -- Conductor con Licencia tipo 'E'
('C-0005', 5, 'P-0031'), -- Conductor con Licencia tipo 'E'
('C-0006', 5, 'P-0032'), -- Conductor con Licencia tipo 'E'
('C-0007', 4, 'P-0033'), -- Conductor con Licencia tipo 'D'
('C-0008', 5, 'P-0034'), -- Conductor con Licencia tipo 'E'
('C-0009', 5, 'P-0035'); -- Conductor con Licencia tipo 'E'

-- Tabla: Pasajero

INSERT INTO PASAJERO (ID_Pasajero, Tipo_Pasajero, ID_tarifa, ID_persona) VALUES
('PS-0001', 'Normal', 2, 'P-0022'), -- Normal
('PS-0002', 'Estudiante', 1, 'P-0023'), -- Estudiante
('PS-0003', 'Adulto Mayor', 4, 'P-0024'), -- Adulto Mayor
('PS-0004', 'Normal', 2, 'P-0025'), -- Normal
('PS-0005', 'Normal', 2, 'P-0026'), -- Normal
('PS-0006', 'Estudiante', 1, 'P-0027'), -- Estudiante
('PS-0007', 'Discapacitado', 3, 'P-0028'), -- Discapacitado
('PS-0008', 'Normal', 2, 'P-0029'), -- Normal
('PS-0009', 'Normal', 2, 'P-0030'), -- Normal
('PS-0010', 'Normal', 2, 'P-0021'), -- Normal
('PS-0011', 'Estudiante', 1, 'P-0020'), -- Estudiante
('PS-0012', 'Discapacitado', 3, 'P-0018'), -- Discapacitado
('PS-0013', 'Estudiante', 1, 'P-0017'), -- Estudiante
('PS-0014', 'Adulto mayor', 4, 'P-0014'), -- Adulto mayor
('PS-0015', 'Normal', 2, 'P-0016'), -- Normal
('PS-0016', 'Normal', 2, 'P-0013'), -- Normal
('PS-0017', 'Discapacitado', 3, 'P-0012'), -- Discapacitado
('PS-0018', 'Adulto mayor', 4, 'P-0011'), -- Adulto mayor
('PS-0019', 'Estudiante', 1, 'P-0010'), -- Estudiante
('PS-0020', 'Adulto mayor', 4, 'P-0009'), -- Adulto mayor
('PS-0021', 'Estudiante', 1, 'P-0008'), -- Estudiante
('PS-0022', 'Estudiante', 1, 'P-0007'), -- Estudiante
('PS-0023', 'Normal', 2, 'P-0006'), -- Normal
('PS-0024', 'Normal', 2, 'P-0004'), -- Normal
('PS-0025', 'Normal', 2, 'P-0003'), -- Normal
('PS-0026', 'Normal', 2, 'P-0002'), -- Normal
('PS-0027', 'Normal', 2, 'P-0036'), -- Normal
('PS-0028', 'Normal', 2, 'P-0037'), -- Normal
('PS-0029', 'Normal', 2, 'P-0038'), -- Normal
('PS-0030', 'Normal', 2, 'P-0039'); -- Normal

-- Tabla: Matricula

INSERT INTO MATRICULA (Placa_vehicular, Nombre_propietario, Capacidad_pasajeros, ID_marca, ID_color, ID_modelo) VALUES
('JPW-4571', 'Gaspar Zambrano', 47, 17, 2, 1),
('JQX-8912', 'Alberto Mart�nez', 45, 5, 1, 6),
('JRM-1234', 'Ra�l Galindo', 44, 4, 2, 8),
('JPA-5678', 'H�ctor Oleas', 43, 15, 8, 10),
('JFY-2468', 'Fernando V�lez', 40, 11, 2, 17),
('JLR-9876', 'Laura Paucar', 50, 1, 9, 28),
('JBG-5432', 'Gabriel Marquez', 48, 6, 15,3),
('JVC-1098', 'Ver�nica Cede�o', 42, 2, 9, 16),
('JVC-2398', 'Alex Farias', 44, 8, 2, 13);

-- Tabla: Vehiculo

INSERT INTO VEHICULO (Nombre_vehiculo, ID_conductor, ID_matricula) VALUES
('Speedy', 'C-0001', 1),
('Thunder', 'C-0002', 2),
('Raptor', 'C-0003', 3),
('Silver Bullet', 'C-0004', 4),
('Phoenix', 'C-0005', 5),
('Midnight Rider', 'C-0006', 6),
('Blaze', 'C-0007', 7),
('Skywalker', 'C-0008', 8),
('Skywalker', 'C-0009', 9);

-- Tabla: Detalle_Mantenimiento

-- Tabla: DETALLE_MANTENIMIENTO

INSERT INTO DETALLE_MANTENIMIENTO (Costo_Total, Detalle, ID_vehiculo, ID_mantenimiento) VALUES
(5.00, 'Mantenimiento inspeccionario', 1, 3),
(60.00, 'Mantenimiento cambio de aceite y reparaciones adicionales', 2, 5),
(30.00, 'Mantenimiento Correctivo', 3, 2),
(70.00, 'Mantenimiento de frenos y reparaciones adicionales', 4, 7),
(800.00, 'Reparaci�n del motor', 5, 4),
(280.00, 'Mantenimiento el�ctrico y filtro de aire', 6, 10),
(10.00, 'Mantenimiento Preventivo', 7, 1),
(35.00, 'Alineaci�n de neum�ticos', 8, 6),
(5.00, 'Mantenimiento inspeccionario', 9, 3);

-- Tabla: Horario

INSERT INTO HORARIO (Hora_salida, Hora_llegada, ID_ruta, ID_vehiculo) VALUES
('06:00:00', '18:00:00', 1, 1),
('06:30:00', '18:30:00', 2, 2),
('08:00:00', '20:00:00', 3, 3),
('06:30:00', '18:30:00', 4, 4),
('01:00:00', '13:00:00', 5, 5),
('16:30:00', '04:30:00', 6, 6),
('18:00:00', '06:00:00', 7, 7),
('19:30:00', '07:30:00', 8, 8),
('09:30:00', '21:30:00', 9, 9);

-- Tabla: Pago

INSERT INTO PAGO (Fecha_pago, Metodo_pago, Monto_Pagado, ID_Pasajero, ID_ruta)
VALUES
(GETDATE(), 'Tarjeta', 0.75, 'PS-0001', 1), -- Normal
(GETDATE(), 'Efectivo', 0.40, 'PS-0002', 2), -- Estudiante
(GETDATE(), 'Efectivo', 0.40, 'PS-0003', 3), -- Adulto Mayor
(GETDATE(), 'Efectivo', 0.75, 'PS-0004', 4), -- Normal
(GETDATE(), 'Efectivo', 0.75, 'PS-0005', 5), -- Normal
(GETDATE(), 'Efectivo', 0.40, 'PS-0006', 6), -- Estudiante
(GETDATE(), 'Efectivo', 0.40, 'PS-0007', 7), -- Discapacitado
(GETDATE(), 'Efectivo', 0.75, 'PS-0008', 8), -- Normal
(GETDATE(), 'Efectivo', 0.75, 'PS-0009', 9), -- Normal
(GETDATE(), 'Efectivo', 0.75, 'PS-0010', 10), -- Normal
(GETDATE(), 'Efectivo', 0.40, 'PS-0011', 11), -- Estudiante
(GETDATE(), 'Efectivo', 0.40, 'PS-0012', 12), -- Discapacitado
(GETDATE(), 'Efectivo', 0.40, 'PS-0013', 13), -- Estudiante
(GETDATE(), 'Efectivo', 0.40, 'PS-0014', 14), -- Adulto Mayor
(GETDATE(), 'Efectivo', 0.75, 'PS-0015', 15), -- Normal
(GETDATE(), 'Efectivo', 0.75, 'PS-0016', 16), -- Normal
(GETDATE(), 'Efectivo', 0.40, 'PS-0017', 17), -- Discapacitado
(GETDATE(), 'Efectivo', 0.40, 'PS-0018', 18), -- Adulto Mayor
(GETDATE(), 'Efectivo', 0.40, 'PS-0019', 19), -- Estudiante
(GETDATE(), 'Efectivo', 0.40, 'PS-0020', 20), -- Adulto Mayor
(GETDATE(), 'Efectivo', 0.40, 'PS-0021', 21), -- Estudiante
(GETDATE(), 'Efectivo', 0.40, 'PS-0022', 22), -- Estudiante
(GETDATE(), 'Tarjeta', 0.75, 'PS-0023', 23), -- Normal
(GETDATE(), 'Efectivo', 0.75, 'PS-0024', 24), -- Normal
(GETDATE(), 'Tarjeta', 0.75, 'PS-0025', 25), -- Normal
(GETDATE(), 'Efectivo', 0.75, 'PS-0026', 26), -- Normal
(GETDATE(), 'Efectivo', 0.75, 'PS-0027', 27), -- Normal
(GETDATE(), 'Efectivo', 0.75, 'PS-0028', 28), -- Normal
(GETDATE(), 'Efectivo', 0.75, 'PS-0029', 29), -- Normal
(GETDATE(), 'Efectivo', 0.75, 'PS-0030', 30); -- Normal

-- Procedimientos almacenados.

-- Procedimiento almacenado para insertar datos en la tabla COLOR
CREATE PROCEDURE InsertarColor
    @Color varchar(20)
AS
BEGIN
    INSERT INTO COLOR (Color)
    VALUES (@Color);
END;


-- Procedimiento almacenado para insertar datos en la tabla MARCA
CREATE PROCEDURE InsertarMarca
    @Marca varchar(30),
    @Detalle varchar(255)
AS
BEGIN
    INSERT INTO MARCA (Marca, Detalle)
    VALUES (@Marca, @Detalle);
END;


-- Procedimiento almacenado para insertar datos en la tabla MODELO
CREATE PROCEDURE InsertarModelo
    @Modelo varchar(30),
    @Detalle varchar(255)
AS
BEGIN
    INSERT INTO MODELO (Modelo, Detalle)
    VALUES (@Modelo, @Detalle);
END;


-- Procedimiento almacenado para insertar datos en la tabla MANTENIMIENTO
CREATE PROCEDURE InsertarMantenimiento
    @TipoMantenimiento varchar(100),
    @Descripcion varchar(255),
    @CostoMantenimiento decimal(7,2)
AS
BEGIN
    INSERT INTO MANTENIMIENTO (Tipo_mantenimiento, Descripcion, Costo_mantenimiento)
    VALUES (@TipoMantenimiento, @Descripcion, @CostoMantenimiento);
END;


-- Procedimiento almacenado para insertar datos en la tabla DIRECCION
CREATE PROCEDURE InsertarDireccion
    @Detalle varchar(255)
AS
BEGIN
    INSERT INTO DIRECCION (Detalle)
    VALUES (@Detalle);
END;


-- Procedimiento almacenado para insertar datos en la tabla RUTA
CREATE PROCEDURE InsertarRuta
    @NombreRuta varchar(100),
    @MontoPagado decimal(7,2),
    @Descripcion varchar(255)
AS
BEGIN
    INSERT INTO RUTA (Nombre_ruta, Monto_pagado, Descripcion)
    VALUES (@NombreRuta, @MontoPagado, @Descripcion);
END;


-- Procedimiento almacenado para insertar datos en la tabla PERSONA
CREATE PROCEDURE InsertarPersona
    @IDPersona varchar(7),
    @Cedula varchar(10),
    @Nombre varchar(50),
    @Apellido varchar(50),
    @Edad int,
    @Sexo varchar(3),
    @Telefono varchar(10),
    @TipoPersona varchar(30),
    @IDDireccion int
AS
BEGIN
    INSERT INTO PERSONA (ID_persona, Cedula, Nombre, Apellido, Edad, Sexo, Telefono, Tipo_persona, ID_direccion)
    VALUES (@IDPersona, @Cedula, @Nombre, @Apellido, @Edad, @Sexo, @Telefono, @TipoPersona, @IDDireccion);
END;


-- Procedimiento almacenado para insertar datos en la tabla CONDUCTOR
CREATE PROCEDURE InsertarConductor
    @IDConductor varchar(7),
    @IDLicencia int,
    @IDPersona varchar(7)
AS
BEGIN
    INSERT INTO CONDUCTOR (ID_conductor, ID_Licencia, ID_persona)
    VALUES (@IDConductor, @IDLicencia, @IDPersona);
END;


-- Procedimiento almacenado para insertar datos en la tabla PASAJERO
CREATE PROCEDURE InsertarPasajero
    @IDPasajero varchar(7),
    @TipoPasajero varchar(30),
    @IDTarifa int,
    @IDPersona varchar(7)
AS
BEGIN
    INSERT INTO PASAJERO (ID_Pasajero, Tipo_Pasajero, ID_tarifa, ID_persona)
    VALUES (@IDPasajero, @TipoPasajero, @IDTarifa, @IDPersona);
END;


-- Procedimiento almacenado para insertar datos en la tabla MATRICULA
CREATE PROCEDURE InsertarMatricula
    @PlacaVehicular varchar(10),
    @NombrePropietario varchar(50),
    @CapacidadPasajeros int,
    @IDMarca int,
    @IDColor int,
    @IDModelo int
AS
BEGIN
    INSERT INTO MATRICULA (Placa_vehicular, Nombre_propietario, Capacidad_pasajeros, ID_marca, ID_color, ID_modelo)
    VALUES (@PlacaVehicular, @NombrePropietario, @CapacidadPasajeros, @IDMarca, @IDColor, @IDModelo);
END;


-- Procedimiento almacenado para insertar datos en la tabla VEHICULO
CREATE PROCEDURE InsertarVehiculo
    @NombreVehiculo varchar(50),
    @IDConductor varchar(7),
    @IDMatricula int
AS
BEGIN
    INSERT INTO VEHICULO (Nombre_vehiculo, ID_conductor, ID_matricula)
    VALUES (@NombreVehiculo, @IDConductor, @IDMatricula);
END;


-- Procedimiento almacenado para insertar datos en la tabla DETALLE_MANTENIMIENTO
CREATE PROCEDURE InsertarDetalleMantenimiento
    @CostoTotal decimal(7,2),
    @Detalle varchar(255),
    @IDVehiculo int,
    @IDMantenimiento int
AS
BEGIN
    INSERT INTO DETALLE_MANTENIMIENTO (Costo_Total, Detalle, ID_vehiculo, ID_mantenimiento)
    VALUES (@CostoTotal, @Detalle, @IDVehiculo, @IDMantenimiento);
END;


-- Procedimiento almacenado para insertar datos en la tabla HORARIO
CREATE PROCEDURE InsertarHorario
    @HoraSalida time,
    @HoraLlegada time,
    @IDRuta int,
    @IDVehiculo int
AS
BEGIN
    INSERT INTO HORARIO (Hora_salida, Hora_llegada, ID_ruta, ID_vehiculo)
    VALUES (@HoraSalida, @HoraLlegada, @IDRuta, @IDVehiculo);
END;


-- Procedimiento almacenado para insertar datos en la tabla PAGO
CREATE PROCEDURE InsertarPago
    @MetodoPago varchar(50),
    @IDPasajero varchar(7),
    @IDRuta int
AS
BEGIN
    DECLARE @MontoPagado decimal(7, 2);

    -- Obtener la tarifa correspondiente para el pasajero desde la tabla TARIFA
    SELECT @MontoPagado = Monto
    FROM TARIFA
    WHERE ID_tarifa = (SELECT ID_tarifa FROM PASAJERO WHERE ID_Pasajero = @IDPasajero);

    -- Insertar datos en la tabla PAGO
    INSERT INTO PAGO (Fecha_pago, Metodo_pago, Monto_Pagado, ID_Pasajero, ID_ruta)
    VALUES (GETDATE(), @MetodoPago, @MontoPagado, @IDPasajero, @IDRuta);

END;

-----------------------------------------------------------------------------------------------
-- Procedimientos para Modificas

-- Procedimiento almacenado para modificar datos en la tabla COLOR
CREATE PROCEDURE ModificarColor
    @ID_color int,
    @NuevoColor varchar(20)
AS
BEGIN
    UPDATE COLOR
    SET Color = @NuevoColor
    WHERE ID_color = @ID_color;
END;


-- Procedimiento almacenado para modificar datos en la tabla MARCA
CREATE PROCEDURE ModificarMarca
    @ID_marca int,
    @Marca varchar(30),
    @Detalle varchar(255)
AS
BEGIN
    UPDATE MARCA
    SET Marca = @Marca,
        Detalle = @Detalle
    WHERE ID_marca = @ID_marca;
END;


-- Procedimiento almacenado para modificar datos en la tabla MODELO
CREATE PROCEDURE ModificarModelo
    @ID_modelo int,
    @Modelo varchar(30),
    @Detalle varchar(255)
AS
BEGIN
    UPDATE MODELO
    SET Modelo = @Modelo,
        Detalle = @Detalle
    WHERE ID_modelo = @ID_modelo;
END;


-- Procedimiento almacenado para modificar datos en la tabla MANTENIMIENTO
CREATE PROCEDURE ModificarMantenimiento
    @ID_mantenimiento int,
    @Tipo_mantenimiento varchar(100),
    @Descripcion varchar(255),
    @Costo_mantenimiento decimal(7,2)
AS
BEGIN
    UPDATE MANTENIMIENTO
    SET Tipo_mantenimiento = @Tipo_mantenimiento,
        Descripcion = @Descripcion,
        Costo_mantenimiento = @Costo_mantenimiento
    WHERE ID_mantenimiento = @ID_mantenimiento;
END;


-- Procedimiento almacenado para modificar datos en la tabla DIRECCION
CREATE PROCEDURE ModificarDireccion
    @ID_direccion int,
    @Detalle varchar(255)
AS
BEGIN
    UPDATE DIRECCION
    SET Detalle = @Detalle
    WHERE ID_direccion = @ID_direccion;
END;


-- Procedimiento almacenado para modificar datos en la tabla RUTA
CREATE PROCEDURE ModificarRuta
    @ID_ruta int,
    @Nombre_ruta varchar(100),
    @Monto_pagado decimal(7,2),
    @Descripcion varchar(255)
AS
BEGIN
    UPDATE RUTA
    SET Nombre_ruta = @Nombre_ruta,
        Monto_pagado = @Monto_pagado,
        Descripcion = @Descripcion
    WHERE ID_ruta = @ID_ruta;
END;


-- Procedimiento almacenado para modificar datos en la tabla PERSONA
CREATE PROCEDURE ModificarPersona
    @ID_persona varchar(7),
    @Cedula varchar(10),
    @Nombre varchar(50),
    @Apellido varchar(50),
    @Edad int,
    @Sexo varchar(3),
    @Telefono varchar(10),
    @Tipo_persona varchar(30),
    @ID_direccion int
AS
BEGIN
    UPDATE PERSONA
    SET Cedula = @Cedula,
        Nombre = @Nombre,
        Apellido = @Apellido,
        Edad = @Edad,
        Sexo = @Sexo,
        Telefono = @Telefono,
        Tipo_persona = @Tipo_persona,
        ID_direccion = @ID_direccion
    WHERE ID_persona = @ID_persona;
END;


-- Procedimiento almacenado para modificar datos en la tabla CONDUCTOR
CREATE PROCEDURE ModificarConductor
    @ID_conductor varchar(7),
    @ID_Licencia int,
    @ID_persona varchar(7)
AS
BEGIN
    UPDATE CONDUCTOR
    SET ID_Licencia = @ID_Licencia,
        ID_persona = @ID_persona
    WHERE ID_conductor = @ID_conductor;
END;


-- Procedimiento almacenado para modificar datos en la tabla PASAJERO
CREATE PROCEDURE ModificarPasajero
    @ID_Pasajero varchar(7),
    @Tipo_Pasajero varchar(30),
    @ID_tarifa int,
    @ID_persona varchar(7)
AS
BEGIN
    UPDATE PASAJERO
    SET Tipo_Pasajero = @Tipo_Pasajero,
        ID_tarifa = @ID_tarifa,
        ID_persona = @ID_persona
    WHERE ID_Pasajero = @ID_Pasajero;
END;


-- Procedimiento almacenado para modificar datos en la tabla MATRICULA
CREATE PROCEDURE ModificarMatricula
    @ID_matricula int,
    @Placa_vehicular varchar(10),
    @Nombre_propietario varchar(50),
    @Capacidad_pasajeros int,
    @ID_marca int,
    @ID_color int,
    @ID_modelo int
AS
BEGIN
    UPDATE MATRICULA
    SET Placa_vehicular = @Placa_vehicular,
        Nombre_propietario = @Nombre_propietario,
        Capacidad_pasajeros = @Capacidad_pasajeros,
        ID_marca = @ID_marca,
        ID_color = @ID_color,
        ID_modelo = @ID_modelo
    WHERE ID_matricula = @ID_matricula;
END;


-- Procedimiento almacenado para modificar datos en la tabla VEHICULO
CREATE PROCEDURE ModificarVehiculo
    @ID_vehiculo int,
    @Nombre_vehiculo varchar(50),
    @ID_conductor varchar(7),
    @ID_matricula int
AS
BEGIN
    UPDATE VEHICULO
    SET Nombre_vehiculo = @Nombre_vehiculo,
        ID_conductor = @ID_conductor,
        ID_matricula = @ID_matricula
    WHERE ID_vehiculo = @ID_vehiculo;
END;


-- Procedimiento almacenado para modificar datos en la tabla DETALLE_MANTENIMIENTO
CREATE PROCEDURE ModificarDetalleMantenimiento
    @ID_detalle int,
    @Costo_Total decimal(7,2),
    @Detalle varchar(255),
    @ID_vehiculo int,
    @ID_mantenimiento int
AS
BEGIN
    UPDATE DETALLE_MANTENIMIENTO
    SET Costo_Total = @Costo_Total,
        Detalle = @Detalle,
        ID_vehiculo = @ID_vehiculo,
        ID_mantenimiento = @ID_mantenimiento
    WHERE ID_detalle = @ID_detalle;
END;


-- Procedimiento almacenado para modificar datos en la tabla HORARIO
CREATE PROCEDURE ModificarHorario
    @ID_horario int,
    @Hora_salida time,
    @Hora_llegada time,
    @ID_ruta int,
    @ID_vehiculo int
AS
BEGIN
    UPDATE HORARIO
    SET Hora_salida = @Hora_salida,
        Hora_llegada = @Hora_llegada,
        ID_ruta = @ID_ruta,
        ID_vehiculo = @ID_vehiculo
    WHERE ID_horario = @ID_horario;
END;


-- Procedimiento almacenado para modificar datos en la tabla PAGO
CREATE PROCEDURE ModificarPago
    @ID_pago int,
    @Metodo_pago varchar(50),
    @Monto_Pagado decimal(7,2),
    @ID_Pasajero varchar(7),
    @ID_ruta int
AS
BEGIN
    UPDATE PAGO
    SET Metodo_pago = @Metodo_pago,
        Monto_Pagado = @Monto_Pagado,
        ID_Pasajero = @ID_Pasajero,
        ID_ruta = @ID_ruta
    WHERE ID_pago = @ID_pago;
END;




-----------------------------------------------------------------------------------------------
-- Procedimiento almacenado para la eliminaci�n

-- Procedimiento almacenado para eliminar datos en la tabla COLOR
CREATE PROCEDURE EliminarColor
    @ID_color int
AS
BEGIN
    DELETE FROM COLOR
    WHERE ID_color = @ID_color;
END;


-- Procedimiento almacenado para eliminar datos en la tabla MARCA
CREATE PROCEDURE EliminarMarca
    @ID_marca int
AS
BEGIN
    DELETE FROM MARCA
    WHERE ID_marca = @ID_marca;
END;


-- Procedimiento almacenado para eliminar datos en la tabla MODELO
CREATE PROCEDURE EliminarModelo
    @ID_modelo int
AS
BEGIN
    DELETE FROM MODELO
    WHERE ID_modelo = @ID_modelo;
END;


-- Procedimiento almacenado para eliminar datos en la tabla MANTENIMIENTO
CREATE PROCEDURE EliminarMantenimiento
    @ID_mantenimiento int
AS
BEGIN
    DELETE FROM MANTENIMIENTO
    WHERE ID_mantenimiento = @ID_mantenimiento;
END;


-- Procedimiento almacenado para eliminar datos en la tabla DIRECCION
CREATE PROCEDURE EliminarDireccion
    @ID_direccion int
AS
BEGIN
    DELETE FROM DIRECCION
    WHERE ID_direccion = @ID_direccion;
END;


-- Procedimiento almacenado para eliminar datos en la tabla RUTA
CREATE PROCEDURE EliminarRuta
    @ID_ruta int
AS
BEGIN
    DELETE FROM RUTA
    WHERE ID_ruta = @ID_ruta;
END;


-- Procedimiento almacenado para eliminar datos en la tabla PERSONA
CREATE PROCEDURE EliminarPersona
    @ID_persona varchar(7)
AS
BEGIN
    DELETE FROM PERSONA
    WHERE ID_persona = @ID_persona;
END;


-- Procedimiento almacenado para eliminar datos en la tabla CONDUCTOR
CREATE PROCEDURE EliminarConductor
    @ID_conductor varchar(7)
AS
BEGIN
    DELETE FROM CONDUCTOR
    WHERE ID_conductor = @ID_conductor;
END;


-- Procedimiento almacenado para eliminar datos en la tabla PASAJERO
CREATE PROCEDURE EliminarPasajero
    @ID_Pasajero varchar(7)
AS
BEGIN
    DELETE FROM PASAJERO
    WHERE ID_Pasajero = @ID_Pasajero;
END;


-- Procedimiento almacenado para eliminar datos en la tabla MATRICULA
CREATE PROCEDURE EliminarMatricula
    @ID_matricula int
AS
BEGIN
    DELETE FROM MATRICULA
    WHERE ID_matricula = @ID_matricula;
END;

SELECT * FROM MATRICULA
-- Procedimiento almacenado para eliminar datos en la tabla VEHICULO
CREATE PROCEDURE EliminarVehiculo
    @ID_vehiculo int
AS
BEGIN
    DELETE FROM VEHICULO
    WHERE ID_vehiculo = @ID_vehiculo;
END;


-- Procedimiento almacenado para eliminar datos en la tabla DETALLE_MANTENIMIENTO
CREATE PROCEDURE EliminarDetalleMantenimiento
    @ID_detalle int
AS
BEGIN
    DELETE FROM DETALLE_MANTENIMIENTO
    WHERE ID_detalle = @ID_detalle;
END;


-- Procedimiento almacenado para eliminar datos en la tabla HORARIO
CREATE PROCEDURE EliminarHorario
    @ID_horario int
AS
BEGIN
    DELETE FROM HORARIO
    WHERE ID_horario = @ID_horario;
END;


-- Procedimiento almacenado para eliminar datos en la tabla PAGO
CREATE PROCEDURE EliminarPago
    @ID_pago int
AS
BEGIN
    DELETE FROM PAGO
    WHERE ID_pago = @ID_pago;
END;


-- VISTAS
SELECT * FROM Usuario

CREATE VIEW VistaUsuario AS
SELECT ID_USUARIO, USUARIO
FROM Usuario;


CREATE VIEW VistaColor AS
SELECT ID_color, Color
FROM COLOR;


CREATE VIEW VistaConductor AS
SELECT ID_conductor, ID_Licencia, ID_persona
FROM CONDUCTOR;


CREATE VIEW VistaDetalleMantenimiento AS
SELECT ID_detalle, Costo_Total, Detalle, ID_vehiculo, ID_mantenimiento
FROM DETALLE_MANTENIMIENTO;



CREATE VIEW VistaDireccion AS
SELECT ID_direccion, Detalle
FROM DIRECCION;


CREATE VIEW VistaHorario AS
SELECT ID_horario, Hora_salida, Hora_llegada, ID_ruta, ID_vehiculo
FROM HORARIO;


CREATE VIEW VistaMantenimiento AS
SELECT ID_mantenimiento, Tipo_mantenimiento, Descripcion, Costo_mantenimiento
FROM MANTENIMIENTO;


CREATE VIEW VistaMarca AS
SELECT ID_marca, Marca, Detalle
FROM MARCA;


CREATE VIEW VistaMatricula AS
SELECT ID_matricula, Placa_vehicular, Nombre_propietario, Capacidad_pasajeros, ID_marca, ID_color, ID_modelo
FROM MATRICULA;



CREATE VIEW VistaModelo AS
SELECT ID_modelo, Modelo, Detalle
FROM MODELO;


CREATE VIEW VistaPago AS
SELECT ID_pago, Fecha_pago, Metodo_pago, Monto_Pagado, ID_Pasajero, ID_ruta
FROM PAGO;


CREATE VIEW VistaPasajero AS
SELECT ID_Pasajero, Tipo_Pasajero, ID_tarifa, ID_persona
FROM PASAJERO;



CREATE VIEW VistaPersona AS
SELECT ID_persona, Cedula, Nombre, Apellido, Edad, Sexo, Telefono, Tipo_persona, ID_direccion
FROM PERSONA;


CREATE VIEW VistaRuta AS
SELECT ID_ruta, Nombre_ruta, Monto_pagado, Descripcion
FROM RUTA;



CREATE VIEW VistaTarifa AS
SELECT ID_tarifa, Nombre_tarifa, Monto, Detalle
FROM TARIFA;


CREATE VIEW VistaTipoLicencia AS
SELECT ID_Licencia, Tipo_licencia, Descripcion
FROM TIPO_LICENCIA;



CREATE VIEW VistaVehiculo AS
SELECT ID_vehiculo, Nombre_vehiculo, ID_conductor, ID_matricula
FROM VEHICULO;































