package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Insertar_Direccion extends JPanel {
    private JTextArea detalleTextArea;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private JButton modificarButton, eliminarButton, insertarButton;

    private ResultSet resultSet;

    public Insertar_Direccion() {
        setLayout(new BorderLayout(10, 10)); // Espaciado entre componentes
        setBackground(new Color(70, 116, 166));

        JPanel panelInsercion = new JPanel(new GridBagLayout());
        panelInsercion.setBackground(new Color(70, 116, 166));

        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar");
        titledBorder.setTitleColor(Color.WHITE);
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        JLabel tituloDetalle = new JLabel("Detalle");
        tituloDetalle.setForeground(Color.WHITE);

        detalleTextArea = new JTextArea(4, 20);
        detalleTextArea.setLineWrap(true);
        detalleTextArea.setWrapStyleWord(true);

        ((AbstractDocument) detalleTextArea.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                    throws BadLocationException {
                String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
                int futureLength = currentText.length() - length + text.length();

                if (futureLength <= 255) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

        insertarButton = new JButton("Insertar");
        personalizarBoton(insertarButton);

        GridBagConstraints gbcTituloDetalle = new GridBagConstraints();
        gbcTituloDetalle.gridx = 0;
        gbcTituloDetalle.gridy = 0;
        gbcTituloDetalle.gridwidth = 2;
        gbcTituloDetalle.insets = new Insets(0, 0, 10, 0);
        gbcTituloDetalle.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcDetalle = new GridBagConstraints();
        gbcDetalle.gridx = 0;
        gbcDetalle.gridy = 1;
        gbcDetalle.gridwidth = 2;
        gbcDetalle.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcInsertar = new GridBagConstraints();
        gbcInsertar.gridx = 0;
        gbcInsertar.gridy = 2;
        gbcInsertar.gridwidth = 2;

        panelInsercion.add(tituloDetalle, gbcTituloDetalle);
        panelInsercion.add(detalleTextArea, gbcDetalle);
        panelInsercion.add(insertarButton, gbcInsertar);

        modificarButton = new JButton("Modificar");
        personalizarBoton(modificarButton);

        eliminarButton = new JButton("Eliminar");
        personalizarBoton(eliminarButton);

        JPanel panelBotonesDireccion = new JPanel();
        panelBotonesDireccion.setLayout(new FlowLayout(FlowLayout.RIGHT));
        panelBotonesDireccion.add(modificarButton);
        panelBotonesDireccion.add(eliminarButton);

        JPanel panelVisualizacionDireccion = new JPanel(new BorderLayout());
        panelVisualizacionDireccion.setBackground(new Color(70, 116, 166));
        JLabel infoLabelDireccion = new JLabel("Visualización, Modificación y Eliminación");
        infoLabelDireccion.setForeground(Color.WHITE);
        infoLabelDireccion.setHorizontalAlignment(SwingConstants.CENTER);
        panelVisualizacionDireccion.add(infoLabelDireccion, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0; // 0 es el índice de la columna ID_direccion
            }
        };
        modeloTabla.addColumn("ID_direccion");
        modeloTabla.addColumn("Detalle");
        tablaRegistros = new JTable(modeloTabla);
        JScrollPane scrollPaneDireccion = new JScrollPane(tablaRegistros);
        panelVisualizacionDireccion.add(scrollPaneDireccion, BorderLayout.CENTER);
        panelVisualizacionDireccion.add(panelBotonesDireccion, BorderLayout.SOUTH);

        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacionDireccion);
        splitPaneHorizontal.setResizeWeight(0.2);

        add(splitPaneHorizontal, BorderLayout.CENTER);

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String detalle = detalleTextArea.getText();
                insertarDireccionEnBaseDeDatos(detalle);
                limpiarCampos();
                cargarRegistros();
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    int idDireccion = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);
                    String detalleSeleccionado = (String) tablaRegistros.getValueAt(filaSeleccionada, 1);

                    detalleTextArea.setText(detalleSeleccionado);

                    if (modificarRegistroEnBaseDeDatos(idDireccion, detalleSeleccionado)) {
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    int idDireccion = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);

                    int opcion = JOptionPane.showConfirmDialog(null, "¿Seguro que quieres eliminar este registro?",
                            "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

                    if (opcion == JOptionPane.YES_OPTION) {
                        eliminarRegistroEnBaseDeDatos(idDireccion);
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cargarRegistros();
    }

    // Método para personalizar un botón
    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140)); // Color de fondo
        boton.setForeground(Color.WHITE); // Color del texto
        boton.setFocusPainted(false); // Evitar que se pinte el borde al obtener el foco
        boton.setFont(new Font("Arial", Font.BOLD, 14)); // Fuente y tamaño del texto
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16)); // Márgenes internos
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR)); // Cambiar el cursor al pasar sobre el botón
    }

    private void cargarRegistros() {
        cargarRegistrosTabla(tablaRegistros, modeloTabla, "SELECT * FROM DIRECCION");
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0); // Limpiar la tabla
        Connection conexion = ConexionBD.obtenerConexion();
    
        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            resultSet = preparedStatement.executeQuery();
    
            while (resultSet.next()) {
                Object[] fila = { resultSet.getInt("ID_direccion"), resultSet.getString("Detalle") };
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }
    

    private void insertarDireccionEnBaseDeDatos(String detalle) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL InsertarDireccion(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, detalle);
            preparedStatement.executeUpdate();
            System.out.println("Dirección insertada en la base de datos: " + detalle);
        } catch (SQLException ex) {
            System.out.println("Error al insertar la dirección en la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private boolean modificarRegistroEnBaseDeDatos(int idDireccion, String nuevoDetalle) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL ModificarDireccion(?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idDireccion);
            preparedStatement.setString(2, nuevoDetalle);
            preparedStatement.executeUpdate();
            System.out.println("Dirección modificada en la base de datos: " + nuevoDetalle);
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al modificar la dirección en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private boolean eliminarRegistroEnBaseDeDatos(int idDireccion) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL EliminarDireccion(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idDireccion);
            preparedStatement.executeUpdate();
            System.out.println("Dirección eliminada de la base de datos con ID: " + idDireccion);
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al eliminar la dirección en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void limpiarCampos() {
        detalleTextArea.setText("");
    }

    public static void main(String[] args) {
        // Puedes agregar un JFrame para probar el formulario
        JFrame frame = new JFrame("Insertar Dirección Form");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar la ventana
        frame.setSize(800, 600); // Ajustar el tamaño del formulario
        frame.add(new Insertar_Direccion());
        frame.setVisible(true);
    }
}
