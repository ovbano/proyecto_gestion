package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Insertar_Ruta extends JPanel {
    private JTextField nombreRutaTextField;
    private JTextField montoPagadoTextField;
    private JTextArea descripcionTextArea;
    private JButton insertarButton;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private JButton modificarButton;
    private JButton eliminarButton;

    private ResultSet resultSet;

    public Insertar_Ruta() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(70, 116, 166));

        JPanel panelInsercion = new JPanel(new GridBagLayout());
        panelInsercion.setBackground(new Color(70, 116, 166));

        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar");
        titledBorder.setTitleColor(Color.WHITE);
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        JLabel tituloNombreRuta = new JLabel("Nombre de la Ruta");
        JLabel tituloMontoPagado = new JLabel("Monto Pagado");
        JLabel tituloDescripcion = new JLabel("Descripción");

        tituloNombreRuta.setForeground(Color.WHITE);
        tituloMontoPagado.setForeground(Color.WHITE);
        tituloDescripcion.setForeground(Color.WHITE);

        nombreRutaTextField = new JTextField(20);
        montoPagadoTextField = new JTextField(20);
        descripcionTextArea = new JTextArea(4, 20);

        descripcionTextArea.setLineWrap(true);
        descripcionTextArea.setWrapStyleWord(true);

        ((AbstractDocument) descripcionTextArea.getDocument()).setDocumentFilter(new DocumentFilter() {
    @Override
    public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
            throws BadLocationException {
        String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
        int futureLength = currentText.length() - length + text.length();

        if (futureLength <= 255) {
            super.replace(fb, offset, length, text, attrs);
        }
    }
});


        insertarButton = new JButton("Insertar");
        personalizarBoton(insertarButton);

        GridBagConstraints gbcTituloNombreRuta = new GridBagConstraints();
        gbcTituloNombreRuta.gridx = 0;
        gbcTituloNombreRuta.gridy = 0;
        gbcTituloNombreRuta.gridwidth = 2;
        gbcTituloNombreRuta.insets = new Insets(0, 0, 10, 0);
        gbcTituloNombreRuta.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloMontoPagado = new GridBagConstraints();
        gbcTituloMontoPagado.gridx = 0;
        gbcTituloMontoPagado.gridy = 3;
        gbcTituloMontoPagado.gridwidth = 2;
        gbcTituloMontoPagado.insets = new Insets(0, 0, 10, 0);
        gbcTituloMontoPagado.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloDescripcion = new GridBagConstraints();
        gbcTituloDescripcion.gridx = 0;
        gbcTituloDescripcion.gridy = 6;
        gbcTituloDescripcion.gridwidth = 2;
        gbcTituloDescripcion.insets = new Insets(0, 0, 10, 0);
        gbcTituloDescripcion.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcNombreRuta = new GridBagConstraints();
        gbcNombreRuta.gridx = 0;
        gbcNombreRuta.gridy = 2;
        gbcNombreRuta.gridwidth = 2;
        gbcNombreRuta.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcMontoPagado = new GridBagConstraints();
        gbcMontoPagado.gridx = 0;
        gbcMontoPagado.gridy = 5;
        gbcMontoPagado.gridwidth = 2;
        gbcMontoPagado.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcDescripcion = new GridBagConstraints();
        gbcDescripcion.gridx = 0;
        gbcDescripcion.gridy = 8;
        gbcDescripcion.gridwidth = 2;
        gbcDescripcion.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcInsertar = new GridBagConstraints();
        gbcInsertar.gridx = 0;
        gbcInsertar.gridy = 9;
        gbcInsertar.gridwidth = 2;

        panelInsercion.add(tituloNombreRuta, gbcTituloNombreRuta);
        panelInsercion.add(nombreRutaTextField, gbcNombreRuta);
        panelInsercion.add(tituloMontoPagado, gbcTituloMontoPagado);
        panelInsercion.add(montoPagadoTextField, gbcMontoPagado);
        panelInsercion.add(tituloDescripcion, gbcTituloDescripcion);
        panelInsercion.add(descripcionTextArea, gbcDescripcion);
        panelInsercion.add(insertarButton, gbcInsertar);

        modificarButton = new JButton("Modificar");
        personalizarBoton(modificarButton);

        eliminarButton = new JButton("Eliminar");
        personalizarBoton(eliminarButton);

        JPanel panelBotonesRuta = new JPanel();
        panelBotonesRuta.setLayout(new FlowLayout(FlowLayout.RIGHT));
        panelBotonesRuta.add(modificarButton);
        panelBotonesRuta.add(eliminarButton);

        JPanel panelVisualizacionRuta = new JPanel(new BorderLayout());
        panelVisualizacionRuta.setBackground(new Color(70, 116, 166));
        JLabel infoLabelRuta = new JLabel("Visualización, Modificación y Eliminación");
        infoLabelRuta.setForeground(Color.WHITE);
        infoLabelRuta.setHorizontalAlignment(SwingConstants.CENTER);
        panelVisualizacionRuta.add(infoLabelRuta, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0; // 0 es el índice de la columna ID_ruta
            }
        };
        modeloTabla.addColumn("ID_ruta");
        modeloTabla.addColumn("Nombre_ruta");
        modeloTabla.addColumn("Monto_pagado");
        modeloTabla.addColumn("Descripcion");
        tablaRegistros = new JTable(modeloTabla);
        JScrollPane scrollPaneRuta = new JScrollPane(tablaRegistros);
        panelVisualizacionRuta.add(scrollPaneRuta, BorderLayout.CENTER);
        panelVisualizacionRuta.add(panelBotonesRuta, BorderLayout.SOUTH);

        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacionRuta);
        splitPaneHorizontal.setResizeWeight(0.2);

        add(splitPaneHorizontal, BorderLayout.CENTER);

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombreRuta = nombreRutaTextField.getText();
                String montoPagadoText = montoPagadoTextField.getText();
                String descripcion = descripcionTextArea.getText();

                // Validar que el monto pagado sea un número decimal válido
                try {
                    double montoPagado = Double.parseDouble(montoPagadoText);
                    insertarRutaEnBaseDeDatos(nombreRuta, montoPagado, descripcion);
                    limpiarCampos();
                    cargarRegistros();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, introduce un monto pagado válido.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    int idRuta = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);
                    String nombreRutaSeleccionada = (String) tablaRegistros.getValueAt(filaSeleccionada, 1);
                    double montoPagadoSeleccionado = (double) tablaRegistros.getValueAt(filaSeleccionada, 2);
                    String descripcionSeleccionada = (String) tablaRegistros.getValueAt(filaSeleccionada, 3);

                    nombreRutaTextField.setText(nombreRutaSeleccionada);
                    montoPagadoTextField.setText(String.valueOf(montoPagadoSeleccionado));
                    descripcionTextArea.setText(descripcionSeleccionada);

                    if (modificarRegistroEnBaseDeDatos(idRuta, nombreRutaSeleccionada, montoPagadoSeleccionado,
                            descripcionSeleccionada)) {
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    int idRuta = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);

                    int opcion = JOptionPane.showConfirmDialog(null,
                            "¿Seguro que quieres eliminar este registro?", "Confirmar eliminación",
                            JOptionPane.YES_NO_OPTION);

                    if (opcion == JOptionPane.YES_OPTION) {
                        eliminarRegistroEnBaseDeDatos(idRuta);
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cargarRegistros();
    }

    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private boolean modificarRegistroEnBaseDeDatos(int idRuta, String nuevoNombreRuta, double nuevoMontoPagado,
            String nuevaDescripcion) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL ModificarRuta(?, ?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idRuta);
            preparedStatement.setString(2, nuevoNombreRuta);
            preparedStatement.setDouble(3, nuevoMontoPagado);
            preparedStatement.setString(4, nuevaDescripcion);
            preparedStatement.executeUpdate();
            System.out.println("Ruta modificada en la base de datos: " + nuevoNombreRuta);
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al modificar la ruta en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private boolean eliminarRegistroEnBaseDeDatos(int idRuta) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL EliminarRuta(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idRuta);
            preparedStatement.executeUpdate();
            System.out.println("Ruta eliminada de la base de datos con ID: " + idRuta);
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al eliminar la ruta en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void cargarRegistros() {
        cargarRegistrosTabla(tablaRegistros, modeloTabla, "SELECT * FROM RUTA");
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0);
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Object[] fila = { resultSet.getInt("ID_ruta"), resultSet.getString("Nombre_ruta"),
                        resultSet.getDouble("Monto_pagado"), resultSet.getString("Descripcion") };
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void insertarRutaEnBaseDeDatos(String nombreRuta, double montoPagado, String descripcion) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL InsertarRuta(?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, nombreRuta);
            preparedStatement.setDouble(2, montoPagado);
            preparedStatement.setString(3, descripcion);
            preparedStatement.executeUpdate();
            System.out.println("Ruta insertada en la base de datos: " + nombreRuta);
        } catch (SQLException ex) {
            System.out.println("Error al insertar la ruta en la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void limpiarCampos() {
        nombreRutaTextField.setText("");
        montoPagadoTextField.setText("");
        descripcionTextArea.setText("");
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Insertar Ruta Form");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setSize(800, 600);
        frame.add(new Insertar_Ruta());
        frame.setVisible(true);
    }
}
