package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Insertar_Pagos extends JPanel {
    private JTextField metodoPagoTextField;
    private JTextField idPasajeroTextField;
    private JTextField idRutaTextField;
    private JTextField montoPagadoTextField;
    private JButton insertarButton;
    private JTable tablaPagos;
    private DefaultTableModel modeloTabla;
    private JButton modificarButton;
    private JButton eliminarButton;

    private ResultSet resultSet;

    public Insertar_Pagos() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(70, 116, 166));

        // Panel de inserción
        JPanel panelInsercion = new JPanel(new GridBagLayout());
        panelInsercion.setBackground(new Color(70, 116, 166));

        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar Pago");
        titledBorder.setTitleColor(Color.WHITE);
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        JLabel tituloMetodoPago = new JLabel("Método de Pago");
        JLabel tituloIdPasajero = new JLabel("ID Pasajero");
        JLabel tituloIdRuta = new JLabel("ID Ruta");
        JLabel tituloMontoPagado = new JLabel("Monto Pagado");

        tituloMetodoPago.setForeground(Color.WHITE);
        tituloIdPasajero.setForeground(Color.WHITE);
        tituloIdRuta.setForeground(Color.WHITE);
        tituloMontoPagado.setForeground(Color.WHITE);

        metodoPagoTextField = new JTextField(20);
        idPasajeroTextField = new JTextField(20);
        idRutaTextField = new JTextField(20);
        montoPagadoTextField = new JTextField(20);

        insertarButton = new JButton("Insertar Pago");
        personalizarBoton(insertarButton);

        GridBagConstraints gbcTituloMetodoPago = new GridBagConstraints();
        gbcTituloMetodoPago.gridx = 0;
        gbcTituloMetodoPago.gridy = 0;
        gbcTituloMetodoPago.gridwidth = 2;
        gbcTituloMetodoPago.insets = new Insets(0, 0, 10, 0);
        gbcTituloMetodoPago.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloIdPasajero = new GridBagConstraints();
        gbcTituloIdPasajero.gridx = 0;
        gbcTituloIdPasajero.gridy = 3;
        gbcTituloIdPasajero.gridwidth = 2;
        gbcTituloIdPasajero.insets = new Insets(0, 0, 10, 0);
        gbcTituloIdPasajero.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloIdRuta = new GridBagConstraints();
        gbcTituloIdRuta.gridx = 0;
        gbcTituloIdRuta.gridy = 6;
        gbcTituloIdRuta.gridwidth = 2;
        gbcTituloIdRuta.insets = new Insets(0, 0, 10, 0);
        gbcTituloIdRuta.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloMontoPagado = new GridBagConstraints();
        gbcTituloMontoPagado.gridx = 0;
        gbcTituloMontoPagado.gridy = 9;
        gbcTituloMontoPagado.gridwidth = 2;
        gbcTituloMontoPagado.insets = new Insets(0, 0, 10, 0);
        gbcTituloMontoPagado.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcMetodoPago = new GridBagConstraints();
        gbcMetodoPago.gridx = 0;
        gbcMetodoPago.gridy = 2;
        gbcMetodoPago.gridwidth = 2;
        gbcMetodoPago.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcIdPasajero = new GridBagConstraints();
        gbcIdPasajero.gridx = 0;
        gbcIdPasajero.gridy = 5;
        gbcIdPasajero.gridwidth = 2;
        gbcIdPasajero.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcIdRuta = new GridBagConstraints();
        gbcIdRuta.gridx = 0;
        gbcIdRuta.gridy = 8;
        gbcIdRuta.gridwidth = 2;
        gbcIdRuta.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcMontoPagado = new GridBagConstraints();
        gbcMontoPagado.gridx = 0;
        gbcMontoPagado.gridy = 11;
        gbcMontoPagado.gridwidth = 2;
        gbcMontoPagado.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcInsertar = new GridBagConstraints();
        gbcInsertar.gridx = 0;
        gbcInsertar.gridy = 12;
        gbcInsertar.gridwidth = 2;

        panelInsercion.add(tituloMetodoPago, gbcTituloMetodoPago);
        panelInsercion.add(metodoPagoTextField, gbcMetodoPago);
        panelInsercion.add(tituloIdPasajero, gbcTituloIdPasajero);
        panelInsercion.add(idPasajeroTextField, gbcIdPasajero);
        panelInsercion.add(tituloIdRuta, gbcTituloIdRuta);
        panelInsercion.add(idRutaTextField, gbcIdRuta);
        panelInsercion.add(tituloMontoPagado, gbcTituloMontoPagado);
        panelInsercion.add(montoPagadoTextField, gbcMontoPagado);
        panelInsercion.add(insertarButton, gbcInsertar);

        // Panel de visualización
        JPanel panelVisualizacion = new JPanel(new BorderLayout());
        panelVisualizacion.setBackground(new Color(70, 116, 166));

        TitledBorder titledBorderVisualizacion = BorderFactory.createTitledBorder("Visualización de Pagos");
        titledBorderVisualizacion.setTitleColor(Color.WHITE);
        titledBorderVisualizacion.setTitleJustification(TitledBorder.CENTER);
        panelVisualizacion.setBorder(titledBorderVisualizacion);

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return true;
            }
        };
        modeloTabla.addColumn("ID Pago");
        modeloTabla.addColumn("Fecha Pago");
        modeloTabla.addColumn("Método Pago");
        modeloTabla.addColumn("Monto Pagado");
        modeloTabla.addColumn("ID Pasajero");
        modeloTabla.addColumn("ID Ruta");
        tablaPagos = new JTable(modeloTabla);
        JScrollPane scrollPanePagos = new JScrollPane(tablaPagos);
        panelVisualizacion.add(scrollPanePagos, BorderLayout.CENTER);

        modificarButton = new JButton("Modificar Pago");
        personalizarBoton(modificarButton);

        eliminarButton = new JButton("Eliminar Pago");
        personalizarBoton(eliminarButton);

        JPanel panelBotonesVisualizacion = new JPanel();
        panelBotonesVisualizacion.setLayout(new FlowLayout(FlowLayout.RIGHT));
        panelBotonesVisualizacion.add(modificarButton);
        panelBotonesVisualizacion.add(eliminarButton);
        panelVisualizacion.add(panelBotonesVisualizacion, BorderLayout.SOUTH);

        // Manejo de eventos
        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String metodoPago = metodoPagoTextField.getText();
                String idPasajero = idPasajeroTextField.getText();
                String idRutaText = idRutaTextField.getText();
                String montoPagadoText = montoPagadoTextField.getText();

                try {
                    int idRuta = Integer.parseInt(idRutaText);
                    double montoPagado = Double.parseDouble(montoPagadoText);

                    insertarPagoEnBaseDeDatos(metodoPago, idPasajero, idRuta, montoPagado);
                    limpiarCampos();
                    cargarRegistros();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, introduce valores válidos.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaPagos.getSelectedRow();

                if (filaSeleccionada != -1) {
                    int idPago = (int) tablaPagos.getValueAt(filaSeleccionada, 0);
                    String metodoPago = (String) tablaPagos.getValueAt(filaSeleccionada, 2);
                    String montoPagadoText = (String) tablaPagos.getValueAt(filaSeleccionada, 3);
                    String idPasajero = (String) tablaPagos.getValueAt(filaSeleccionada, 4);
                    String idRutaText = (String) tablaPagos.getValueAt(filaSeleccionada, 5);

                    metodoPagoTextField.setText(metodoPago);
                    montoPagadoTextField.setText(montoPagadoText);
                    idPasajeroTextField.setText(idPasajero);
                    idRutaTextField.setText(idRutaText);

                    if (modificarPagoEnBaseDeDatos(idPago, metodoPago, idPasajero, idRutaText)) {
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaPagos.getSelectedRow();

                if (filaSeleccionada != -1) {
                    int idPago = (int) tablaPagos.getValueAt(filaSeleccionada, 0);

                    int opcion = JOptionPane.showConfirmDialog(null,
                            "¿Seguro que quieres eliminar este pago?", "Confirmar eliminación",
                            JOptionPane.YES_NO_OPTION);

                    if (opcion == JOptionPane.YES_OPTION) {
                        eliminarPagoEnBaseDeDatos(idPago);
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacion);
        splitPaneHorizontal.setResizeWeight(0.2);

        add(splitPaneHorizontal, BorderLayout.CENTER);

        cargarRegistros();
    }

    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void cargarRegistros() {
        cargarRegistrosTabla(tablaPagos, modeloTabla, "SELECT * FROM PAGO");
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0);
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Object[] fila = { resultSet.getInt("ID_pago"), resultSet.getTimestamp("Fecha_pago"),
                        resultSet.getString("Metodo_pago"), resultSet.getDouble("Monto_Pagado"),
                        resultSet.getString("ID_Pasajero"), resultSet.getInt("ID_ruta") };
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void insertarPagoEnBaseDeDatos(String metodoPago, String idPasajero, int idRuta, double montoPagado) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL InsertarPago(?, ?, ?)}";
        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, metodoPago);
            preparedStatement.setString(2, idPasajero);
            preparedStatement.setInt(3, idRuta);
            preparedStatement.executeUpdate();
            System.out.println("Pago insertado en la base de datos.");
        } catch (SQLException ex) {
            System.out.println("Error al insertar el pago en la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private boolean modificarPagoEnBaseDeDatos(int idPago, String metodoPago, String idPasajero, String idRuta) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL ModificarPago(?, ?, ?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idPago);
            preparedStatement.setString(2, metodoPago);
            preparedStatement.setDouble(3, Double.parseDouble(idPasajero));
            preparedStatement.setInt(4, Integer.parseInt(idRuta));
            preparedStatement.executeUpdate();
            System.out.println("Pago modificado en la base de datos.");
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al modificar el pago en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void eliminarPagoEnBaseDeDatos(int idPago) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL EliminarPago(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idPago);
            preparedStatement.executeUpdate();
            System.out.println("Pago eliminado de la base de datos con éxito.");
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el pago de la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void limpiarCampos() {
        metodoPagoTextField.setText("");
        idPasajeroTextField.setText("");
        idRutaTextField.setText("");
        montoPagadoTextField.setText("");
        tablaPagos.clearSelection();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("Gestión de Pagos");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.getContentPane().add(new Insertar_Pagos());
                frame.setSize(800, 600);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            }
        });
    }
}
