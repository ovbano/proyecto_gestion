package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Insertar_Marca extends JPanel {
    private JTextField marcaTextField;
    private JTextArea detalleTextArea;
    private JButton insertarButton;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private JButton modificarButton;
    private JButton eliminarButton;


    public Insertar_Marca() {
        // Configurar el formulario de inserción, modificación y eliminación de marca
        setLayout(new BorderLayout(10, 10)); // Espaciado entre componentes
        setBackground(new Color(70, 116, 166));

        // Panel de inserción con GridBagLayout
        JPanel panelInsercion = new JPanel(new GridBagLayout());
        panelInsercion.setBackground(new Color(70, 116, 166));

        // Crear TitledBorder para el borde titulado
        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar Marca");
        titledBorder.setTitleColor(Color.WHITE); // Color del texto del título
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        // Agregar títulos centrados
        JLabel tituloMarca = new JLabel("Marca");
        JLabel tituloDetalle = new JLabel("Detalle");
        tituloMarca.setForeground(Color.BLACK);
        tituloDetalle.setForeground(Color.BLACK);

        marcaTextField = new JTextField(20);
        detalleTextArea = new JTextArea(4, 20);
        detalleTextArea.setLineWrap(true);
        detalleTextArea.setWrapStyleWord(true);

        // Limitar la cantidad de caracteres en el JTextArea a 255
        ((AbstractDocument) detalleTextArea.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                    throws BadLocationException {
                String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
                int futureLength = currentText.length() - length + text.length();

                if (futureLength <= 255) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

        insertarButton = new JButton("Insertar");
        personalizarBoton(insertarButton);

        GridBagConstraints gbcTituloMarca = new GridBagConstraints();
        gbcTituloMarca.gridx = 0;
        gbcTituloMarca.gridy = 0;
        gbcTituloMarca.gridwidth = 2;
        gbcTituloMarca.insets = new Insets(0, 0, 10, 0);
        gbcTituloMarca.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloDetalle = new GridBagConstraints();
        gbcTituloDetalle.gridx = 0;
        gbcTituloDetalle.gridy = 3;
        gbcTituloDetalle.gridwidth = 2;
        gbcTituloDetalle.insets = new Insets(0, 0, 10, 0);
        gbcTituloDetalle.anchor = GridBagConstraints.CENTER;

        // Restricciones para el marcaTextField
        GridBagConstraints gbcMarca = new GridBagConstraints();
        gbcMarca.gridx = 0;
        gbcMarca.gridy = 2;
        gbcMarca.gridwidth = 2; // Ocupa 2 columnas
        gbcMarca.insets = new Insets(0, 0, 10, 0); // Márgenes

        // Restricciones para el detalleTextArea
        GridBagConstraints gbcDetalle = new GridBagConstraints();
        gbcDetalle.gridx = 0;
        gbcDetalle.gridy = 4;
        gbcDetalle.gridwidth = 2; // Ocupa 2 columnas
        gbcDetalle.insets = new Insets(0, 0, 10, 0); // Márgenes

        // Restricciones para el insertarButton
        GridBagConstraints gbcInsertar = new GridBagConstraints();
        gbcInsertar.gridx = 0;
        gbcInsertar.gridy = 5;
        gbcInsertar.gridwidth = 2; // Ocupa 2 columnas

        panelInsercion.add(tituloMarca, gbcTituloMarca);
        panelInsercion.add(marcaTextField, gbcMarca);
        panelInsercion.add(tituloDetalle, gbcTituloDetalle);
        panelInsercion.add(detalleTextArea, gbcDetalle);
        panelInsercion.add(insertarButton, gbcInsertar);

        // Botón de modificación
        modificarButton = new JButton("Modificar");
        personalizarBoton(modificarButton);

        // Botón de eliminación
        eliminarButton = new JButton("Eliminar");
        personalizarBoton(eliminarButton);

        // Panel para los botones de modificación y eliminación
        JPanel panelBotonesMarca = new JPanel();
        panelBotonesMarca.setLayout(new FlowLayout(FlowLayout.RIGHT)); // Usar FlowLayout para alinear a la derecha
        panelBotonesMarca.add(modificarButton);
        panelBotonesMarca.add(eliminarButton);

        // Panel de visualización y modificación
        JPanel panelVisualizacionMarca = new JPanel(new BorderLayout());
        panelVisualizacionMarca.setBackground(new Color(70, 116, 166));
        JLabel infoLabelMarca = new JLabel("Visualización, Modificación y Eliminación de Marcas");
        infoLabelMarca.setForeground(Color.WHITE); // Color del texto
        infoLabelMarca.setHorizontalAlignment(SwingConstants.CENTER); // Centrar el texto
        panelVisualizacionMarca.add(infoLabelMarca, BorderLayout.NORTH);

        // Tabla para mostrar registros
        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Hacer que la columna de ID no sea editable
                return column != 0; // 0 es el índice de la columna ID_marca
            }
        };
        modeloTabla.addColumn("ID_marca");
        modeloTabla.addColumn("Marca");
        modeloTabla.addColumn("Detalle");
        tablaRegistros = new JTable(modeloTabla);
        JScrollPane scrollPaneMarca = new JScrollPane(tablaRegistros);
        panelVisualizacionMarca.add(scrollPaneMarca, BorderLayout.CENTER);
        panelVisualizacionMarca.add(panelBotonesMarca, BorderLayout.SOUTH); // Agregar el panel de botones a la parte inferior

        // Espacio entre paneles

        // Crear JSplitPane horizontal para dividir el formulario en dos partes
        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacionMarca);
        splitPaneHorizontal.setResizeWeight(0.2);

        // Agregar el JSplitPane a la ventana principal
        add(splitPaneHorizontal, BorderLayout.CENTER);

        // Configurar el manejador de eventos para los botones
        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String marca = marcaTextField.getText();
                String detalle = detalleTextArea.getText();
                insertarMarcaEnBaseDeDatos(marca, detalle);
                limpiarCampos();
                cargarRegistros();
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    // Obtener valores de la fila seleccionada
                    int idMarca = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);
                    String marcaSeleccionada = (String) tablaRegistros.getValueAt(filaSeleccionada, 1);
                    String detalleSeleccionado = (String) tablaRegistros.getValueAt(filaSeleccionada, 2);

                    // Poblar los campos de inserción con los valores seleccionados
                    marcaTextField.setText(marcaSeleccionada);
                    detalleTextArea.setText(detalleSeleccionado);

                    // Implementar la lógica para modificar el registro en la base de datos
                    if (modificarRegistroEnBaseDeDatos(idMarca, marcaSeleccionada, detalleSeleccionado)) {
                        // Limpiar campos después de la modificación
                        limpiarCampos();
                        // Recargar registros en la tabla
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    // Obtener el ID de la marca seleccionada en la tabla
                    int idMarca = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);

                    // Preguntar al usuario para confirmar la eliminación
                    int opcion = JOptionPane.showConfirmDialog(null, "¿Seguro que quieres eliminar este registro?",
                            "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

                    // Implementar la lógica para eliminar el registro seleccionado
                    if (opcion == JOptionPane.YES_OPTION) {
                        eliminarRegistroEnBaseDeDatos(idMarca);
                        // Limpiar campos después de la eliminación
                        limpiarCampos();
                        // Recargar registros en la tabla
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Cargar registros al inicializar el formulario
        cargarRegistros();
    }

    // Método para personalizar un botón
    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140)); // Color de fondo
        boton.setForeground(Color.WHITE); // Color del texto
        boton.setFocusPainted(false); // Evitar que se pinte el borde al obtener el foco
        boton.setFont(new Font("Arial", Font.BOLD, 14)); // Fuente y tamaño del texto
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16)); // Márgenes internos
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR)); // Cambiar el cursor al pasar sobre el botón
    }

    private void insertarMarcaEnBaseDeDatos(String marca, String detalle) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL InsertarMarca(?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, marca);
            preparedStatement.setString(2, detalle);
            preparedStatement.executeUpdate();
            System.out.println("Marca insertada en la base de datos: " + marca);
        } catch (SQLException ex) {
            System.out.println("Error al insertar la marca en la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private boolean modificarRegistroEnBaseDeDatos(int idMarca, String nuevaMarca, String nuevoDetalle) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL ModificarMarca(?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idMarca);
            preparedStatement.setString(2, nuevaMarca);
            preparedStatement.setString(3, nuevoDetalle);
            preparedStatement.executeUpdate();
            System.out.println("Marca modificada en la base de datos: " + nuevaMarca);
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al modificar la marca en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private boolean eliminarRegistroEnBaseDeDatos(int idMarca) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL EliminarMarca(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idMarca);
            preparedStatement.executeUpdate();
            System.out.println("Marca eliminada de la base de datos con ID: " + idMarca);
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al eliminar la marca en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void cargarRegistros() {
        cargarRegistrosTabla(tablaRegistros, modeloTabla, "SELECT * FROM MARCA");
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0); // Limpiar la tabla
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Object[] fila = {resultSet.getInt("ID_marca"), resultSet.getString("Marca"),
                        resultSet.getString("Detalle")};
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void limpiarCampos() {
        marcaTextField.setText("");
        detalleTextArea.setText("");
    }

    public static void main(String[] args) {
        // Puedes agregar un JFrame para probar el formulario
        JFrame frame = new JFrame("Insertar Modelo Form");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar la ventana
        frame.setSize(800, 600); // Ajustar el tamaño del formulario
        frame.add(new Insertar_Marca());
        frame.setVisible(true);
    }
}