package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class Insertar_Vehiculo extends JPanel {
    private JTextField nombreVehiculoTextField;
    private JComboBox<String> idConductorComboBox;
    private JComboBox<String> idMatriculaComboBox;

    // Mapeos para convertir entre nombres y IDs
    private Map<String, String> conductoresMap = new HashMap<>();
    private Map<String, String> matriculasMap = new HashMap<>();

    private JButton insertarButton;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private JButton modificarButton;
    private JButton eliminarButton;
    private ResultSet resultSet;

    public Insertar_Vehiculo() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(70, 116, 166));

        JPanel panelInsercion = new JPanel(new GridBagLayout());
        panelInsercion.setBackground(new Color(70, 116, 166));

        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar Vehículo");
        titledBorder.setTitleColor(Color.WHITE);
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        JLabel tituloNombreVehiculo = new JLabel("Nombre del Vehículo");
        JLabel tituloIdConductor = new JLabel("Conductor");
        JLabel tituloIdMatricula = new JLabel("Matrícula");

        tituloNombreVehiculo.setForeground(Color.WHITE);
        tituloIdConductor.setForeground(Color.WHITE);
        tituloIdMatricula.setForeground(Color.WHITE);

        nombreVehiculoTextField = new JTextField(20);
        idConductorComboBox = new JComboBox<>();
        idMatriculaComboBox = new JComboBox<>();
        cargarConductores();
        cargarMatriculas();

        insertarButton = new JButton("Insertar");
        personalizarBoton(insertarButton);

        GridBagConstraints gbcTituloNombreVehiculo = new GridBagConstraints();
        gbcTituloNombreVehiculo.gridx = 0;
        gbcTituloNombreVehiculo.gridy = 0;
        gbcTituloNombreVehiculo.gridwidth = 2;
        gbcTituloNombreVehiculo.insets = new Insets(0, 0, 10, 0);
        gbcTituloNombreVehiculo.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloIdConductor = new GridBagConstraints();
        gbcTituloIdConductor.gridx = 0;
        gbcTituloIdConductor.gridy = 3;
        gbcTituloIdConductor.gridwidth = 2;
        gbcTituloIdConductor.insets = new Insets(0, 0, 10, 0);
        gbcTituloIdConductor.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloIdMatricula = new GridBagConstraints();
        gbcTituloIdMatricula.gridx = 0;
        gbcTituloIdMatricula.gridy = 6;
        gbcTituloIdMatricula.gridwidth = 2;
        gbcTituloIdMatricula.insets = new Insets(0, 0, 10, 0);
        gbcTituloIdMatricula.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcNombreVehiculo = new GridBagConstraints();
        gbcNombreVehiculo.gridx = 0;
        gbcNombreVehiculo.gridy = 2;
        gbcNombreVehiculo.gridwidth = 2;
        gbcNombreVehiculo.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcIdConductor = new GridBagConstraints();
        gbcIdConductor.gridx = 0;
        gbcIdConductor.gridy = 5;
        gbcIdConductor.gridwidth = 2;
        gbcIdConductor.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcIdMatricula = new GridBagConstraints();
        gbcIdMatricula.gridx = 0;
        gbcIdMatricula.gridy = 8;
        gbcIdMatricula.gridwidth = 2;
        gbcIdMatricula.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcInsertar = new GridBagConstraints();
        gbcInsertar.gridx = 0;
        gbcInsertar.gridy = 9;
        gbcInsertar.gridwidth = 2;

        panelInsercion.add(tituloNombreVehiculo, gbcTituloNombreVehiculo);
        panelInsercion.add(nombreVehiculoTextField, gbcNombreVehiculo);
        panelInsercion.add(tituloIdConductor, gbcTituloIdConductor);
        panelInsercion.add(idConductorComboBox, gbcIdConductor);
        panelInsercion.add(tituloIdMatricula, gbcTituloIdMatricula);
        panelInsercion.add(idMatriculaComboBox, gbcIdMatricula);
        panelInsercion.add(insertarButton, gbcInsertar);

        modificarButton = new JButton("Modificar");
        personalizarBoton(modificarButton);

        eliminarButton = new JButton("Eliminar");
        personalizarBoton(eliminarButton);

        JPanel panelBotonesVehiculo = new JPanel();
        panelBotonesVehiculo.setLayout(new FlowLayout(FlowLayout.RIGHT));
        panelBotonesVehiculo.add(modificarButton);
        panelBotonesVehiculo.add(eliminarButton);

        JPanel panelVisualizacionVehiculo = new JPanel(new BorderLayout());
        panelVisualizacionVehiculo.setBackground(new Color(70, 116, 166));
        JLabel infoLabelVehiculo = new JLabel("Visualización, Modificación y Eliminación de Vehículos");
        infoLabelVehiculo.setForeground(Color.WHITE);
        infoLabelVehiculo.setHorizontalAlignment(SwingConstants.CENTER);
        panelVisualizacionVehiculo.add(infoLabelVehiculo, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return true;
            }
        };
        modeloTabla.addColumn("ID_vehiculo");
        modeloTabla.addColumn("Nombre_vehiculo");
        modeloTabla.addColumn("ID_conductor");
        modeloTabla.addColumn("ID_matricula");
        tablaRegistros = new JTable(modeloTabla);
        JScrollPane scrollPaneVehiculo = new JScrollPane(tablaRegistros);
        panelVisualizacionVehiculo.add(scrollPaneVehiculo, BorderLayout.CENTER);
        panelVisualizacionVehiculo.add(panelBotonesVehiculo, BorderLayout.SOUTH);

        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacionVehiculo);
        splitPaneHorizontal.setResizeWeight(0.2);

        add(splitPaneHorizontal, BorderLayout.CENTER);

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombreVehiculo = nombreVehiculoTextField.getText();
               String idConductor = conductoresMap.get((String) idConductorComboBox.getSelectedItem());
                String idMatricula = matriculasMap.get((String) idMatriculaComboBox.getSelectedItem());
                // Validar que los campos no estén vacíos antes de insertar
                if (!nombreVehiculo.isEmpty() && !idConductor.isEmpty() && !idMatricula.isEmpty()) {
                    insertarVehiculoEnBaseDeDatos(nombreVehiculo, idConductor, idMatricula);
                    limpiarCampos();
                    cargarRegistros();
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, completa todos los campos.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    String idVehiculo = (String) tablaRegistros.getValueAt(filaSeleccionada, 0);
                    String nombreVehiculo = (String) tablaRegistros.getValueAt(filaSeleccionada, 1);
                    String idConductor = conductoresMap.get((String) idConductorComboBox.getSelectedItem());
                String idMatricula = matriculasMap.get((String) idMatriculaComboBox.getSelectedItem());

                    nombreVehiculoTextField.setText(nombreVehiculo);
                    idConductorComboBox.setToolTipText(idConductor);
                    idMatriculaComboBox.setToolTipText(idMatricula);

                    // Implementar la lógica para la modificación en la base de datos
                    modificarVehiculoEnBaseDeDatos(idVehiculo, nombreVehiculo, idConductor, idMatricula);

                    // Después de modificar, limpiar campos y recargar registros
                    limpiarCampos();
                    cargarRegistros();
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    String idVehiculo = (String) tablaRegistros.getValueAt(filaSeleccionada, 0);

                    int opcion = JOptionPane.showConfirmDialog(null,
                            "¿Seguro que quieres eliminar este registro?", "Confirmar eliminación",
                            JOptionPane.YES_NO_OPTION);

                    if (opcion == JOptionPane.YES_OPTION) {
                        // Implementar la lógica para la eliminación en la base de datos
                        eliminarVehiculoEnBaseDeDatos(idVehiculo);

                        // Después de eliminar, limpiar campos y recargar registros
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cargarRegistros();
    }

    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void insertarVehiculoEnBaseDeDatos(String nombreVehiculo, String idConductor, String idMatricula) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL InsertarVehiculo(?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, nombreVehiculo);
            preparedStatement.setString(2, idConductor);
            preparedStatement.setString(3, idMatricula);
            preparedStatement.executeUpdate();
            System.out.println("Vehículo insertado en la base de datos: " + nombreVehiculo);
        } catch (SQLException ex) {
            System.out.println("Error al insertar el vehículo en la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void modificarVehiculoEnBaseDeDatos(String idVehiculo, String nombreVehiculo, String idConductor, String idMatricula) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL ModificarVehiculo(?, ?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, idVehiculo);
            preparedStatement.setString(2, nombreVehiculo);
            preparedStatement.setString(3, idConductor);
            preparedStatement.setString(4, idMatricula);
            preparedStatement.executeUpdate();
            System.out.println("Vehículo modificado en la base de datos: " + nombreVehiculo);
        } catch (SQLException ex) {
            System.out.println("Error al modificar el vehículo en la base de datos: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void eliminarVehiculoEnBaseDeDatos(String idVehiculo) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL EliminarVehiculo(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, idVehiculo);
            preparedStatement.executeUpdate();
            System.out.println("Vehículo eliminado de la base de datos: " + idVehiculo);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el vehículo de la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void cargarConductores() {
        Connection conexion = null;
    
        try {
            // Establecer la conexión a la base de datos
            conexion = ConexionBD.obtenerConexion();
    
            // Consulta SQL para obtener conductores sin matrícula asociada
            String consultaConductores = "SELECT C.ID_conductor, P.Nombre " +
                                         "FROM CONDUCTOR C " +
                                         "INNER JOIN PERSONA P ON C.ID_persona = P.ID_persona " +
                                         "WHERE C.ID_conductor NOT IN (SELECT ID_conductor FROM VEHICULO WHERE ID_matricula IS NOT NULL)";
    
            PreparedStatement preparedStatement = conexion.prepareStatement(consultaConductores);
            ResultSet resultSet = preparedStatement.executeQuery();
    
            // Limpiar y llenar el JComboBox y el mapa de conductores
            idConductorComboBox.removeAllItems();
            conductoresMap.clear();
    
            while (resultSet.next()) {
                String idConductor = resultSet.getString("ID_conductor");
                String nombreConductor = resultSet.getString("Nombre");
    
                idConductorComboBox.addItem(nombreConductor);
                conductoresMap.put(nombreConductor, idConductor);
            }
    
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }
    
    
    private void cargarMatriculas() {
        Connection conexion = null;
    
        try {
            // Establecer la conexión a la base de datos
            conexion = ConexionBD.obtenerConexion();
    
            // Consulta SQL para obtener matrículas
            String consultaMatriculas = "SELECT ID_matricula, Placa_vehicular FROM MATRICULA";
    
            PreparedStatement preparedStatement = conexion.prepareStatement(consultaMatriculas);
            ResultSet resultSet = preparedStatement.executeQuery();
    
            // Limpiar y llenar el JComboBox y el mapa de matrículas
            idMatriculaComboBox.removeAllItems();
            matriculasMap.clear();
    
            while (resultSet.next()) {
                String idMatricula = resultSet.getString("ID_matricula");
                String placa = resultSet.getString("Placa_vehicular");
    
                // Concatenar información y agregar al JComboBox
                String matriculaConPlaca = "Matricula con placa: [" + placa + "]";
                idMatriculaComboBox.addItem(matriculaConPlaca);
    
                // Agregar al mapa de matrículas
                matriculasMap.put(matriculaConPlaca, idMatricula);
            }
    
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }
    

    private void cargarRegistros() {
        cargarRegistrosTabla(tablaRegistros, modeloTabla, "SELECT * FROM VEHICULO");
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0);
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Object[] fila = {resultSet.getString("ID_vehiculo"), resultSet.getString("Nombre_vehiculo"),
                        resultSet.getString("ID_conductor"), resultSet.getString("ID_matricula")};
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void limpiarCampos() {
        nombreVehiculoTextField.setText("");
        idConductorComboBox.setToolTipText("");
        idMatriculaComboBox.setToolTipText("");
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Insertar Vehículo Form");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setSize(800, 600);
        frame.add(new Insertar_Vehiculo());
        frame.setVisible(true);
    }
}
