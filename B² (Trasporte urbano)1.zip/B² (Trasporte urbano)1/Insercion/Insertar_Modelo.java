package Insercion;

import javax.swing.*;

import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Insertar_Modelo extends JPanel {
    private JTextField modeloTextField;
    private JTextArea detalleTextArea;
    private JButton insertarButton;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private JButton modificarButton;
    private JButton eliminarButton;

    private ResultSet resultSet;

    public Insertar_Modelo() {
        // Configurar el formulario de inserción, modificación y eliminación de modelo
        setLayout(new BorderLayout(10, 10)); // Espaciado entre componentes
        setBackground(new Color(70, 116, 166));

        // Panel de inserción con GridBagLayout
        JPanel panelInsercion = new JPanel(new GridBagLayout());
        panelInsercion.setBackground(new Color(70, 116, 166));

        // Crear TitledBorder para el borde titulado
        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar");
        titledBorder.setTitleColor(Color.WHITE); // Color del texto del título
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        // Agregar títulos centrados
        JLabel tituloModelo = new JLabel("Modelo");
        JLabel tituloDetalle = new JLabel("Detalle");
        tituloModelo.setForeground(Color.WHITE);
        tituloDetalle.setForeground(Color.WHITE);

        modeloTextField = new JTextField(20);
        detalleTextArea = new JTextArea(4, 20);
        detalleTextArea.setLineWrap(true);
        detalleTextArea.setWrapStyleWord(true);

        // Limitar la cantidad de caracteres en el JTextArea a 255
        ((AbstractDocument) detalleTextArea.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                    throws BadLocationException {
                String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
                int futureLength = currentText.length() - length + text.length();

                if (futureLength <= 255) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

        insertarButton = new JButton("Insertar");
        personalizarBoton(insertarButton);

        GridBagConstraints gbcTituloModelo = new GridBagConstraints();
        gbcTituloModelo.gridx = 0;
        gbcTituloModelo.gridy = 0;
        gbcTituloModelo.gridwidth = 2;
        gbcTituloModelo.insets = new Insets(0, 0, 10, 0);
        gbcTituloModelo.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloDetalle = new GridBagConstraints();
        gbcTituloDetalle.gridx = 0;
        gbcTituloDetalle.gridy = 3;
        gbcTituloDetalle.gridwidth = 2;
        gbcTituloDetalle.insets = new Insets(0, 0, 10, 0);
        gbcTituloDetalle.anchor = GridBagConstraints.CENTER;

        // Restricciones para el modeloTextField
        GridBagConstraints gbcModelo = new GridBagConstraints();
        gbcModelo.gridx = 0;
        gbcModelo.gridy = 2;
        gbcModelo.gridwidth = 2; // Ocupa 2 columnas
        gbcModelo.insets = new Insets(0, 0, 10, 0); // Márgenes

        // Restricciones para el detalleTextArea
        GridBagConstraints gbcDetalle = new GridBagConstraints();
        gbcDetalle.gridx = 0;
        gbcDetalle.gridy = 4;
        gbcDetalle.gridwidth = 2; // Ocupa 2 columnas
        gbcDetalle.insets = new Insets(0, 0, 10, 0); // Márgenes

        // Restricciones para el insertarButton
        GridBagConstraints gbcInsertar = new GridBagConstraints();
        gbcInsertar.gridx = 0;
        gbcInsertar.gridy = 5;
        gbcInsertar.gridwidth = 2; // Ocupa 2 columnas

        panelInsercion.add(tituloModelo, gbcTituloModelo);
        panelInsercion.add(modeloTextField, gbcModelo);
        panelInsercion.add(tituloDetalle, gbcTituloDetalle);
        panelInsercion.add(detalleTextArea, gbcDetalle);
        panelInsercion.add(insertarButton, gbcInsertar);

        // Botón de modificación
        modificarButton = new JButton("Modificar");
        personalizarBoton(modificarButton);

        // Botón de eliminación
        eliminarButton = new JButton("Eliminar");
        personalizarBoton(eliminarButton);

        // Panel para los botones de modificación y eliminación
        JPanel panelBotonesModelo = new JPanel();
        panelBotonesModelo.setLayout(new FlowLayout(FlowLayout.RIGHT)); // Usar FlowLayout para alinear a la derecha
        panelBotonesModelo.add(modificarButton);
        panelBotonesModelo.add(eliminarButton);

        // Panel de visualización y modificación
        JPanel panelVisualizacionModelo = new JPanel(new BorderLayout());
        panelVisualizacionModelo.setBackground(new Color(70, 116, 166));
        JLabel infoLabelModelo = new JLabel("Visualización, Modificación y Eliminación");
        infoLabelModelo.setForeground(Color.WHITE); // Color del texto
        infoLabelModelo.setHorizontalAlignment(SwingConstants.CENTER); // Centrar el texto
        panelVisualizacionModelo.add(infoLabelModelo, BorderLayout.NORTH);

        // Tabla para mostrar registros
        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Hacer que la columna de ID no sea editable
                return column != 0; // 0 es el índice de la columna ID_modelo
            }
        };
        modeloTabla.addColumn("ID_modelo");
        modeloTabla.addColumn("Modelo");
        modeloTabla.addColumn("Detalle");
        tablaRegistros = new JTable(modeloTabla);
        JScrollPane scrollPaneModelo = new JScrollPane(tablaRegistros);
        panelVisualizacionModelo.add(scrollPaneModelo, BorderLayout.CENTER);
        panelVisualizacionModelo.add(panelBotonesModelo, BorderLayout.SOUTH); // Agregar el panel de botones a la parte
                                                                              // inferior

        // Espacio entre paneles

        // Crear JSplitPane horizontal para dividir el formulario en dos partes
        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacionModelo);
        splitPaneHorizontal.setResizeWeight(0.2);

        // Agregar el JSplitPane a la ventana principal
        add(splitPaneHorizontal, BorderLayout.CENTER);

        // Configurar el manejador de eventos para los botones
        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String modelo = modeloTextField.getText();
                String detalle = detalleTextArea.getText();
                insertarModeloEnBaseDeDatos(modelo, detalle);
                limpiarCampos();
                cargarRegistros();
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    // Obtener valores de la fila seleccionada
                    int idModelo = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);
                    String modeloSeleccionado = (String) tablaRegistros.getValueAt(filaSeleccionada, 1);
                    String detalleSeleccionado = (String) tablaRegistros.getValueAt(filaSeleccionada, 2);

                    // Poblar los campos de inserción con los valores seleccionados
                    modeloTextField.setText(modeloSeleccionado);
                    detalleTextArea.setText(detalleSeleccionado);

                    // Implementar la lógica para modificar el registro en la base de datos
                    if (modificarRegistroEnBaseDeDatos(idModelo, modeloSeleccionado, detalleSeleccionado)) {
                        // Limpiar campos después de la modificación
                        limpiarCampos();
                        // Recargar registros en la tabla
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    // Obtener el ID del modelo seleccionado en la tabla
                    int idModelo = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);

                    // Preguntar al usuario para confirmar la eliminación
                    int opcion = JOptionPane.showConfirmDialog(null, "¿Seguro que quieres eliminar este registro?",
                            "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

                    // Implementar la lógica para eliminar el registro seleccionado
                    if (opcion == JOptionPane.YES_OPTION) {
                        eliminarRegistroEnBaseDeDatos(idModelo);
                        // Limpiar campos después de la eliminación
                        limpiarCampos();
                        // Recargar registros en la tabla
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Cargar registros al inicializar el formulario
        cargarRegistros();
    }

    // Método para personalizar un botón
    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140)); // Color de fondo
        boton.setForeground(Color.WHITE); // Color del texto
        boton.setFocusPainted(false); // Evitar que se pinte el borde al obtener el foco
        boton.setFont(new Font("Arial", Font.BOLD, 14)); // Fuente y tamaño del texto
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16)); // Márgenes internos
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR)); // Cambiar el cursor al pasar sobre el botón
    }

    private boolean modificarRegistroEnBaseDeDatos(int idModelo, String nuevoModelo, String nuevoDetalle) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL ModificarModelo(?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idModelo);
            preparedStatement.setString(2, nuevoModelo);
            preparedStatement.setString(3, nuevoDetalle);
            preparedStatement.executeUpdate();
            System.out.println("Modelo modificado en la base de datos: " + nuevoModelo);
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al modificar el modelo en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private boolean eliminarRegistroEnBaseDeDatos(int idModelo) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL EliminarModelo(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idModelo);
            preparedStatement.executeUpdate();
            System.out.println("Modelo eliminado de la base de datos con ID: " + idModelo);
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el modelo en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void cargarRegistros() {
        cargarRegistrosTabla(tablaRegistros, modeloTabla, "SELECT * FROM MODELO");
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0); // Limpiar la tabla
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Object[] fila = { resultSet.getInt("ID_modelo"), resultSet.getString("Modelo"),
                        resultSet.getString("Detalle") };
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void insertarModeloEnBaseDeDatos(String modelo, String detalle) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL InsertarModelo(?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, modelo);
            preparedStatement.setString(2, detalle);
            preparedStatement.executeUpdate();
            System.out.println("Modelo insertado en la base de datos: " + modelo);
        } catch (SQLException ex) {
            System.out.println("Error al insertar el modelo en la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void limpiarCampos() {
        modeloTextField.setText("");
        detalleTextArea.setText("");
    }

    public static void main(String[] args) {
        // Puedes agregar un JFrame para probar el formulario
        JFrame frame = new JFrame("Insertar Modelo Form");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar la ventana
        frame.setSize(800, 600); // Ajustar el tamaño del formulario
        frame.add(new Insertar_Modelo());
        frame.setVisible(true);
    }
}