package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Insertar_Color extends JPanel {
    private JTextField colorTextField;
    private JButton insertarButton;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private JButton modificarButton;
    private JButton eliminarButton;

    private ResultSet resultSet;

    public Insertar_Color() {
        // Configurar el formulario de inserción, modificación y eliminación de color
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(70, 116, 166));

        // Panel de inserción
        JPanel panelInsercion = new JPanel(new FlowLayout());
        // Color de fondo para el panel de inserción
        panelInsercion.setBackground(new Color(70, 116, 166));

        // Crear TitledBorder para el borde titulado
        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar");
        titledBorder.setTitleColor(Color.WHITE); // Color del texto del título
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        colorTextField = new JTextField(15);
        insertarButton = new JButton("Insertar");
        panelInsercion.add(new JLabel("Color: "));
        panelInsercion.add(colorTextField);
        panelInsercion.add(insertarButton);



        // Botón de modificación
        modificarButton = new JButton("Modificar");

        // Botón de eliminación
        eliminarButton = new JButton("Eliminar");

        // Panel para los botones de modificación y eliminación
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new FlowLayout(FlowLayout.RIGHT)); // Usar FlowLayout para alinear a la derecha
        panelBotones.add(modificarButton);
        panelBotones.add(eliminarButton);

        // Panel de visualización y modificación
        JPanel panelVisualizacion = new JPanel(new BorderLayout());
        // Color de fondo para el panel de visualización y modificación
        panelVisualizacion.setBackground(new Color(70, 116, 166));
        JLabel infoLabelModelo = new JLabel("Visualización, Modificación y Eliminación");
        infoLabelModelo.setForeground(Color.WHITE); // Color del texto
        infoLabelModelo.setHorizontalAlignment(SwingConstants.CENTER); // Centrar el texto
        panelVisualizacion.add(infoLabelModelo, BorderLayout.NORTH);

        // Tabla para mostrar registros
        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Hacer que la columna de ID no sea editable
                return column != 0; // 0 es el índice de la columna ID_modelo
            }
        };
        modeloTabla.addColumn("ID_color");
        modeloTabla.addColumn("Color");
        tablaRegistros = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaRegistros);
        panelVisualizacion.add(scrollPane, BorderLayout.CENTER);
        panelVisualizacion.add(panelBotones, BorderLayout.SOUTH); // Agregar el panel de botones a la parte inferior

        

        // Espacio entre paneles
        // panelVisualizacion.setBorder(BorderFactory.createEmptyBorder(50, 50, 10, 10));

        // Crear JSplitPane horizontal para dividir el formulario en dos partes
        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacion);
        splitPaneHorizontal.setResizeWeight(0.2);

        // Agregar el JSplitPane a la ventana principal
        add(splitPaneHorizontal, BorderLayout.CENTER);

        // Configurar el manejador de eventos para los botones
        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String color = colorTextField.getText();
                insertarColorEnBaseDeDatos(color);
                limpiarCampos();
                cargarRegistros();
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    // Obtener valores de la fila seleccionada
                    int idColor = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);
                    String colorSeleccionado = (String) tablaRegistros.getValueAt(filaSeleccionada, 1);

                    // Poblar los campos de inserción con los valores seleccionados
                    colorTextField.setText(colorSeleccionado);

                    // Implementar la lógica para modificar el registro en la base de datos
                    if (modificarRegistroEnBaseDeDatos(idColor, colorSeleccionado)) {
                        // Limpiar campos después de la modificación
                        limpiarCampos();
                        // Recargar registros en las tablas
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener la fila seleccionada de la tabla
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                // Verificar si hay una fila seleccionada
                if (filaSeleccionada != -1) {
                    // Obtener el ID_color del registro seleccionado
                    int idcolor = (int) modeloTabla.getValueAt(filaSeleccionada, 0);

                    // Preguntar al usuario para confirmar la eliminación
                    int opcion = JOptionPane.showConfirmDialog(null, "¿Seguro que quieres eliminar este registro?",
                            "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

                    if (opcion == JOptionPane.YES_OPTION) {
                        // Llamar al procedimiento almacenado para eliminar el registro
                        eliminarColorEnBaseDeDatos(idcolor);

                        // Actualizar las tablas después de la eliminación
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Selecciona un registro para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Cargar registros al inicializar el formulario
        cargarRegistros();
    }

    private boolean modificarRegistroEnBaseDeDatos(int idColor, String nuevoColor) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL ModificarColor(?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idColor);
            preparedStatement.setString(2, nuevoColor);
            preparedStatement.executeUpdate();
            System.out.println("Color modificado en la base de datos: " + nuevoColor);
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al modificar el color en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    // Método para eliminar un registro en la base de datos
    private void eliminarColorEnBaseDeDatos(int idcolor) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL EliminarColor(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idcolor);
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el color en la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void cargarRegistros() {
        cargarRegistrosTabla(tablaRegistros, modeloTabla, "SELECT * FROM COLOR");
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0); // Limpiar la tabla
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Object[] fila = {resultSet.getInt("ID_color"), resultSet.getString("Color")};
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void insertarColorEnBaseDeDatos(String color) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL InsertarColor(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, color);
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error al insertar el color en la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void limpiarCampos() {
        colorTextField.setText("");
    }


    public static void main(String[] args) {
        // Puedes agregar un JFrame para probar el formulario
        JFrame frame = new JFrame("Insertar Color Form");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600); // Ajustar el tamaño del formulario
        frame.add(new Insertar_Color());
        frame.setVisible(true);
    }
}
