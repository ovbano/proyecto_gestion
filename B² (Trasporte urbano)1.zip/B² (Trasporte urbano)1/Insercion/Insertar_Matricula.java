package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Insertar_Matricula extends JPanel {
    private JTextField placaTextField;
    private JTextField propietarioTextField;
    private JTextField capacidadTextField;
    private JTextField marcaTextField;
    private JTextField colorTextField;
    private JTextField modeloTextField;
    private JButton insertarButton;
    private JButton modificarButton;
    private JButton eliminarButton;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;

    public Insertar_Matricula() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(70, 116, 166));

        JPanel panelInsercion = new JPanel(new GridBagLayout());
        panelInsercion.setBackground(new Color(70, 116, 166));

        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar Matrícula");
        titledBorder.setTitleColor(Color.WHITE);
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        JLabel placaLabel = new JLabel("Placa:");
        JLabel propietarioLabel = new JLabel("Nombre Propietario:");
        JLabel capacidadLabel = new JLabel("Capacidad Pasajeros:");
        JLabel marcaLabel = new JLabel("ID Marca:");
        JLabel colorLabel = new JLabel("ID Color:");
        JLabel modeloLabel = new JLabel("ID Modelo:");

        placaTextField = new JTextField(20);
        propietarioTextField = new JTextField(20);
        capacidadTextField = new JTextField(20);
        marcaTextField = new JTextField(20);
        colorTextField = new JTextField(20);
        modeloTextField = new JTextField(20);

        insertarButton = new JButton("Insertar");
        personalizarBoton(insertarButton);

        modificarButton = new JButton("Modificar");
        personalizarBoton(modificarButton);

        eliminarButton = new JButton("Eliminar");
        personalizarBoton(eliminarButton);

        GridBagConstraints gbcPlacaLabel = new GridBagConstraints();
        gbcPlacaLabel.gridx = 0;
        gbcPlacaLabel.gridy = 0;
        gbcPlacaLabel.insets = new Insets(0, 0, 10, 5);
        gbcPlacaLabel.anchor = GridBagConstraints.WEST;

        GridBagConstraints gbcPlacaTextField = new GridBagConstraints();
        gbcPlacaTextField.gridx = 0;
        gbcPlacaTextField.gridy = 1;
        gbcPlacaTextField.insets = new Insets(0, 0, 10, 0);
        gbcPlacaTextField.anchor = GridBagConstraints.WEST;

        GridBagConstraints gbcPropietarioLabel = new GridBagConstraints();
        gbcPropietarioLabel.gridx = 0;
        gbcPropietarioLabel.gridy = 2;
        gbcPropietarioLabel.insets = new Insets(0, 0, 10, 5);
        gbcPropietarioLabel.anchor = GridBagConstraints.WEST;

        GridBagConstraints gbcPropietarioTextField = new GridBagConstraints();
        gbcPropietarioTextField.gridx = 0;
        gbcPropietarioTextField.gridy = 3;
        gbcPropietarioTextField.insets = new Insets(0, 0, 10, 0);
        gbcPropietarioTextField.anchor = GridBagConstraints.WEST;

        GridBagConstraints gbcCapacidadLabel = new GridBagConstraints();
        gbcCapacidadLabel.gridx = 0;
        gbcCapacidadLabel.gridy = 4;
        gbcCapacidadLabel.insets = new Insets(0, 0, 10, 5);
        gbcCapacidadLabel.anchor = GridBagConstraints.WEST;

        GridBagConstraints gbcCapacidadTextField = new GridBagConstraints();
        gbcCapacidadTextField.gridx = 0;
        gbcCapacidadTextField.gridy = 5;
        gbcCapacidadTextField.insets = new Insets(0, 0, 10, 0);
        gbcCapacidadTextField.anchor = GridBagConstraints.WEST;

        GridBagConstraints gbcMarcaLabel = new GridBagConstraints();
        gbcMarcaLabel.gridx = 0;
        gbcMarcaLabel.gridy = 6;
        gbcMarcaLabel.insets = new Insets(0, 0, 10, 5);
        gbcMarcaLabel.anchor = GridBagConstraints.WEST;

        GridBagConstraints gbcMarcaTextField = new GridBagConstraints();
        gbcMarcaTextField.gridx = 0;
        gbcMarcaTextField.gridy = 7;
        gbcMarcaTextField.insets = new Insets(0, 0, 10, 0);
        gbcMarcaTextField.anchor = GridBagConstraints.WEST;

        GridBagConstraints gbcColorLabel = new GridBagConstraints();
        gbcColorLabel.gridx = 0;
        gbcColorLabel.gridy = 8;
        gbcColorLabel.insets = new Insets(0, 0, 10, 5);
        gbcColorLabel.anchor = GridBagConstraints.WEST;

        GridBagConstraints gbcColorTextField = new GridBagConstraints();
        gbcColorTextField.gridx = 0;
        gbcColorTextField.gridy = 9;
        gbcColorTextField.insets = new Insets(0, 0, 10, 0);
        gbcColorTextField.anchor = GridBagConstraints.WEST;

        GridBagConstraints gbcModeloLabel = new GridBagConstraints();
        gbcModeloLabel.gridx = 0;
        gbcModeloLabel.gridy = 10;
        gbcModeloLabel.insets = new Insets(0, 0, 10, 5);
        gbcModeloLabel.anchor = GridBagConstraints.WEST;

        GridBagConstraints gbcModeloTextField = new GridBagConstraints();
        gbcModeloTextField.gridx = 0;
        gbcModeloTextField.gridy = 11;
        gbcModeloTextField.insets = new Insets(0, 0, 10, 0);
        gbcModeloTextField.anchor = GridBagConstraints.WEST;

        GridBagConstraints gbcInsertar = new GridBagConstraints();
        gbcInsertar.gridx = 0;
        gbcInsertar.gridy = 12;
        gbcInsertar.gridwidth = 2;
        gbcInsertar.insets = new Insets(20, 0, 0, 0);
        gbcInsertar.anchor = GridBagConstraints.CENTER;

        panelInsercion.add(placaLabel, gbcPlacaLabel);
        panelInsercion.add(placaTextField, gbcPlacaTextField);
        panelInsercion.add(propietarioLabel, gbcPropietarioLabel);
        panelInsercion.add(propietarioTextField, gbcPropietarioTextField);
        panelInsercion.add(capacidadLabel, gbcCapacidadLabel);
        panelInsercion.add(capacidadTextField, gbcCapacidadTextField);
        panelInsercion.add(marcaLabel, gbcMarcaLabel);
        panelInsercion.add(marcaTextField, gbcMarcaTextField);
        panelInsercion.add(colorLabel, gbcColorLabel);
        panelInsercion.add(colorTextField, gbcColorTextField);
        panelInsercion.add(modeloLabel, gbcModeloLabel);
        panelInsercion.add(modeloTextField, gbcModeloTextField);
        panelInsercion.add(insertarButton, gbcInsertar);

        modificarButton = new JButton("Modificar");
        personalizarBoton(modificarButton);

        eliminarButton = new JButton("Eliminar");
        personalizarBoton(eliminarButton);

        JPanel panelBotonesMatricula = new JPanel();
        panelBotonesMatricula.setLayout(new FlowLayout(FlowLayout.RIGHT));
        panelBotonesMatricula.add(modificarButton);
        panelBotonesMatricula.add(eliminarButton);

        // Crear modelo para la tabla
        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return true;
            }
        };
        modeloTabla.addColumn("ID_matricula");
        modeloTabla.addColumn("Placa_vehicular");
        modeloTabla.addColumn("Nombre_propietario");
        modeloTabla.addColumn("Capacidad_pasajeros");
        modeloTabla.addColumn("ID_marca");
        modeloTabla.addColumn("ID_color");
        modeloTabla.addColumn("ID_modelo");

        tablaRegistros = new JTable(modeloTabla);
        JScrollPane scrollPaneMatricula = new JScrollPane(tablaRegistros);

        // Agregar el JScrollPane al panel izquierdo
        JPanel panelVisualizacionMatricula = new JPanel(new BorderLayout());
        panelVisualizacionMatricula.setBackground(new Color(70, 116, 166));
        JLabel infoLabelMatricula = new JLabel("Visualización, Modificación y Eliminación de Matrículas");
        infoLabelMatricula.setForeground(Color.WHITE);
        infoLabelMatricula.setHorizontalAlignment(SwingConstants.CENTER);
        panelVisualizacionMatricula.add(infoLabelMatricula, BorderLayout.NORTH);
        panelVisualizacionMatricula.add(scrollPaneMatricula, BorderLayout.CENTER);
        panelVisualizacionMatricula.add(panelBotonesMatricula, BorderLayout.SOUTH);

        // Configurar acciones para los botones
        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                insertarMatricula();
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modificarMatricula();
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarMatricula();
            }
        });

        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacionMatricula);
        splitPaneHorizontal.setResizeWeight(0.2);

        add(splitPaneHorizontal, BorderLayout.CENTER);

        // Cargar registros al inicio
        cargarRegistros();
    }

    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void insertarMatricula() {
        String placa = placaTextField.getText();
        String propietario = propietarioTextField.getText();
        String capacidadStr = capacidadTextField.getText();
        String marcaStr = marcaTextField.getText();
        String colorStr = colorTextField.getText();
        String modeloStr = modeloTextField.getText();
    
        // Validaciones
        if (placa.isEmpty() || propietario.isEmpty() || capacidadStr.isEmpty() ||
                marcaStr.isEmpty() || colorStr.isEmpty() || modeloStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        try {
            int capacidad = Integer.parseInt(capacidadStr);
            int marca = Integer.parseInt(marcaStr);
            int color = Integer.parseInt(colorStr);
            int modelo = Integer.parseInt(modeloStr);
    
            // Validación de la capacidad
            if (capacidad <= 0) {
                JOptionPane.showMessageDialog(this, "La capacidad debe ser mayor a 0.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            // Validación de la unicidad de la Placa_vehicular
            if (!verificarUnicidadPlaca(placa)) {
                JOptionPane.showMessageDialog(this, "La Placa_vehicular debe ser única.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            // Insertar en la base de datos
            Connection conexion = null;
    
            try {
                conexion = ConexionBD.obtenerConexion();
                String procedimientoAlmacenado = "{CALL InsertarMatricula(?, ?, ?, ?, ?, ?)}";
    
                PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
                preparedStatement.setString(1, placa);
                preparedStatement.setString(2, propietario);
                preparedStatement.setInt(3, capacidad);
                preparedStatement.setInt(4, marca);
                preparedStatement.setInt(5, color);
                preparedStatement.setInt(6, modelo);
    
                preparedStatement.executeUpdate();
    
                // Limpiar campos y recargar registros
                limpiarCampos();
                cargarRegistros();
    
                JOptionPane.showMessageDialog(this, "Matrícula insertada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error al insertar la matrícula en la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            } finally {
                ConexionBD.cerrarConexion(conexion);
            }
    
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, ingresa valores numéricos válidos en los campos correspondientes.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private boolean verificarUnicidadPlaca(String placa) {
        Connection conexion = null;
    
        try {
            conexion = ConexionBD.obtenerConexion();
            String consulta = "SELECT COUNT(*) FROM MATRICULA WHERE Placa_vehicular = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            preparedStatement.setString(1, placa);
    
            ResultSet resultSet = preparedStatement.executeQuery();
    
            if (resultSet.next()) {
                int cantidad = resultSet.getInt(1);
                return cantidad == 0;  // Si cantidad es 0, la Placa_vehicular es única
            }
    
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    
        return false;  // En caso de error, consideramos que la Placa_vehicular no es única
    }

    private void modificarMatricula() {
        int filaSeleccionada = tablaRegistros.getSelectedRow();
    
        if (filaSeleccionada != -1) {
            Integer idMatriculaInteger = (Integer) tablaRegistros.getValueAt(filaSeleccionada, 0);
            String idMatricula = idMatriculaInteger.toString();
            String placa = (String) tablaRegistros.getValueAt(filaSeleccionada, 1);
            String propietario = (String) tablaRegistros.getValueAt(filaSeleccionada, 2);
            Integer capacidad = (Integer) tablaRegistros.getValueAt(filaSeleccionada, 3);
            Integer marca = (Integer) tablaRegistros.getValueAt(filaSeleccionada, 4);
            Integer color = (Integer) tablaRegistros.getValueAt(filaSeleccionada, 5);
            Integer modelo = (Integer) tablaRegistros.getValueAt(filaSeleccionada, 6);
    
            // Validaciones adicionales utilizando los datos de la tabla
            // Por ejemplo, puedes comprobar si la nueva placa ya existe en la tabla
            if (!validarPlacaUnica(idMatricula, placa)) {
                JOptionPane.showMessageDialog(this, "La placa ya está registrada.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            // Actualizar en la base de datos
            Connection conexion = null;
    
            try {
                conexion = ConexionBD.obtenerConexion();
                String procedimientoAlmacenado = "{CALL ModificarMatricula(?, ?, ?, ?, ?, ?, ?)}";
    
                PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
                preparedStatement.setString(1, idMatricula);
                preparedStatement.setString(2, placa);
                preparedStatement.setString(3, propietario);
                preparedStatement.setInt(4, capacidad);
                preparedStatement.setInt(5, marca);
                preparedStatement.setInt(6, color);
                preparedStatement.setInt(7, modelo);
    
                preparedStatement.executeUpdate();
    
                // Limpiar campos y recargar registros
                limpiarCampos();
                cargarRegistros();
    
                JOptionPane.showMessageDialog(this, "Matrícula modificada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error al modificar la matrícula en la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            } finally {
                ConexionBD.cerrarConexion(conexion);
            }
    
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, selecciona una fila para modificar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    
    // Método para validar que la placa sea única en la tabla MATRICULA
    private boolean validarPlacaUnica(String idMatricula, String nuevaPlaca) {
        Connection conexion = null;
    
        try {
            conexion = ConexionBD.obtenerConexion();
            String consulta = "SELECT COUNT(*) FROM MATRICULA WHERE Placa_vehicular = ? AND ID_matricula <> ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            preparedStatement.setString(1, nuevaPlaca);
            preparedStatement.setString(2, idMatricula);
    
            ResultSet resultSet = preparedStatement.executeQuery();
            resultSet.next();
            int count = resultSet.getInt(1);
    
            return count == 0;  // Si count es 0, la placa es única; si es mayor a 0, ya existe
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }
    
    

    private void eliminarMatricula() {
        int filaSeleccionada = tablaRegistros.getSelectedRow();
    
        if (filaSeleccionada != -1) {
            String idMatricula = (String) tablaRegistros.getValueAt(filaSeleccionada, 0).toString();
    
            int opcion = JOptionPane.showConfirmDialog(this, "¿Seguro que quieres eliminar este registro?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
    
            if (opcion == JOptionPane.YES_OPTION) {
                // Eliminar en la base de datos
                Connection conexion = null;
    
                try {
                    conexion = ConexionBD.obtenerConexion();
                    String procedimientoAlmacenado = "{CALL EliminarMatricula(?)}";
    
                    PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
                    preparedStatement.setString(1, idMatricula);
    
                    preparedStatement.executeUpdate();
    
                    // Limpiar campos y recargar registros
                    limpiarCampos();
                    cargarRegistros();
    
                    JOptionPane.showMessageDialog(this, "Matrícula eliminada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Error al eliminar la matrícula de la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                } finally {
                    ConexionBD.cerrarConexion(conexion);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, selecciona una fila para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

    // Método para cargar registros desde la base de datos a la tabla
    private void cargarRegistros() {
        cargarRegistrosTabla(tablaRegistros, modeloTabla, "SELECT * FROM MATRICULA");
    }

    // Método para cargar registros en la tabla
    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0);
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Object[] fila = {
                        resultSet.getInt("ID_matricula"),
                        resultSet.getString("Placa_vehicular"),
                        resultSet.getString("Nombre_propietario"),
                        resultSet.getInt("Capacidad_pasajeros"),
                        resultSet.getInt("ID_marca"),
                        resultSet.getInt("ID_color"),
                        resultSet.getInt("ID_modelo")
                };
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void limpiarCampos() {
        placaTextField.setText("");
        propietarioTextField.setText("");
        capacidadTextField.setText("");
        marcaTextField.setText("");
        colorTextField.setText("");
        modeloTextField.setText("");
    }
    

    public static void main(String[] args) {
        JFrame frame = new JFrame("Insertar Matrícula Form");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new Insertar_Matricula());
        frame.setVisible(true);
    }
}
