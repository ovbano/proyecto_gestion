package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Insertar_Mantenimiento extends JPanel {
    private JTextField tipoMantenimientoTextField;
    private JTextArea descripcionTextArea;
    private JTextField costoMantenimientoTextField;
    private JButton insertarButton;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private JButton modificarButton;
    private JButton eliminarButton;

    private ResultSet resultSet;

    public Insertar_Mantenimiento() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(70, 116, 166));

        JPanel panelInsercion = new JPanel(new GridBagLayout());
        panelInsercion.setBackground(new Color(70, 116, 166));

        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar");
        titledBorder.setTitleColor(Color.WHITE);
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        JLabel tituloTipoMantenimiento = new JLabel("Tipo de Mantenimiento");
        JLabel tituloDescripcion = new JLabel("Descripción");
        JLabel tituloCostoMantenimiento = new JLabel("Costo de Mantenimiento");

        tituloTipoMantenimiento.setForeground(Color.WHITE);
        tituloDescripcion.setForeground(Color.WHITE);
        tituloCostoMantenimiento.setForeground(Color.WHITE);

        tipoMantenimientoTextField = new JTextField(20);
        descripcionTextArea = new JTextArea(4, 20);
        costoMantenimientoTextField = new JTextField(20);

        descripcionTextArea.setLineWrap(true);
        descripcionTextArea.setWrapStyleWord(true);

        ((AbstractDocument) descripcionTextArea.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                    throws BadLocationException {
                String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
                int futureLength = currentText.length() - length + text.length();

                if (futureLength <= 255) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

        insertarButton = new JButton("Insertar");
        personalizarBoton(insertarButton);

        GridBagConstraints gbcTituloTipoMantenimiento = new GridBagConstraints();
        gbcTituloTipoMantenimiento.gridx = 0;
        gbcTituloTipoMantenimiento.gridy = 0;
        gbcTituloTipoMantenimiento.gridwidth = 2;
        gbcTituloTipoMantenimiento.insets = new Insets(0, 0, 10, 0);
        gbcTituloTipoMantenimiento.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloDescripcion = new GridBagConstraints();
        gbcTituloDescripcion.gridx = 0;
        gbcTituloDescripcion.gridy = 3;
        gbcTituloDescripcion.gridwidth = 2;
        gbcTituloDescripcion.insets = new Insets(0, 0, 10, 0);
        gbcTituloDescripcion.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloCostoMantenimiento = new GridBagConstraints();
        gbcTituloCostoMantenimiento.gridx = 0;
        gbcTituloCostoMantenimiento.gridy = 6;
        gbcTituloCostoMantenimiento.gridwidth = 2;
        gbcTituloCostoMantenimiento.insets = new Insets(0, 0, 10, 0);
        gbcTituloCostoMantenimiento.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTipoMantenimiento = new GridBagConstraints();
        gbcTipoMantenimiento.gridx = 0;
        gbcTipoMantenimiento.gridy = 2;
        gbcTipoMantenimiento.gridwidth = 2;
        gbcTipoMantenimiento.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcDescripcion = new GridBagConstraints();
        gbcDescripcion.gridx = 0;
        gbcDescripcion.gridy = 5;
        gbcDescripcion.gridwidth = 2;
        gbcDescripcion.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcCostoMantenimiento = new GridBagConstraints();
        gbcCostoMantenimiento.gridx = 0;
        gbcCostoMantenimiento.gridy = 8;
        gbcCostoMantenimiento.gridwidth = 2;
        gbcCostoMantenimiento.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcInsertar = new GridBagConstraints();
        gbcInsertar.gridx = 0;
        gbcInsertar.gridy = 9;
        gbcInsertar.gridwidth = 2;

        panelInsercion.add(tituloTipoMantenimiento, gbcTituloTipoMantenimiento);
        panelInsercion.add(tipoMantenimientoTextField, gbcTipoMantenimiento);
        panelInsercion.add(tituloDescripcion, gbcTituloDescripcion);
        panelInsercion.add(descripcionTextArea, gbcDescripcion);
        panelInsercion.add(tituloCostoMantenimiento, gbcTituloCostoMantenimiento);
        panelInsercion.add(costoMantenimientoTextField, gbcCostoMantenimiento);
        panelInsercion.add(insertarButton, gbcInsertar);

        modificarButton = new JButton("Modificar");
        personalizarBoton(modificarButton);

        eliminarButton = new JButton("Eliminar");
        personalizarBoton(eliminarButton);

        JPanel panelBotonesMantenimiento = new JPanel();
        panelBotonesMantenimiento.setLayout(new FlowLayout(FlowLayout.RIGHT));
        panelBotonesMantenimiento.add(modificarButton);
        panelBotonesMantenimiento.add(eliminarButton);

        JPanel panelVisualizacionMantenimiento = new JPanel(new BorderLayout());
        panelVisualizacionMantenimiento.setBackground(new Color(70, 116, 166));
        JLabel infoLabelMantenimiento = new JLabel("Visualización, Modificación y Eliminación");
        infoLabelMantenimiento.setForeground(Color.WHITE);
        infoLabelMantenimiento.setHorizontalAlignment(SwingConstants.CENTER);
        panelVisualizacionMantenimiento.add(infoLabelMantenimiento, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0; // 0 es el índice de la columna ID_mantenimiento
            }
        };
        modeloTabla.addColumn("ID_mantenimiento");
        modeloTabla.addColumn("Tipo_mantenimiento");
        modeloTabla.addColumn("Descripcion");
        modeloTabla.addColumn("Costo_mantenimiento");
        tablaRegistros = new JTable(modeloTabla);
        JScrollPane scrollPaneMantenimiento = new JScrollPane(tablaRegistros);
        panelVisualizacionMantenimiento.add(scrollPaneMantenimiento, BorderLayout.CENTER);
        panelVisualizacionMantenimiento.add(panelBotonesMantenimiento, BorderLayout.SOUTH);

        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacionMantenimiento);
        splitPaneHorizontal.setResizeWeight(0.2);

        add(splitPaneHorizontal, BorderLayout.CENTER);

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tipoMantenimiento = tipoMantenimientoTextField.getText();
                String descripcion = descripcionTextArea.getText();
                String costoMantenimientoText = costoMantenimientoTextField.getText();

                // Validar que el costo sea un número decimal válido
                try {
                    double costoMantenimiento = Double.parseDouble(costoMantenimientoText);
                    insertarMantenimientoEnBaseDeDatos(tipoMantenimiento, descripcion, costoMantenimiento);
                    limpiarCampos();
                    cargarRegistros();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, introduce un costo de mantenimiento válido.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    int idMantenimiento = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);
                    String tipoMantenimientoSeleccionado = (String) tablaRegistros.getValueAt(filaSeleccionada, 1);
                    String descripcionSeleccionada = (String) tablaRegistros.getValueAt(filaSeleccionada, 2);
                    double costoMantenimientoSeleccionado = (double) tablaRegistros.getValueAt(filaSeleccionada, 3);

                    tipoMantenimientoTextField.setText(tipoMantenimientoSeleccionado);
                    descripcionTextArea.setText(descripcionSeleccionada);
                    costoMantenimientoTextField.setText(String.valueOf(costoMantenimientoSeleccionado));

                    if (modificarRegistroEnBaseDeDatos(idMantenimiento, tipoMantenimientoSeleccionado,
                            descripcionSeleccionada, costoMantenimientoSeleccionado)) {
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    int idMantenimiento = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);

                    int opcion = JOptionPane.showConfirmDialog(null,
                            "¿Seguro que quieres eliminar este registro?", "Confirmar eliminación",
                            JOptionPane.YES_NO_OPTION);

                    if (opcion == JOptionPane.YES_OPTION) {
                        eliminarRegistroEnBaseDeDatos(idMantenimiento);
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cargarRegistros();
    }

    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private boolean modificarRegistroEnBaseDeDatos(int idMantenimiento, String nuevoTipoMantenimiento,
            String nuevaDescripcion, double nuevoCostoMantenimiento) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL ModificarMantenimiento(?, ?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idMantenimiento);
            preparedStatement.setString(2, nuevoTipoMantenimiento);
            preparedStatement.setString(3, nuevaDescripcion);
            preparedStatement.setDouble(4, nuevoCostoMantenimiento);
            preparedStatement.executeUpdate();
            System.out.println("Mantenimiento modificado en la base de datos: " + nuevoTipoMantenimiento);
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al modificar el mantenimiento en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private boolean eliminarRegistroEnBaseDeDatos(int idMantenimiento) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL EliminarMantenimiento(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idMantenimiento);
            preparedStatement.executeUpdate();
            System.out.println("Mantenimiento eliminado de la base de datos con ID: " + idMantenimiento);
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el mantenimiento en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void cargarRegistros() {
        cargarRegistrosTabla(tablaRegistros, modeloTabla, "SELECT * FROM MANTENIMIENTO");
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0);
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Object[] fila = { resultSet.getInt("ID_mantenimiento"), resultSet.getString("Tipo_mantenimiento"),
                        resultSet.getString("Descripcion"), resultSet.getDouble("Costo_mantenimiento") };
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void insertarMantenimientoEnBaseDeDatos(String tipoMantenimiento, String descripcion,
            double costoMantenimiento) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL InsertarMantenimiento(?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, tipoMantenimiento);
            preparedStatement.setString(2, descripcion);
            preparedStatement.setDouble(3, costoMantenimiento);
            preparedStatement.executeUpdate();
            System.out.println("Mantenimiento insertado en la base de datos: " + tipoMantenimiento);
        } catch (SQLException ex) {
            System.out.println("Error al insertar el mantenimiento en la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void limpiarCampos() {
        tipoMantenimientoTextField.setText("");
        descripcionTextArea.setText("");
        costoMantenimientoTextField.setText("");
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Insertar Mantenimiento Form");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setSize(800, 600);
        frame.add(new Insertar_Mantenimiento());
        frame.setVisible(true);
    }
}
