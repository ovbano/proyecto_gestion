package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.PlainDocument;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Insertar_Persona extends JPanel {
    private JTextField idPersonaTextField;
    private JTextField cedulaTextField;
    private JTextField nombreTextField;
    private JTextField apellidoTextField;
    private JTextField edadTextField;
    private JComboBox<String> sexoComboBox, direccionComboBox, tipoPersonaComboBox;
    private JTextField telefonoTextField;
    private JButton insertarButton, modificarButton, eliminarButton;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;


    public Insertar_Persona() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(70, 116, 166));

        JPanel panelInsercion = new JPanel(new GridBagLayout());
        panelInsercion.setBackground(new Color(70, 116, 166));

        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar");
        titledBorder.setTitleColor(Color.WHITE);
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        JLabel tituloIDPersona = new JLabel("ID Persona");
        JLabel tituloCedula = new JLabel("Cedula");
        JLabel tituloNombre = new JLabel("Nombre");
        JLabel tituloApellido = new JLabel("Apellido");
        JLabel tituloEdad = new JLabel("Edad");
        JLabel tituloSexo = new JLabel("Sexo");
        JLabel tituloTelefono = new JLabel("Telefono");
        JLabel tituloTipoPersona = new JLabel("Tipo Persona");
        JLabel tituloIDDireccion = new JLabel("Direccion");

        tituloIDPersona.setForeground(Color.WHITE);
        tituloCedula.setForeground(Color.WHITE);
        tituloNombre.setForeground(Color.WHITE);
        tituloApellido.setForeground(Color.WHITE);
        tituloEdad.setForeground(Color.WHITE);
        tituloSexo.setForeground(Color.WHITE);
        tituloTelefono.setForeground(Color.WHITE);
        tituloTipoPersona.setForeground(Color.WHITE);
        tituloIDDireccion.setForeground(Color.WHITE);

        idPersonaTextField = new JTextField(20);

        // Crear un documento de texto plano y aplicar DocumentFilter
        PlainDocument doc = new PlainDocument();
        doc.setDocumentFilter(new MyDocumentFilter());

        // Establecer el documento en el JTextField
        idPersonaTextField.setDocument(doc);

        // Generar automáticamente el ID_Persona
        idPersonaTextField.setText(generarIDPersona());

        cedulaTextField = new JTextField(20);
        nombreTextField = new JTextField(20);
        apellidoTextField = new JTextField(20);
        edadTextField = new JTextField(20);
        sexoComboBox = new JComboBox<>(new String[] { "H", "M", "P" }); // Menú desplegable para Sexo
        telefonoTextField = new JTextField(20);
        tipoPersonaComboBox = new JComboBox<>(new String[] { "Conductor", "Pasajero" }); // Menú desplegable para Tipo
                                                                                         // Persona
        direccionComboBox = new JComboBox<>();
        cargarDireccionesEnComboBoxEjemplo();

        insertarButton = new JButton("Insertar");
        personalizarBoton(insertarButton);

        GridBagConstraints gbcTituloIDPersona = new GridBagConstraints();
        gbcTituloIDPersona.gridx = 0;
        gbcTituloIDPersona.gridy = 0;
        gbcTituloIDPersona.gridwidth = 2;
        gbcTituloIDPersona.insets = new Insets(0, 0, 10, 0);
        gbcTituloIDPersona.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloCedula = new GridBagConstraints();
        gbcTituloCedula.gridx = 0;
        gbcTituloCedula.gridy = 2;
        gbcTituloCedula.gridwidth = 2;
        gbcTituloCedula.insets = new Insets(0, 0, 10, 0);
        gbcTituloCedula.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloNombre = new GridBagConstraints();
        gbcTituloNombre.gridx = 0;
        gbcTituloNombre.gridy = 4;
        gbcTituloNombre.gridwidth = 2;
        gbcTituloNombre.insets = new Insets(0, 0, 10, 0);
        gbcTituloNombre.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloApellido = new GridBagConstraints();
        gbcTituloApellido.gridx = 0;
        gbcTituloApellido.gridy = 6;
        gbcTituloApellido.gridwidth = 2;
        gbcTituloApellido.insets = new Insets(0, 0, 10, 0);
        gbcTituloApellido.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloEdad = new GridBagConstraints();
        gbcTituloEdad.gridx = 0;
        gbcTituloEdad.gridy = 8;
        gbcTituloEdad.gridwidth = 2;
        gbcTituloEdad.insets = new Insets(0, 0, 10, 0);
        gbcTituloEdad.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloSexo = new GridBagConstraints();
        gbcTituloSexo.gridx = 0;
        gbcTituloSexo.gridy = 10;
        gbcTituloSexo.gridwidth = 2;
        gbcTituloSexo.insets = new Insets(0, 0, 10, 0);
        gbcTituloSexo.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloTelefono = new GridBagConstraints();
        gbcTituloTelefono.gridx = 0;
        gbcTituloTelefono.gridy = 12;
        gbcTituloTelefono.gridwidth = 2;
        gbcTituloTelefono.insets = new Insets(0, 0, 10, 0);
        gbcTituloTelefono.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloTipoPersona = new GridBagConstraints();
        gbcTituloTipoPersona.gridx = 0;
        gbcTituloTipoPersona.gridy = 14;
        gbcTituloTipoPersona.gridwidth = 2;
        gbcTituloTipoPersona.insets = new Insets(0, 0, 10, 0);
        gbcTituloTipoPersona.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloIDDireccion = new GridBagConstraints();
        gbcTituloIDDireccion.gridx = 0;
        gbcTituloIDDireccion.gridy = 16;
        gbcTituloIDDireccion.gridwidth = 2;
        gbcTituloIDDireccion.insets = new Insets(0, 0, 10, 0);
        gbcTituloIDDireccion.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcIDPersona = new GridBagConstraints();
        gbcIDPersona.gridx = 0;
        gbcIDPersona.gridy = 1;
        gbcIDPersona.gridwidth = 2;
        gbcIDPersona.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcCedula = new GridBagConstraints();
        gbcCedula.gridx = 0;
        gbcCedula.gridy = 3;
        gbcCedula.gridwidth = 2;
        gbcCedula.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcNombre = new GridBagConstraints();
        gbcNombre.gridx = 0;
        gbcNombre.gridy = 5;
        gbcNombre.gridwidth = 2;
        gbcNombre.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcApellido = new GridBagConstraints();
        gbcApellido.gridx = 0;
        gbcApellido.gridy = 7;
        gbcApellido.gridwidth = 2;
        gbcApellido.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcEdad = new GridBagConstraints();
        gbcEdad.gridx = 0;
        gbcEdad.gridy = 9;
        gbcEdad.gridwidth = 2;
        gbcEdad.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcSexo = new GridBagConstraints();
        gbcSexo.gridx = 0;
        gbcSexo.gridy = 11;
        gbcSexo.gridwidth = 2;
        gbcSexo.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcTelefono = new GridBagConstraints();
        gbcTelefono.gridx = 0;
        gbcTelefono.gridy = 13;
        gbcTelefono.gridwidth = 2;
        gbcTelefono.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcTipoPersona = new GridBagConstraints();
        gbcTipoPersona.gridx = 0;
        gbcTipoPersona.gridy = 15;
        gbcTipoPersona.gridwidth = 2;
        gbcTipoPersona.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcIDDireccion = new GridBagConstraints();
        gbcIDDireccion.gridx = 0;
        gbcIDDireccion.gridy = 17;
        gbcIDDireccion.gridwidth = 2;
        gbcIDDireccion.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcInsertar = new GridBagConstraints();
        gbcInsertar.gridx = 0;
        gbcInsertar.gridy = 19;
        gbcInsertar.gridwidth = 2;

        panelInsercion.add(tituloIDPersona, gbcTituloIDPersona);
        panelInsercion.add(idPersonaTextField, gbcIDPersona);
        panelInsercion.add(tituloCedula, gbcTituloCedula);
        panelInsercion.add(cedulaTextField, gbcCedula);
        panelInsercion.add(tituloNombre, gbcTituloNombre);
        panelInsercion.add(nombreTextField, gbcNombre);
        panelInsercion.add(tituloApellido, gbcTituloApellido);
        panelInsercion.add(apellidoTextField, gbcApellido);
        panelInsercion.add(tituloEdad, gbcTituloEdad);
        panelInsercion.add(edadTextField, gbcEdad);
        panelInsercion.add(tituloSexo, gbcTituloSexo);
        panelInsercion.add(sexoComboBox, gbcSexo);
        panelInsercion.add(tituloTelefono, gbcTituloTelefono);
        panelInsercion.add(telefonoTextField, gbcTelefono);
        panelInsercion.add(tituloTipoPersona, gbcTituloTipoPersona);
        panelInsercion.add(tipoPersonaComboBox, gbcTipoPersona);
        panelInsercion.add(tituloIDDireccion, gbcTituloIDDireccion);
        panelInsercion.add(direccionComboBox, gbcIDDireccion);
        panelInsercion.add(insertarButton, gbcInsertar);

        modificarButton = new JButton("Modificar");
        personalizarBoton(modificarButton);

        eliminarButton = new JButton("Eliminar");
        personalizarBoton(eliminarButton);

        JPanel panelBotonesPersona = new JPanel();
        panelBotonesPersona.setLayout(new FlowLayout(FlowLayout.RIGHT));
        panelBotonesPersona.add(modificarButton);
        panelBotonesPersona.add(eliminarButton);

        JPanel panelVisualizacionPersona = new JPanel(new BorderLayout());
        panelVisualizacionPersona.setBackground(new Color(70, 116, 166));
        JLabel infoLabelPersona = new JLabel("Visualización, Modificación y Eliminación");
        infoLabelPersona.setForeground(Color.WHITE);
        infoLabelPersona.setHorizontalAlignment(SwingConstants.CENTER);
        panelVisualizacionPersona.add(infoLabelPersona, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0; // 0 es el índice de la columna ID_persona
            }
        };
        modeloTabla.addColumn("ID_persona");
        modeloTabla.addColumn("Cedula");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Apellido");
        modeloTabla.addColumn("Edad");
        modeloTabla.addColumn("Sexo");
        modeloTabla.addColumn("Telefono");
        modeloTabla.addColumn("Tipo_persona");
        modeloTabla.addColumn("ID_direccion");

        tablaRegistros = new JTable(modeloTabla);
        JScrollPane scrollPanePersona = new JScrollPane(tablaRegistros);
        panelVisualizacionPersona.add(scrollPanePersona, BorderLayout.CENTER);
        panelVisualizacionPersona.add(panelBotonesPersona, BorderLayout.SOUTH);

        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacionPersona);
        splitPaneHorizontal.setResizeWeight(0.2);

        add(splitPaneHorizontal, BorderLayout.CENTER);

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idPersona = idPersonaTextField.getText();
                String cedula = cedulaTextField.getText();
                String nombre = nombreTextField.getText();
                String apellido = apellidoTextField.getText();
                String edadText = edadTextField.getText();

                // Validar que la edad sea un número entero mayor a 0
                try {
                    int edad = Integer.parseInt(edadText);
                    if (edad <= 0) {
                        throw new NumberFormatException();
                    }

                    String sexo = (String) sexoComboBox.getSelectedItem();
                    String telefono = telefonoTextField.getText();
                    String tipoPersona = (String) tipoPersonaComboBox.getSelectedItem();
                    String direccionSeleccionada = (String) direccionComboBox.getSelectedItem();

                    // Obtener el ID de la dirección seleccionada
                    int idDireccion = obtenerIdDireccionDesdeBD(direccionSeleccionada);

                    // Validar que la cédula y el teléfono no estén repetidos
                    if (!validarCedulaRepetida(cedula) || !validarTelefonoRepetido(telefono)) {
                        JOptionPane.showMessageDialog(null,
                                "La cédula o el teléfono ya existen. Introduce valores únicos.",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Insertar en la base de datos
                    insertarPersonaEnBaseDeDatos(idPersona, cedula, nombre, apellido, edad, sexo, telefono, tipoPersona,
                            idDireccion);
                    limpiarCampos();
                    cargarRegistros();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, introduce una edad válida (mayor a 0).",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
                idPersonaTextField.setText(idPersona);
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();
        
                if (filaSeleccionada != -1) {
                    String idPersonaModificar = (String) modeloTabla.getValueAt(filaSeleccionada, 0).toString();
                    String cedulaSeleccionada = (String) modeloTabla.getValueAt(filaSeleccionada, 1).toString();
                    String nombreSeleccionado = (String) modeloTabla.getValueAt(filaSeleccionada, 2).toString();
                    String apellidoSeleccionado = (String) modeloTabla.getValueAt(filaSeleccionada, 3).toString();
                    int edadSeleccionada = (int) modeloTabla.getValueAt(filaSeleccionada, 4);
                    String sexoSeleccionado = (String) modeloTabla.getValueAt(filaSeleccionada, 5).toString();
                    String telefonoSeleccionado = (String) modeloTabla.getValueAt(filaSeleccionada, 6).toString();
                    String tipoPersonaSeleccionado = (String) modeloTabla.getValueAt(filaSeleccionada, 7).toString();
                    String direccionSeleccionada = (String) modeloTabla.getValueAt(filaSeleccionada, 8).toString();
        
                    // Establecer los valores en los campos correspondientes
                    idPersonaTextField.setText(idPersonaModificar);
                    cedulaTextField.setText(cedulaSeleccionada);
                    nombreTextField.setText(nombreSeleccionado);
                    apellidoTextField.setText(apellidoSeleccionado);
                    edadTextField.setText(String.valueOf(edadSeleccionada));
                    sexoComboBox.setSelectedItem(sexoSeleccionado);
                    telefonoTextField.setText(telefonoSeleccionado);
                    tipoPersonaComboBox.setSelectedItem(tipoPersonaSeleccionado);
                    direccionComboBox.setSelectedItem(direccionSeleccionada);
        
                    // Lógica para la modificación
                    try {
                        int edad = Integer.parseInt(edadTextField.getText());
                        String sexo = (String) sexoComboBox.getSelectedItem();
                        String telefono = telefonoTextField.getText();
                        String tipoPersona = (String) tipoPersonaComboBox.getSelectedItem();
                        String direccion = (String) direccionComboBox.getSelectedItem();
                        String cedula = cedulaTextField.getText();
                        String apellido = apellidoTextField.getText();
        
                        // Obtener el ID de la dirección seleccionada
                        int idDireccion = obtenerIdDireccionDesdeBD(direccion);
        
                        // Validar que la cédula y el teléfono no estén repetidos (excepto para el ID actual)
                        if (!validarCedulaRepetida(idPersonaModificar) || !validarTelefonoRepetido(idPersonaModificar)) {
                            JOptionPane.showMessageDialog(null, "La cédula o el teléfono ya existen. Introduce valores únicos.",
                                    "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
        
                        // Llamar al procedimiento almacenado para modificar persona
                        modificarPersonaEnBD(idPersonaModificar, cedula, nombreSeleccionado, apellido, edad, sexo, telefono,
                                tipoPersona, idDireccion);
                        limpiarCampos();
                        cargarRegistros();
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Por favor, introduce una edad válida (mayor a 0).",
                                "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        

        // Implementación de ActionListener para el botón "Eliminar"
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    
                    int opcion = JOptionPane.showConfirmDialog(null,
                            "¿Seguro que quieres eliminar este registro?", "Confirmar eliminación",
                            JOptionPane.YES_NO_OPTION);

                    if (opcion == JOptionPane.YES_OPTION) {
                        String idPersonaAEliminar = (String) modeloTabla.getValueAt(filaSeleccionada, 0);
                        eliminarPersonaEnBaseDeDatos(idPersonaAEliminar);
                        limpiarCampos();
                        cargarRegistros();
                        // Después de la eliminación, actualiza el campo ID_persona
                        if (tablaRegistros.getRowCount() > 0) {
                            int nuevaFilaSeleccionada = Math.max(filaSeleccionada, tablaRegistros.getRowCount() - 1);
                            String nuevoIDPersona = (String) modeloTabla.getValueAt(nuevaFilaSeleccionada, 0);
                            idPersonaTextField.setText(nuevoIDPersona);
                        } else {
                            // Si no hay más registros, limpia el campo ID_persona
                            idPersonaTextField.setText("");
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cargarRegistros();
    }

    private String generarIDPersona() {
        int contador = obtenerContadorInicial(); // Obtener el valor inicial del contador
        contador = obtenerUltimoID() + 1; // Obtener el último ID de la base de datos y sumar 1
        return String.format("P-%04d", contador); // Formatear el ID_Persona
    }

    private int obtenerUltimoID() {
        int ultimoID = 0;
        Connection conexion = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            conexion = ConexionBD.obtenerConexion();
            String consulta = "SELECT MAX(CAST(SUBSTRING(ID_persona, 3, LEN(ID_persona)) AS INT)) FROM PERSONA";
            statement = conexion.prepareStatement(consulta);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                ultimoID = resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }

        return ultimoID;
    }

    private int obtenerContadorInicial() {
        // Devuelve el valor inicial deseado (en este caso, 39)
        return 39;
    }

    // Método para cargar direcciones en un JComboBox
    private void cargarDireccionesEnComboBox(JComboBox<String> comboBox, String consulta) {
        comboBox.removeAllItems(); // Limpiar items existentes
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String direccion = resultSet.getString("Detalle");
                comboBox.addItem(direccion);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar direcciones en el JComboBox.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private int obtenerIdDireccionDesdeBD(String direccion) {
        int idDireccion = -1;

        Connection conexion = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            conexion = ConexionBD.obtenerConexion();

            String consulta = "SELECT ID_direccion FROM DIRECCION WHERE Detalle = ?";
            statement = conexion.prepareStatement(consulta);
            statement.setString(1, direccion);

            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                idDireccion = resultSet.getInt("ID_direccion");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }

        return idDireccion;
    }

    private void cargarDireccionesEnComboBoxEjemplo() {
        // Consulta para obtener direcciones
        String consultaDirecciones = "SELECT Detalle FROM DIRECCION";

        // Llamada al método para cargar direcciones en un JComboBox
        cargarDireccionesEnComboBox(direccionComboBox, consultaDirecciones);
    }

    // Método para personalizar un botón
    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140)); // Color de fondo
        boton.setForeground(Color.WHITE); // Color del texto
        boton.setFocusPainted(false); // Evitar que se pinte el borde al obtener el foco
        boton.setFont(new Font("Arial", Font.BOLD, 14)); // Fuente y tamaño del texto
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16)); // Márgenes internos
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR)); // Cambiar el cursor al pasar sobre el botón
    }

    private boolean validarCedulaRepetida(String cedula) {
        Connection conexion = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            conexion = ConexionBD.obtenerConexion();

            // Consulta para verificar si la cédula ya existe
            String consulta = "SELECT COUNT(*) FROM PERSONA WHERE Cedula = ?";
            statement = conexion.prepareStatement(consulta);
            statement.setString(1, cedula);
            resultSet = statement.executeQuery();

            // Si el resultado es mayor que 0, la cédula ya existe
            return resultSet.next() && resultSet.getInt(1) == 0;

        } catch (SQLException e) {
            e.printStackTrace();
            // Manejar la excepción de manera apropiada en tu aplicación
            return false;

        } finally {
            ConexionBD.cerrarConexion(conexion);
            cerrarStatement(statement);
        }
    }

    private boolean validarTelefonoRepetido(String telefono) {
        Connection conexion = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            conexion = ConexionBD.obtenerConexion();

            // Consulta para verificar si el teléfono ya existe
            String consulta = "SELECT COUNT(*) FROM PERSONA WHERE Telefono = ?";
            statement = conexion.prepareStatement(consulta);
            statement.setString(1, telefono);
            resultSet = statement.executeQuery();

            // Si el resultado es mayor que 0, el teléfono ya existe
            return resultSet.next() && resultSet.getInt(1) == 0;

        } catch (SQLException e) {
            e.printStackTrace();
            // Manejar la excepción de manera apropiada en tu aplicación
            return false;

        } finally {
            ConexionBD.cerrarConexion(conexion);
            cerrarStatement(statement);
        }
    }

    private void insertarPersonaEnBaseDeDatos(String idPersona, String cedula, String nombre, String apellido, int edad,
            String sexo, String telefono, String tipoPersona, int idDireccion) {
        Connection conexion = null;
        CallableStatement statement = null;

        try {
            conexion = ConexionBD.obtenerConexion();

            // Llama al procedimiento almacenado InsertarPersona
            String procedimientoAlmacenado = "{CALL InsertarPersona(?, ?, ?, ?, ?, ?, ?, ?, ?)}";
            statement = conexion.prepareCall(procedimientoAlmacenado);

            // Establece los parámetros del procedimiento almacenado
            statement.setString(1, idPersona);
            statement.setString(2, cedula);
            statement.setString(3, nombre);
            statement.setString(4, apellido);
            statement.setInt(5, edad);
            statement.setString(6, sexo);
            statement.setString(7, telefono);
            statement.setString(8, tipoPersona);
            statement.setInt(9, idDireccion);

            // Ejecuta el procedimiento almacenado
            statement.execute();

            JOptionPane.showMessageDialog(null, "Persona insertada correctamente.", "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al insertar la persona en la base de datos.", "Error",
                    JOptionPane.ERROR_MESSAGE);

        } finally {
            ConexionBD.cerrarConexion(conexion);
            cerrarStatement(statement);
        }
    }

    private void modificarPersonaEnBD(String idPersona, String cedula, String nombre, String apellido, int edad,
            String sexo, String telefono, String tipoPersona, int idDireccion) {
        Connection conexion = null;
        CallableStatement callableStatement = null;

        try {
            conexion = ConexionBD.obtenerConexion();
            callableStatement = conexion.prepareCall("{call ModificarPersona(?, ?, ?, ?, ?, ?, ?, ?, ?)}");

            // Configurar los parámetros del procedimiento almacenado
            callableStatement.setString(1, idPersona);
            callableStatement.setString(2, cedula);
            callableStatement.setString(3, nombre);
            callableStatement.setString(4, apellido);
            callableStatement.setInt(5, edad);
            callableStatement.setString(6, sexo);
            callableStatement.setString(7, telefono);
            callableStatement.setString(8, tipoPersona);
            callableStatement.setInt(9, idDireccion);

            // Ejecutar el procedimiento almacenado
            callableStatement.executeUpdate();
            System.out.println("Persona modificada en la base de datos: " + nombre);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al modificar la persona en la base de datos.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            cerrarStatement(callableStatement);
            ConexionBD.cerrarConexion(conexion);
        }
    }

    // Agrega la función necesaria para eliminar en la base de datos
    private void eliminarPersonaEnBaseDeDatos(String idPersona) {
        Connection conexion = null;
        CallableStatement statement = null;

        try {
            conexion = ConexionBD.obtenerConexion();

            // Llama al procedimiento almacenado EliminarPersona
            String procedimientoAlmacenado = "{CALL EliminarPersona(?)}";
            statement = conexion.prepareCall(procedimientoAlmacenado);

            // Establece el parámetro del procedimiento almacenado
            statement.setString(1, idPersona);

            // Ejecuta el procedimiento almacenado
            statement.execute();

            JOptionPane.showMessageDialog(null, "Persona eliminada correctamente.", "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al eliminar la persona en la base de datos.", "Error",
                    JOptionPane.ERROR_MESSAGE);

        } finally {
            ConexionBD.cerrarConexion(conexion);
            cerrarStatement(statement);
        }
    }

    // Método para cerrar un PreparedStatement
    private void cerrarStatement(PreparedStatement statement) {
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void cargarRegistros() {
        cargarRegistrosTabla(tablaRegistros, modeloTabla, "SELECT * FROM PERSONA");
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0); // Limpia los registros existentes en el modelo

        Connection conexion = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            conexion = ConexionBD.obtenerConexion();
            preparedStatement = conexion.prepareStatement(consulta);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Object[] fila = {
                        resultSet.getString("ID_persona"),
                        resultSet.getString("Cedula"),
                        resultSet.getString("Nombre"),
                        resultSet.getString("Apellido"),
                        resultSet.getInt("Edad"),
                        resultSet.getString("Sexo"),
                        resultSet.getString("Telefono"),
                        resultSet.getString("Tipo_persona"),
                        resultSet.getInt("ID_direccion")
                };
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            cerrarResultSet(resultSet);
            cerrarStatement(preparedStatement);
            ConexionBD.cerrarConexion(conexion);
        }
    }

    // Agrega funciones para cerrar el ResultSet y el PreparedStatement
    private void cerrarResultSet(ResultSet resultSet) {
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void limpiarCampos() {
        idPersonaTextField.setText("");
        cedulaTextField.setText("");
        nombreTextField.setText("");
        apellidoTextField.setText("");
        edadTextField.setText("");
        sexoComboBox.setSelectedIndex(0);
        telefonoTextField.setText("");
        tipoPersonaComboBox.setSelectedIndex(0);
        direccionComboBox.setToolTipText("Direcciones...");
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Insertar Mantenimiento Form");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setSize(800, 600);
        frame.add(new Insertar_Persona());
        frame.setVisible(true);
    }
}
