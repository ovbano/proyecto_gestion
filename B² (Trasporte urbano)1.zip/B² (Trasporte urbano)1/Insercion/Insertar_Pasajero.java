package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Insertar_Pasajero extends JPanel {
    private JTextField idPasajeroTextField;
    private JComboBox<String> tipoPasajeroComboBox;
    private JComboBox<String> idTarifaComboBox;
    private JComboBox<String> idPersonaComboBox;
    private JButton insertarButton;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private JButton modificarButton;
    private JButton eliminarButton;
    private ResultSet resultSet;

    public Insertar_Pasajero() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(70, 116, 166));

        JPanel panelInsercion = new JPanel(new GridBagLayout());
        panelInsercion.setBackground(new Color(70, 116, 166));

        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar Pasajero");
        titledBorder.setTitleColor(Color.WHITE);
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        JLabel tituloIdPasajero = new JLabel("ID Pasajero");
        JLabel tituloTipoPasajero = new JLabel("Tipo Pasajero");
        JLabel tituloIdTarifa = new JLabel("ID Tarifa");
        JLabel tituloIdPersonaPasajero = new JLabel("ID Persona");

        tituloIdPasajero.setForeground(Color.WHITE);
        tituloTipoPasajero.setForeground(Color.WHITE);
        tituloIdTarifa.setForeground(Color.WHITE);
        tituloIdPersonaPasajero.setForeground(Color.WHITE);

        idPasajeroTextField = new JTextField(20);
        String[] tiposPasajero = {"Estudiante", "Normal", "Discapacitado", "Adulto mayor"};
        tipoPasajeroComboBox = new JComboBox<>(tiposPasajero);
        idTarifaComboBox = new JComboBox<>();
        idPersonaComboBox = new JComboBox<>();

        insertarButton = new JButton("Insertar");
        personalizarBoton(insertarButton);

        GridBagConstraints gbcTituloIdPasajero = new GridBagConstraints();
        gbcTituloIdPasajero.gridx = 0;
        gbcTituloIdPasajero.gridy = 0;
        gbcTituloIdPasajero.gridwidth = 2;
        gbcTituloIdPasajero.insets = new Insets(0, 0, 10, 0);
        gbcTituloIdPasajero.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloTipoPasajero = new GridBagConstraints();
        gbcTituloTipoPasajero.gridx = 0;
        gbcTituloTipoPasajero.gridy = 3;
        gbcTituloTipoPasajero.gridwidth = 2;
        gbcTituloTipoPasajero.insets = new Insets(0, 0, 10, 0);
        gbcTituloTipoPasajero.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloIdTarifa = new GridBagConstraints();
        gbcTituloIdTarifa.gridx = 0;
        gbcTituloIdTarifa.gridy = 6;
        gbcTituloIdTarifa.gridwidth = 2;
        gbcTituloIdTarifa.insets = new Insets(0, 0, 10, 0);
        gbcTituloIdTarifa.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloIdPersonaPasajero = new GridBagConstraints();
        gbcTituloIdPersonaPasajero.gridx = 0;
        gbcTituloIdPersonaPasajero.gridy = 9;
        gbcTituloIdPersonaPasajero.gridwidth = 2;
        gbcTituloIdPersonaPasajero.insets = new Insets(0, 0, 10, 0);
        gbcTituloIdPersonaPasajero.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcIdPasajero = new GridBagConstraints();
        gbcIdPasajero.gridx = 0;
        gbcIdPasajero.gridy = 2;
        gbcIdPasajero.gridwidth = 2;
        gbcIdPasajero.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcTipoPasajero = new GridBagConstraints();
        gbcTipoPasajero.gridx = 0;
        gbcTipoPasajero.gridy = 5;
        gbcTipoPasajero.gridwidth = 2;
        gbcTipoPasajero.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcIdTarifa = new GridBagConstraints();
        gbcIdTarifa.gridx = 0;
        gbcIdTarifa.gridy = 8;
        gbcIdTarifa.gridwidth = 2;
        gbcIdTarifa.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcIdPersonaPasajero = new GridBagConstraints();
        gbcIdPersonaPasajero.gridx = 0;
        gbcIdPersonaPasajero.gridy = 11;
        gbcIdPersonaPasajero.gridwidth = 2;
        gbcIdPersonaPasajero.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcInsertar = new GridBagConstraints();
        gbcInsertar.gridx = 0;
        gbcInsertar.gridy = 12;
        gbcInsertar.gridwidth = 2;

        panelInsercion.add(tituloIdPasajero, gbcTituloIdPasajero);
        panelInsercion.add(idPasajeroTextField, gbcIdPasajero);
        panelInsercion.add(tituloTipoPasajero, gbcTituloTipoPasajero);
        panelInsercion.add(tipoPasajeroComboBox, gbcTipoPasajero);
        panelInsercion.add(tituloIdTarifa, gbcTituloIdTarifa);
        panelInsercion.add(idTarifaComboBox, gbcIdTarifa);
        panelInsercion.add(tituloIdPersonaPasajero, gbcTituloIdPersonaPasajero);
        panelInsercion.add(idPersonaComboBox, gbcIdPersonaPasajero);
        panelInsercion.add(insertarButton, gbcInsertar);

        modificarButton = new JButton("Modificar");
        personalizarBoton(modificarButton);

        eliminarButton = new JButton("Eliminar");
        personalizarBoton(eliminarButton);

        JPanel panelBotonesPasajero = new JPanel();
        panelBotonesPasajero.setLayout(new FlowLayout(FlowLayout.RIGHT));
        panelBotonesPasajero.add(modificarButton);
        panelBotonesPasajero.add(eliminarButton);

        JPanel panelVisualizacionPasajero = new JPanel(new BorderLayout());
        panelVisualizacionPasajero.setBackground(new Color(70, 116, 166));
        JLabel infoLabelPasajero = new JLabel("Visualización, Modificación y Eliminación de Pasajeros");
        infoLabelPasajero.setForeground(Color.WHITE);
        infoLabelPasajero.setHorizontalAlignment(SwingConstants.CENTER);
        panelVisualizacionPasajero.add(infoLabelPasajero, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return true;
            }
        };
        modeloTabla.addColumn("ID_Pasajero");
        modeloTabla.addColumn("Tipo_Pasajero");
        modeloTabla.addColumn("ID_tarifa");
        modeloTabla.addColumn("ID_persona");
        tablaRegistros = new JTable(modeloTabla);
        JScrollPane scrollPanePasajero = new JScrollPane(tablaRegistros);
        panelVisualizacionPasajero.add(scrollPanePasajero, BorderLayout.CENTER);
        panelVisualizacionPasajero.add(panelBotonesPasajero, BorderLayout.SOUTH);

        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacionPasajero);
        splitPaneHorizontal.setResizeWeight(0.2);

        add(splitPaneHorizontal, BorderLayout.CENTER);

        cargarTarifasEnComboBox();
        cargarPersonasEnComboBox();

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idPasajero = idPasajeroTextField.getText();
                String tipoPasajero = (String) tipoPasajeroComboBox.getSelectedItem();
                String idTarifaSeleccionada = (String) idTarifaComboBox.getSelectedItem();
                String idPersonaSeleccionada = (String) idPersonaComboBox.getSelectedItem();

                // Extraer el ID de tarifa y persona desde las selecciones
                String idTarifa = idTarifaSeleccionada.split(" - ")[0];
                String idPersona = idPersonaSeleccionada.split(" - ")[0];

                // Validar que los campos no estén vacíos antes de insertar
                if (!idPasajero.isEmpty() && !tipoPasajero.isEmpty() && !idTarifa.isEmpty() && !idPersona.isEmpty()) {
                    insertarPasajeroEnBaseDeDatos(idPasajero, tipoPasajero, idTarifa, idPersona);
                    limpiarCampos();
                    cargarRegistros();
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, completa todos los campos.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    String idPasajero = (String) tablaRegistros.getValueAt(filaSeleccionada, 0);
                    String tipoPasajero = (String) tablaRegistros.getValueAt(filaSeleccionada, 1);
                    String idTarifaSeleccionada = (String) tablaRegistros.getValueAt(filaSeleccionada, 2);
                    String idPersonaSeleccionada = (String) tablaRegistros.getValueAt(filaSeleccionada, 3);

                    idPasajeroTextField.setText(idPasajero);
                    tipoPasajeroComboBox.setSelectedItem(tipoPasajero);

                    // Extraer el ID de tarifa y persona desde las selecciones
                    String idTarifa = idTarifaSeleccionada.split(" - ")[0];
                    String idPersona = idPersonaSeleccionada.split(" - ")[0];

                    idTarifaComboBox.setSelectedItem(idTarifa + " - " + obtenerNombreTarifa(idTarifa));
                    idPersonaComboBox.setSelectedItem(idPersona + " - " + obtenerNombrePersona(idPersona));

                    // Implementar la lógica para la modificación en la base de datos
                    modificarPasajeroEnBaseDeDatos(idPasajero, tipoPasajero, idTarifa, idPersona);

                    // Después de modificar, limpiar campos y recargar registros
                    limpiarCampos();
                    cargarRegistros();
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    String idPasajero = (String) tablaRegistros.getValueAt(filaSeleccionada, 0);

                    int opcion = JOptionPane.showConfirmDialog(null,
                            "¿Seguro que quieres eliminar este registro?", "Confirmar eliminación",
                            JOptionPane.YES_NO_OPTION);

                    if (opcion == JOptionPane.YES_OPTION) {
                        // Implementar la lógica para la eliminación en la base de datos
                        eliminarPasajeroEnBaseDeDatos(idPasajero);

                        // Después de eliminar, limpiar campos y recargar registros
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cargarRegistros();
    }

    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private String obtenerNombreTarifa(String idTarifa) {
        Connection conexion = ConexionBD.obtenerConexion();
        String nombreTarifa = "";

        try {
            String consulta = "SELECT Nombre_tarifa FROM TARIFA WHERE ID_tarifa = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            preparedStatement.setString(1, idTarifa);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                nombreTarifa = resultSet.getString("Nombre_tarifa");
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener el nombre de la tarifa.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }

        return nombreTarifa;
    }

    private String obtenerNombrePersona(String idPersona) {
        Connection conexion = ConexionBD.obtenerConexion();
        String nombrePersona = "";

        try {
            String consulta = "SELECT Nombre, Apellido FROM PERSONA WHERE ID_persona = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            preparedStatement.setString(1, idPersona);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                nombrePersona = resultSet.getString("Nombre") + " " + resultSet.getString("Apellido");
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener el nombre de la persona.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }

        return nombrePersona;
    }

    private void insertarPasajeroEnBaseDeDatos(String idPasajero, String tipoPasajero, String idTarifa, String idPersona) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL InsertarPasajero(?, ?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, idPasajero);
            preparedStatement.setString(2, tipoPasajero);
            preparedStatement.setString(3, idTarifa);
            preparedStatement.setString(4, idPersona);
            preparedStatement.executeUpdate();
            System.out.println("Pasajero insertado en la base de datos: " + idPasajero);
        } catch (SQLException ex) {
            System.out.println("Error al insertar el pasajero en la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void modificarPasajeroEnBaseDeDatos(String idPasajero, String tipoPasajero, String idTarifa, String idPersona) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL ModificarPasajero(?, ?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, idPasajero);
            preparedStatement.setString(2, tipoPasajero);
            preparedStatement.setString(3, idTarifa);
            preparedStatement.setString(4, idPersona);
            preparedStatement.executeUpdate();
            System.out.println("Pasajero modificado en la base de datos: " + idPasajero);
        } catch (SQLException ex) {
            System.out.println("Error al modificar el pasajero en la base de datos: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void eliminarPasajeroEnBaseDeDatos(String idPasajero) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL EliminarPasajero(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, idPasajero);
            preparedStatement.executeUpdate();
            System.out.println("Pasajero eliminado de la base de datos: " + idPasajero);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el pasajero de la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void cargarRegistros() {
        cargarRegistrosTabla(tablaRegistros, modeloTabla, "SELECT * FROM PASAJERO");
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0);
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Object[] fila = {resultSet.getString("ID_Pasajero"), resultSet.getString("Tipo_Pasajero"),
                        resultSet.getString("ID_tarifa"), resultSet.getString("ID_persona")};
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void limpiarCampos() {
        idPasajeroTextField.setText("");
        tipoPasajeroComboBox.setSelectedIndex(0);
        idTarifaComboBox.setSelectedIndex(0);
        idPersonaComboBox.setSelectedIndex(0);
    }

    private void cargarTarifasEnComboBox() {
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            String consulta = "SELECT ID_tarifa, Nombre_tarifa FROM TARIFA";
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String idTarifa = resultSet.getString("ID_tarifa");
                String nombreTarifa = resultSet.getString("Nombre_tarifa");
                idTarifaComboBox.addItem(idTarifa + " - " + nombreTarifa);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar tarifas en ComboBox.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void cargarPersonasEnComboBox() {
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            String consulta = "SELECT ID_persona, Nombre, Apellido FROM PERSONA";
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String idPersona = resultSet.getString("ID_persona");
                String nombre = resultSet.getString("Nombre");
                String apellido = resultSet.getString("Apellido");
                idPersonaComboBox.addItem(idPersona + " - " + nombre + " " + apellido);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar personas en ComboBox.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }


    public static void main(String[] args) {
        JFrame frame = new JFrame("Insertar Pasajero Form");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setSize(800, 600);
        frame.add(new Insertar_Pasajero());
        frame.setVisible(true);
    }
}
