package Insercion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InicioSesion extends JFrame {
    private JTextField usuarioTextField;
    private JPasswordField contrasenaPasswordField;
    private JButton iniciarSesionButton;

    public InicioSesion() {
        setTitle("Inicio de Sesión");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(930, 650);

        // Crear panel principal con BorderLayout
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setBackground(new Color(200, 220, 240)); // Cambiar color de fondo

        // Crear panel izquierdo para el formulario de inicio de sesión
        JPanel formularioPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        formularioPanel.setBackground(new Color(200, 220, 240)); // Cambiar color de fondo

        // Componentes del formulario
        JLabel tituloLabel = new JLabel("INICIO DE SESIÓN");
        tituloLabel.setFont(new Font("Agency FB", Font.BOLD, 30));

        JLabel usuarioLabel = new JLabel("Usuario:");
        usuarioTextField = new JTextField();
        usuarioTextField.setForeground(Color.BLACK);
        usuarioLabel.setFont(new Font("Agency FB", Font.BOLD, 20));
        usuarioTextField.setFont(new Font("Agency FB", Font.ITALIC, 15));

        JLabel contrasenaLabel = new JLabel("Contraseña:");
        contrasenaPasswordField = new JPasswordField();
        contrasenaPasswordField.setForeground(Color.BLACK);
        contrasenaLabel.setFont(new Font("Agency FB", Font.BOLD, 20));
        contrasenaPasswordField.setFont(new Font("Agency FB", Font.ITALIC, 15));

        iniciarSesionButton = new JButton("Iniciar Sesión");

        // Personalizar apariencia del botón
        iniciarSesionButton.setFont(new Font("Agency FB", Font.BOLD, 20));
        iniciarSesionButton.setForeground(Color.WHITE);
        iniciarSesionButton.setBackground(new Color(144, 184, 224)); // Cambiar color de fondo
        

        // Personalizar bordes
        iniciarSesionButton.setBorderPainted(false);
        iniciarSesionButton.setFocusPainted(false);

        // Añadir evento de cambio de color al pasar el ratón
        iniciarSesionButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                iniciarSesionButton.setBackground(new Color(141, 191, 240));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                iniciarSesionButton.setBackground(new Color(144, 184, 224));
            }
        });

        // Ajustar tamaño de los JTextField y aplicar un margen interno
        int anchoTextField = 0; // Ajusta este valor según tus preferencias
        usuarioTextField.setPreferredSize(new Dimension(anchoTextField, usuarioTextField.getPreferredSize().height));
        contrasenaPasswordField.setPreferredSize(new Dimension(anchoTextField, contrasenaPasswordField.getPreferredSize().height));


        // Ajustar tamaño del panel izquierdo
        formularioPanel.setPreferredSize(new Dimension(300, getHeight()));

        // Ajustar tamaño de los componentes JLabel
        usuarioLabel.setPreferredSize(new Dimension(120, usuarioLabel.getPreferredSize().height));
        contrasenaLabel.setPreferredSize(new Dimension(120, contrasenaLabel.getPreferredSize().height));
        usuarioTextField.setPreferredSize(new Dimension(150, usuarioTextField.getPreferredSize().height));
        contrasenaPasswordField.setPreferredSize(new Dimension(150, contrasenaPasswordField.getPreferredSize().height));


        // Agregar componentes al panel del formulario con GridBagLayout
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 10, 0); // Espacio entre el título y los campos de texto
        formularioPanel.add(tituloLabel, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        gbc.insets = new Insets(0, 0, 10, 10); // Espacio entre componentes
        formularioPanel.add(usuarioLabel, gbc);

        gbc.gridx++;
        gbc.insets = new Insets(0, 0, 10, 0);
        formularioPanel.add(usuarioTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 10, 10);
        formularioPanel.add(contrasenaLabel, gbc);

        gbc.gridx++;
        gbc.insets = new Insets(0, 0, 10, 0);
        formularioPanel.add(contrasenaPasswordField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        formularioPanel.add(iniciarSesionButton, gbc);

        // Agregar panel del formulario al panel principal (izquierdo)
        panel.add(formularioPanel, BorderLayout.WEST);

        // Crear panel derecho para el logo y lema
        JPanel logoPanel = new JPanel(new GridBagLayout());
        logoPanel.setBackground(new Color(200, 220, 240)); // Cambiar color de fondo

        // Agregar logo
        String rutaDelLogo = "img/Bus.jpg"; // Reemplazar con la ruta de tu logo
        ImageIcon logoIcon = new ImageIcon(new ImageIcon(rutaDelLogo).getImage().getScaledInstance(500, 500, Image.SCALE_DEFAULT));
        JLabel logoLabel = new JLabel(logoIcon);
        logoLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 5));

        // Agregar lema debajo del logo
        JLabel lemaLabel = new JLabel("Viaja seguro con Trasportes Urbano B²");
        lemaLabel.setFont(new Font("Verdana", Font.ITALIC, 16));

        // Agregar logo y lema al panel derecho
        gbc.gridx = 0;
        gbc.gridy = 0;
        logoPanel.add(logoLabel, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(10, 0, 0, 0); // Espacio entre el logo y el lema
        logoPanel.add(lemaLabel, gbc);

        // Agregar panel del logo al panel principal (derecho)
        panel.add(logoPanel, BorderLayout.EAST);

        // Manejador de eventos para el botón de inicio de sesión
        iniciarSesionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarSesion();
            }
        });

        // Agregar el panel principal al marco
        add(panel);

        // Centrar la ventana en la pantalla
        setLocationRelativeTo(null);

        // Ajustar tamaño de la ventana
        setPreferredSize(new Dimension(950, 650));
        // setResizable(false);
    }

    private void iniciarSesion() {
        String usuario = usuarioTextField.getText();
        String contrasena = new String(contrasenaPasswordField.getPassword());

        // Verificar en la base de datos
        if (verificarCredenciales(usuario, contrasena)) {
            JOptionPane.showMessageDialog(this, "Inicio de sesión exitoso", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            abrirNuevaInterfaz();
        } else {
            JOptionPane.showMessageDialog(this, "Credenciales incorrectas", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void abrirNuevaInterfaz() {
        dispose(); // Cierra la interfaz actual
    
        // Abre la nueva interfaz con botones "Registros" e "Informes"
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new NuevaInterfaz().setVisible(true);
            }
        });
    }

    private boolean verificarCredenciales(String usuario, String contrasena) {
        Connection conexion = ConexionBD.obtenerConexion();
        String consulta = "SELECT * FROM Usuario WHERE USUARIO = ? AND CONTRASEÑA = ?";

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            preparedStatement.setString(1, usuario);
            preparedStatement.setString(2, contrasena);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next(); // Si hay resultados, las credenciales son válidas
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new InicioSesion().setVisible(true);
            }
        });
    }
}
