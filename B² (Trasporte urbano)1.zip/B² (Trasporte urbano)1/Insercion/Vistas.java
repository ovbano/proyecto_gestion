package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Vistas extends JPanel {
    private JComboBox<String> vistasComboBox;
    private JButton mostrarVistaButton;
    private JTextArea consultaTextArea;
    private JButton ejecutarConsultaButton;
    private JTable tablaResultados;
    private DefaultTableModel modeloTabla;

    public Vistas() {
        setLayout(new BorderLayout(10, 10));

        // Panel izquierdo con el menú desplegable y área de texto para consultas
        JPanel panelIzquierdo = new JPanel(new BorderLayout(10, 10));
        panelIzquierdo.setPreferredSize(new Dimension(200, getHeight()));
        panelIzquierdo.setBackground(new Color(70, 116, 166));

        // Subpanel superior para combobox y botón
        JPanel subPanelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
        TitledBorder titledBorderSuperior = BorderFactory.createTitledBorder("Seleccione Vista");
        titledBorderSuperior.setTitleColor(Color.WHITE);
        subPanelSuperior.setBorder(titledBorderSuperior);
        subPanelSuperior.setBackground(new Color(70, 116, 166));

        vistasComboBox = new JComboBox<>();
        vistasComboBox.addItem("VistaMarca");
        vistasComboBox.addItem("VistaMatricula");
        vistasComboBox.addItem("VistaModelo");
        vistasComboBox.addItem("VistaPago");
        vistasComboBox.addItem("VistaPasajero");
        vistasComboBox.addItem("VistaPersona");
        vistasComboBox.addItem("VistaRuta");
        vistasComboBox.addItem("VistaTarifa");
        vistasComboBox.addItem("VistaTipoLicencia");
        vistasComboBox.addItem("VistaVehiculo");

        personalizarComboBox(vistasComboBox);

        mostrarVistaButton = new JButton("Mostrar Vista");
        personalizarBoton(mostrarVistaButton);
        mostrarVistaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cargarVistaSeleccionada();
            }
        });

        subPanelSuperior.add(vistasComboBox);
        subPanelSuperior.add(mostrarVistaButton);

        // Subpanel inferior para área de texto y botón de consulta
        JPanel subPanelInferior = new JPanel(new BorderLayout(10, 10));
        subPanelInferior.setBackground(new Color(70, 116, 166));
        TitledBorder titledBorderInferior = BorderFactory.createTitledBorder("Realizar Consultas");
        titledBorderInferior.setTitleColor(Color.WHITE);
        subPanelInferior.setBorder(titledBorderInferior);

        consultaTextArea = new JTextArea(6, 20);
        consultaTextArea.setLineWrap(true);
        consultaTextArea.setWrapStyleWord(true);

        ejecutarConsultaButton = new JButton("Ejecutar");
        ejecutarConsultaButton.setPreferredSize(new Dimension(100, 30));
        personalizarBoton(ejecutarConsultaButton);

        ejecutarConsultaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ejecutarConsultaSQL();
            }
        });

        subPanelInferior.add(new JScrollPane(consultaTextArea), BorderLayout.NORTH);
        subPanelInferior.add(ejecutarConsultaButton, BorderLayout.SOUTH);

        panelIzquierdo.add(subPanelSuperior, BorderLayout.NORTH);
        panelIzquierdo.add(subPanelInferior, BorderLayout.CENTER);

        // Panel derecho con la tabla para mostrar resultados
        JPanel panelDerecho = new JPanel(new BorderLayout(10, 10));
        panelDerecho.setBackground(new Color(70, 116, 166));

        modeloTabla = new DefaultTableModel();
        tablaResultados = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaResultados);

        panelDerecho.add(scrollPane, BorderLayout.CENTER);

        // Divisor entre paneles izquierdo y derecho
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelIzquierdo, panelDerecho);
        splitPane.setDividerLocation(200);
        splitPane.setBackground(new Color(70, 116, 166));

        add(splitPane, BorderLayout.CENTER);
    }

    private void cargarVistaSeleccionada() {
        String vistaSeleccionada = (String) vistasComboBox.getSelectedItem();
        if (vistaSeleccionada != null) {
            cargarRegistrosVista(vistaSeleccionada);
        }
    }

    private void personalizarComboBox(JComboBox<String> comboBox) {
        comboBox.setBackground(new Color(50, 92, 140)); // Color de fondo
        comboBox.setForeground(Color.WHITE); // Color del texto
        comboBox.setFont(new Font("Arial", Font.PLAIN, 14)); // Fuente y tamaño del texto
        comboBox.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); // Márgenes internos
    }

    private void cargarRegistrosVista(String vista) {
        String consulta = "SELECT * FROM " + vista;
        cargarRegistrosTabla(tablaResultados, modeloTabla, consulta);
    }

    private void ejecutarConsultaSQL() {
        String consultaSQL = consultaTextArea.getText();
        cargarRegistrosTabla(tablaResultados, modeloTabla, consultaSQL);
    }

    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0);
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            ResultSet resultSet = preparedStatement.executeQuery();

            // Agregar las columnas de la tabla a la parte superior del modelo
            modelo.setColumnCount(0);
            for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
                modelo.addColumn(resultSet.getMetaData().getColumnName(i));
            }

            // Agregar los datos al modelo
            while (resultSet.next()) {
                int columnCount = resultSet.getMetaData().getColumnCount();
                Object[] fila = new Object[columnCount];

                for (int i = 1; i <= columnCount; i++) {
                    fila[i - 1] = resultSet.getObject(i);
                }

                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("Consulta Base de Datos");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(800, 600);
                frame.add(new Vistas());
                frame.setVisible(true);
            }
        });
    }
}
