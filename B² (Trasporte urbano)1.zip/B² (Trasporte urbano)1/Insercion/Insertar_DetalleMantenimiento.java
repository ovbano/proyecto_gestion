package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Insertar_DetalleMantenimiento extends JPanel {
    private JTextField costoTotalTextField;
    private JTextArea detalleTextArea;
    private JTextField idVehiculoTextField;
    private JTextField idMantenimientoTextField;
    private JButton insertarButton;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private JButton modificarButton;
    private JButton eliminarButton;

    private ResultSet resultSet;

    public Insertar_DetalleMantenimiento() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(70, 116, 166));

        JPanel panelInsercion = new JPanel(new GridBagLayout());
        panelInsercion.setBackground(new Color(70, 116, 166));

        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar");
        titledBorder.setTitleColor(Color.WHITE);
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        JLabel tituloCostoTotal = new JLabel("Costo Total");
        JLabel tituloDetalle = new JLabel("Detalle");
        JLabel tituloIdVehiculo = new JLabel("ID Vehiculo");
        JLabel tituloIdMantenimiento = new JLabel("ID Mantenimiento");

        tituloCostoTotal.setForeground(Color.WHITE);
        tituloDetalle.setForeground(Color.WHITE);
        tituloIdVehiculo.setForeground(Color.WHITE);
        tituloIdMantenimiento.setForeground(Color.WHITE);

        costoTotalTextField = new JTextField(20);
        detalleTextArea = new JTextArea(4, 20);
        idVehiculoTextField = new JTextField(20);
        idMantenimientoTextField = new JTextField(20);

        detalleTextArea.setLineWrap(true);
        detalleTextArea.setWrapStyleWord(true);

        ((AbstractDocument) detalleTextArea.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                    throws BadLocationException {
                String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
                int futureLength = currentText.length() - length + text.length();

                if (futureLength <= 255) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

        insertarButton = new JButton("Insertar");
        personalizarBoton(insertarButton);

        GridBagConstraints gbcTituloCostoTotal = new GridBagConstraints();
        gbcTituloCostoTotal.gridx = 0;
        gbcTituloCostoTotal.gridy = 0;
        gbcTituloCostoTotal.gridwidth = 2;
        gbcTituloCostoTotal.insets = new Insets(0, 0, 10, 0);
        gbcTituloCostoTotal.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloDetalle = new GridBagConstraints();
        gbcTituloDetalle.gridx = 0;
        gbcTituloDetalle.gridy = 3;
        gbcTituloDetalle.gridwidth = 2;
        gbcTituloDetalle.insets = new Insets(0, 0, 10, 0);
        gbcTituloDetalle.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloIdVehiculo = new GridBagConstraints();
        gbcTituloIdVehiculo.gridx = 0;
        gbcTituloIdVehiculo.gridy = 6;
        gbcTituloIdVehiculo.gridwidth = 2;
        gbcTituloIdVehiculo.insets = new Insets(0, 0, 10, 0);
        gbcTituloIdVehiculo.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloIdMantenimiento = new GridBagConstraints();
        gbcTituloIdMantenimiento.gridx = 0;
        gbcTituloIdMantenimiento.gridy = 9;
        gbcTituloIdMantenimiento.gridwidth = 2;
        gbcTituloIdMantenimiento.insets = new Insets(0, 0, 10, 0);
        gbcTituloIdMantenimiento.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcCostoTotal = new GridBagConstraints();
        gbcCostoTotal.gridx = 0;
        gbcCostoTotal.gridy = 2;
        gbcCostoTotal.gridwidth = 2;
        gbcCostoTotal.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcDetalle = new GridBagConstraints();
        gbcDetalle.gridx = 0;
        gbcDetalle.gridy = 5;
        gbcDetalle.gridwidth = 2;
        gbcDetalle.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcIdVehiculo = new GridBagConstraints();
        gbcIdVehiculo.gridx = 0;
        gbcIdVehiculo.gridy = 8;
        gbcIdVehiculo.gridwidth = 2;
        gbcIdVehiculo.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcIdMantenimiento = new GridBagConstraints();
        gbcIdMantenimiento.gridx = 0;
        gbcIdMantenimiento.gridy = 11;
        gbcIdMantenimiento.gridwidth = 2;
        gbcIdMantenimiento.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcInsertar = new GridBagConstraints();
        gbcInsertar.gridx = 0;
        gbcInsertar.gridy = 12;
        gbcInsertar.gridwidth = 2;

        panelInsercion.add(tituloCostoTotal, gbcTituloCostoTotal);
        panelInsercion.add(costoTotalTextField, gbcCostoTotal);
        panelInsercion.add(tituloDetalle, gbcTituloDetalle);
        panelInsercion.add(detalleTextArea, gbcDetalle);
        panelInsercion.add(tituloIdVehiculo, gbcTituloIdVehiculo);
        panelInsercion.add(idVehiculoTextField, gbcIdVehiculo);
        panelInsercion.add(tituloIdMantenimiento, gbcTituloIdMantenimiento);
        panelInsercion.add(idMantenimientoTextField, gbcIdMantenimiento);
        panelInsercion.add(insertarButton, gbcInsertar);

        modificarButton = new JButton("Modificar");
        personalizarBoton(modificarButton);

        eliminarButton = new JButton("Eliminar");
        personalizarBoton(eliminarButton);

        JPanel panelBotonesDetalle = new JPanel();
        panelBotonesDetalle.setLayout(new FlowLayout(FlowLayout.RIGHT));
        panelBotonesDetalle.add(modificarButton);
        panelBotonesDetalle.add(eliminarButton);

        JPanel panelVisualizacionDetalle = new JPanel(new BorderLayout());
        panelVisualizacionDetalle.setBackground(new Color(70, 116, 166));
        JLabel infoLabelDetalle = new JLabel("Visualización, Modificación y Eliminación");
        infoLabelDetalle.setForeground(Color.WHITE);
        infoLabelDetalle.setHorizontalAlignment(SwingConstants.CENTER);
        panelVisualizacionDetalle.add(infoLabelDetalle, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column != 0; // 0 es el índice de la columna ID_detalle
            }
        };
        modeloTabla.addColumn("ID_detalle");
        modeloTabla.addColumn("Costo_Total");
        modeloTabla.addColumn("Detalle");
        modeloTabla.addColumn("ID_vehiculo");
        modeloTabla.addColumn("ID_mantenimiento");
        tablaRegistros = new JTable(modeloTabla);
        JScrollPane scrollPaneDetalle = new JScrollPane(tablaRegistros);
        panelVisualizacionDetalle.add(scrollPaneDetalle, BorderLayout.CENTER);
        panelVisualizacionDetalle.add(panelBotonesDetalle, BorderLayout.SOUTH);

        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacionDetalle);
        splitPaneHorizontal.setResizeWeight(0.2);

        add(splitPaneHorizontal, BorderLayout.CENTER);

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String costoTotalText = costoTotalTextField.getText();
                String detalle = detalleTextArea.getText();
                String idVehiculoText = idVehiculoTextField.getText();
                String idMantenimientoText = idMantenimientoTextField.getText();

                // Validar que los campos sean válidos
                try {
                    double costoTotal = Double.parseDouble(costoTotalText);
                    int idVehiculo = Integer.parseInt(idVehiculoText);
                    int idMantenimiento = Integer.parseInt(idMantenimientoText);

                    insertarDetalleMantenimientoEnBaseDeDatos(costoTotal, detalle, idVehiculo, idMantenimiento);
                    limpiarCampos();
                    cargarRegistros();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, introduce valores válidos.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    int idDetalle = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);
                    double costoTotalSeleccionado = (double) tablaRegistros.getValueAt(filaSeleccionada, 1);
                    String detalleSeleccionado = (String) tablaRegistros.getValueAt(filaSeleccionada, 2);
                    int idVehiculoSeleccionado = (int) tablaRegistros.getValueAt(filaSeleccionada, 3);
                    int idMantenimientoSeleccionado = (int) tablaRegistros.getValueAt(filaSeleccionada, 4);

                    costoTotalTextField.setText(String.valueOf(costoTotalSeleccionado));
                    detalleTextArea.setText(detalleSeleccionado);
                    idVehiculoTextField.setText(String.valueOf(idVehiculoSeleccionado));
                    idMantenimientoTextField.setText(String.valueOf(idMantenimientoSeleccionado));

                    if (modificarRegistroEnBaseDeDatos(idDetalle, costoTotalSeleccionado, detalleSeleccionado,
                            idVehiculoSeleccionado, idMantenimientoSeleccionado)) {
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    int idDetalle = (int) tablaRegistros.getValueAt(filaSeleccionada, 0);

                    int opcion = JOptionPane.showConfirmDialog(null,
                            "¿Seguro que quieres eliminar este registro?", "Confirmar eliminación",
                            JOptionPane.YES_NO_OPTION);

                    if (opcion == JOptionPane.YES_OPTION) {
                        eliminarRegistroEnBaseDeDatos(idDetalle);
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cargarRegistros();
    }

    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private boolean modificarRegistroEnBaseDeDatos(int idDetalle, double nuevoCostoTotal, String nuevoDetalle,
            int nuevoIdVehiculo, int nuevoIdMantenimiento) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL ModificarDetalleMantenimiento(?, ?, ?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idDetalle);
            preparedStatement.setDouble(2, nuevoCostoTotal);
            preparedStatement.setString(3, nuevoDetalle);
            preparedStatement.setInt(4, nuevoIdVehiculo);
            preparedStatement.setInt(5, nuevoIdMantenimiento);
            preparedStatement.executeUpdate();
            System.out.println("Detalle de Mantenimiento modificado en la base de datos.");
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al modificar el detalle de mantenimiento en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private boolean eliminarRegistroEnBaseDeDatos(int idDetalle) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL EliminarDetalleMantenimiento(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setInt(1, idDetalle);
            preparedStatement.executeUpdate();
            System.out.println("Detalle de Mantenimiento eliminado de la base de datos con ID: " + idDetalle);
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el detalle de mantenimiento en la base de datos.");
            ex.printStackTrace();
            return false;
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void cargarRegistros() {
        cargarRegistrosTabla(tablaRegistros, modeloTabla, "SELECT * FROM DETALLE_MANTENIMIENTO");
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0);
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Object[] fila = { resultSet.getInt("ID_detalle"), resultSet.getDouble("Costo_Total"),
                        resultSet.getString("Detalle"), resultSet.getInt("ID_vehiculo"),
                        resultSet.getInt("ID_mantenimiento") };
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void insertarDetalleMantenimientoEnBaseDeDatos(double costoTotal, String detalle, int idVehiculo,
        int idMantenimiento) {
    Connection conexion = ConexionBD.obtenerConexion();
    String procedimientoAlmacenado = "{CALL InsertarDetalleMantenimiento(?, ?, ?, ?)}";
    try {
        PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
        preparedStatement.setDouble(1, costoTotal);
        preparedStatement.setString(2, detalle);
        preparedStatement.setInt(3, idVehiculo);
        preparedStatement.setInt(4, idMantenimiento);
        preparedStatement.executeUpdate();
        System.out.println("Detalle de Mantenimiento insertado en la base de datos.");
    } catch (SQLException ex) {
        System.out.println("Error al insertar el detalle de mantenimiento en la base de datos.");
        ex.printStackTrace();
    } finally {
        ConexionBD.cerrarConexion(conexion);
    }
}

    
    private void limpiarCampos() {
        costoTotalTextField.setText("");
        detalleTextArea.setText("");
        idVehiculoTextField.setText("");
        idMantenimientoTextField.setText("");
    }
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Insertar Detalle Mantenimiento Form");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setSize(800, 600);
        frame.add(new Insertar_DetalleMantenimiento());
        frame.setVisible(true);
    }
}
