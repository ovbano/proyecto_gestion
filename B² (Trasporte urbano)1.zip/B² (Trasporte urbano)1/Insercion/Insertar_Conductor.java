package Insercion;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Insertar_Conductor extends JPanel {
    private JTextField idConductorTextField;
    private JComboBox<String> tipoLicenciaComboBox;
    private JComboBox<String> idPersonaComboBox;
    private JButton insertarButton;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private JButton modificarButton;
    private JButton eliminarButton;
    private ResultSet resultSet;

    public Insertar_Conductor() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(70, 116, 166));

        JPanel panelInsercion = new JPanel(new GridBagLayout());
        panelInsercion.setBackground(new Color(70, 116, 166));

        TitledBorder titledBorder = BorderFactory.createTitledBorder("Insertar Conductor");
        titledBorder.setTitleColor(Color.WHITE);
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        panelInsercion.setBorder(titledBorder);

        JLabel tituloIdConductor = new JLabel("ID Conductor");
        JLabel tituloTipoLicencia = new JLabel("Tipo Licencia");
        JLabel tituloIdPersona = new JLabel("Nombre y Apellido");

        tituloIdConductor.setForeground(Color.WHITE);
        tituloTipoLicencia.setForeground(Color.WHITE);
        tituloIdPersona.setForeground(Color.WHITE);

        idConductorTextField = new JTextField(20);
        String[] tiposLicencia = {"A", "B", "C", "D"};
        tipoLicenciaComboBox = new JComboBox<>(tiposLicencia);
        idPersonaComboBox = new JComboBox<>();

        insertarButton = new JButton("Insertar");
        personalizarBoton(insertarButton);

        GridBagConstraints gbcTituloIdConductor = new GridBagConstraints();
        gbcTituloIdConductor.gridx = 0;
        gbcTituloIdConductor.gridy = 0;
        gbcTituloIdConductor.gridwidth = 2;
        gbcTituloIdConductor.insets = new Insets(0, 0, 10, 0);
        gbcTituloIdConductor.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloTipoLicencia = new GridBagConstraints();
        gbcTituloTipoLicencia.gridx = 0;
        gbcTituloTipoLicencia.gridy = 3;
        gbcTituloTipoLicencia.gridwidth = 2;
        gbcTituloTipoLicencia.insets = new Insets(0, 0, 10, 0);
        gbcTituloTipoLicencia.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcTituloIdPersona = new GridBagConstraints();
        gbcTituloIdPersona.gridx = 0;
        gbcTituloIdPersona.gridy = 6;
        gbcTituloIdPersona.gridwidth = 2;
        gbcTituloIdPersona.insets = new Insets(0, 0, 10, 0);
        gbcTituloIdPersona.anchor = GridBagConstraints.CENTER;

        GridBagConstraints gbcIdConductor = new GridBagConstraints();
        gbcIdConductor.gridx = 0;
        gbcIdConductor.gridy = 2;
        gbcIdConductor.gridwidth = 2;
        gbcIdConductor.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcTipoLicencia = new GridBagConstraints();
        gbcTipoLicencia.gridx = 0;
        gbcTipoLicencia.gridy = 5;
        gbcTipoLicencia.gridwidth = 2;
        gbcTipoLicencia.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcIdPersona = new GridBagConstraints();
        gbcIdPersona.gridx = 0;
        gbcIdPersona.gridy = 8;
        gbcIdPersona.gridwidth = 2;
        gbcIdPersona.insets = new Insets(0, 0, 10, 0);

        GridBagConstraints gbcInsertar = new GridBagConstraints();
        gbcInsertar.gridx = 0;
        gbcInsertar.gridy = 9;
        gbcInsertar.gridwidth = 2;

        panelInsercion.add(tituloIdConductor, gbcTituloIdConductor);
        panelInsercion.add(idConductorTextField, gbcIdConductor);
        panelInsercion.add(tituloTipoLicencia, gbcTituloTipoLicencia);
        panelInsercion.add(tipoLicenciaComboBox, gbcTipoLicencia);
        panelInsercion.add(tituloIdPersona, gbcTituloIdPersona);
        panelInsercion.add(idPersonaComboBox, gbcIdPersona);
        panelInsercion.add(insertarButton, gbcInsertar);

        modificarButton = new JButton("Modificar");
        personalizarBoton(modificarButton);

        eliminarButton = new JButton("Eliminar");
        personalizarBoton(eliminarButton);

        JPanel panelBotonesConductor = new JPanel();
        panelBotonesConductor.setLayout(new FlowLayout(FlowLayout.RIGHT));
        panelBotonesConductor.add(modificarButton);
        panelBotonesConductor.add(eliminarButton);

        JPanel panelVisualizacionConductor = new JPanel(new BorderLayout());
        panelVisualizacionConductor.setBackground(new Color(70, 116, 166));
        JLabel infoLabelConductor = new JLabel("Visualización, Modificación y Eliminación de Conductores");
        infoLabelConductor.setForeground(Color.WHITE);
        infoLabelConductor.setHorizontalAlignment(SwingConstants.CENTER);
        panelVisualizacionConductor.add(infoLabelConductor, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return true;
            }
        };
        modeloTabla.addColumn("ID_Conductor");
        modeloTabla.addColumn("Tipo_Licencia");
        modeloTabla.addColumn("ID_persona");
        tablaRegistros = new JTable(modeloTabla);
        JScrollPane scrollPaneConductor = new JScrollPane(tablaRegistros);
        panelVisualizacionConductor.add(scrollPaneConductor, BorderLayout.CENTER);
        panelVisualizacionConductor.add(panelBotonesConductor, BorderLayout.SOUTH);

        JSplitPane splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelInsercion,
                panelVisualizacionConductor);
        splitPaneHorizontal.setResizeWeight(0.2);

        add(splitPaneHorizontal, BorderLayout.CENTER);

        cargarPersonasEnComboBox();

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idConductor = idConductorTextField.getText();
                String tipoLicencia = (String) tipoLicenciaComboBox.getSelectedItem();
                String idPersonaSeleccionada = (String) idPersonaComboBox.getSelectedItem();

                // Extraer el ID de persona desde la selección
                String idPersona = idPersonaSeleccionada.split(" - ")[0];

                // Validar que los campos no estén vacíos antes de insertar
                if (!idConductor.isEmpty() && !tipoLicencia.isEmpty() && !idPersona.isEmpty()) {
                    insertarConductorEnBaseDeDatos(idConductor, tipoLicencia, idPersona);
                    limpiarCampos();
                    cargarRegistros();
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, completa todos los campos.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        modificarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    String idConductor = (String) tablaRegistros.getValueAt(filaSeleccionada, 0);
                    String tipoLicencia = (String) tablaRegistros.getValueAt(filaSeleccionada, 1);
                    String idPersonaSeleccionada = (String) tablaRegistros.getValueAt(filaSeleccionada, 2);

                    idConductorTextField.setText(idConductor);
                    tipoLicenciaComboBox.setSelectedItem(tipoLicencia);

                    // Extraer el ID de persona desde la selección
                    String idPersona = idPersonaSeleccionada.split(" - ")[0];

                    idPersonaComboBox.setSelectedItem(idPersona + " - " + obtenerNombrePersona(idPersona));

                    // Implementar la lógica para la modificación en la base de datos
                    modificarConductorEnBaseDeDatos(idConductor, tipoLicencia, idPersona);

                    // Después de modificar, limpiar campos y recargar registros
                    limpiarCampos();
                    cargarRegistros();
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para modificar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tablaRegistros.getSelectedRow();

                if (filaSeleccionada != -1) {
                    String idConductor = (String) tablaRegistros.getValueAt(filaSeleccionada, 0);

                    int opcion = JOptionPane.showConfirmDialog(null,
                            "¿Seguro que quieres eliminar este registro?", "Confirmar eliminación",
                            JOptionPane.YES_NO_OPTION);

                    if (opcion == JOptionPane.YES_OPTION) {
                        // Implementar la lógica para la eliminación en la base de datos
                        eliminarConductorEnBaseDeDatos(idConductor);

                        // Después de eliminar, limpiar campos y recargar registros
                        limpiarCampos();
                        cargarRegistros();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cargarRegistros();
    }

    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140));
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private String obtenerNombrePersona(String idPersona) {
        Connection conexion = ConexionBD.obtenerConexion();
        String nombrePersona = "";

        try {
            String consulta = "SELECT Nombre, Apellido FROM PERSONA WHERE ID_persona = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            preparedStatement.setString(1, idPersona);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                nombrePersona = resultSet.getString("Nombre") + " " + resultSet.getString("Apellido");
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener el nombre de la persona.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }

        return nombrePersona;
    }

    private void insertarConductorEnBaseDeDatos(String idConductor, String tipoLicenciaSeleccionada, String idPersonaSeleccionada) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL InsertarConductor(?, ?, ?)}";
    
        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, idConductor);
    
            // Obtener el ID de la licencia desde la base de datos
            int idLicencia = obtenerIdLicencia(tipoLicenciaSeleccionada);
            preparedStatement.setInt(2, idLicencia);
    
            preparedStatement.setString(3, idPersonaSeleccionada);
            preparedStatement.executeUpdate();
            System.out.println("Conductor insertado en la base de datos: " + idConductor);
        } catch (SQLException ex) {
            System.out.println("Error al insertar el conductor en la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }
    
    // Método para obtener el ID de la licencia desde la base de datos
    private int obtenerIdLicencia(String tipoLicencia) {
        int idLicencia = 0;
        Connection conexion = ConexionBD.obtenerConexion();
    
        try {
            String consulta = "SELECT ID_Licencia FROM TIPO_LICENCIA WHERE Tipo_Licencia = ?";
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            preparedStatement.setString(1, tipoLicencia);
            ResultSet resultSet = preparedStatement.executeQuery();
    
            if (resultSet.next()) {
                idLicencia = resultSet.getInt("ID_Licencia");
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener el ID de la licencia.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    
        return idLicencia;
    }
    
    
    

    private void modificarConductorEnBaseDeDatos(String idConductor, String tipoLicencia, String idPersona) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL ModificarConductor(?, ?, ?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, idConductor);
            preparedStatement.setString(2, tipoLicencia);
            preparedStatement.setString(3, idPersona);
            preparedStatement.executeUpdate();
            System.out.println("Conductor modificado en la base de datos: " + idConductor);
        } catch (SQLException ex) {
            System.out.println("Error al modificar el conductor en la base de datos: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void eliminarConductorEnBaseDeDatos(String idConductor) {
        Connection conexion = ConexionBD.obtenerConexion();
        String procedimientoAlmacenado = "{CALL EliminarConductor(?)}";

        try {
            PreparedStatement preparedStatement = conexion.prepareCall(procedimientoAlmacenado);
            preparedStatement.setString(1, idConductor);
            preparedStatement.executeUpdate();
            System.out.println("Conductor eliminado de la base de datos: " + idConductor);
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el conductor de la base de datos.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void cargarRegistros() {
        cargarRegistrosTabla(tablaRegistros, modeloTabla, "SELECT * FROM CONDUCTOR");
    }

    private void cargarRegistrosTabla(JTable tabla, DefaultTableModel modelo, String consulta) {
        modelo.setRowCount(0);
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Object[] fila = {resultSet.getString("ID_conductor"), resultSet.getString("ID_Licencia"),
                        resultSet.getString("ID_persona")};
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar registros en la tabla.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    private void limpiarCampos() {
        idConductorTextField.setText("");
        tipoLicenciaComboBox.setSelectedIndex(0);
        idPersonaComboBox.setSelectedIndex(0);
    }

    private void cargarPersonasEnComboBox() {
        Connection conexion = ConexionBD.obtenerConexion();

        try {
            String consulta = "SELECT ID_persona, Nombre, Apellido FROM PERSONA";
            PreparedStatement preparedStatement = conexion.prepareStatement(consulta);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String idPersona = resultSet.getString("ID_persona");
                String nombre = resultSet.getString("Nombre");
                String apellido = resultSet.getString("Apellido");
                idPersonaComboBox.addItem(idPersona + " - " + nombre + " " + apellido);
            }
        } catch (SQLException ex) {
            System.out.println("Error al cargar personas en el ComboBox.");
            ex.printStackTrace();
        } finally {
            ConexionBD.cerrarConexion(conexion);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Insertar_Conductor");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600);
            frame.setContentPane(new Insertar_Conductor());
            frame.setVisible(true);
        });
    }
}
