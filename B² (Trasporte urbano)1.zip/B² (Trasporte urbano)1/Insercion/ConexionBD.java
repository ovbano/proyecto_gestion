package Insercion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=P1_U1;user=Oswaldo_Remoto;password=Valentin1999";

    public static Connection obtenerConexion() {
        Connection conexion = null;
        try {
            // Cargar el driver JDBC
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            // Establecer la conexión a la base de datos
            conexion = DriverManager.getConnection(URL);
            System.out.println("Conexión exitosa a la base de datos.");
        } catch (ClassNotFoundException e) {
            System.out.println("Error al cargar el driver JDBC.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos.");
            e.printStackTrace();
        }
        return conexion;
    }

    public static void cerrarConexion(Connection conexion) {
        if (conexion != null) {
            try {
                conexion.close();
                //System.out.println("Conexión cerrada.");
            } catch (SQLException e) {
                //System.out.println("Error al cerrar la conexión.");
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        Connection conexion = obtenerConexion();

        // Cierra la conexión cuando hayas terminado
        cerrarConexion(conexion);
    }
}