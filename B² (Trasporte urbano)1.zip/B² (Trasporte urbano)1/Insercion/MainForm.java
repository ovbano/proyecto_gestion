package Insercion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class MainForm extends JFrame {
    private JPanel cards;
    private CardLayout cardLayout;

    private Map<String, JPanel> panelMap;  // Mapa para almacenar los paneles identificados por nombre

    public MainForm() {
        // Configurar el formulario
        setTitle("Gestión de Base de Datos");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear un panel para el menú desplegable
        JPanel menuPanel = new JPanel();
        menuPanel.setBackground(new Color(50, 92, 140));
        String[] opciones = {"TABLA...", "COLOR", "MARCA", "MODELO", "MANTENIMIENTO", "DIRECCION", "RUTA",
                "PERSONA", "CONDUCTOR", "PASAJERO", "MATRICULA", "VEHICULO", "DETALLE_MANTENIMIENTO", "PAGO"};
        JComboBox<String> tablaComboBox = new JComboBox<>(opciones);

        // Estilizar el JComboBox
        personalizarComboBox(tablaComboBox);
        JButton mostrarFormularioButton = new JButton("Mostrar Formulario");

        // Configurar el manejador de eventos para el botón
        mostrarFormularioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarFormulario((String) tablaComboBox.getSelectedItem());
            }
        });

        // Agregar componentes al panel de menú
        menuPanel.add(new JLabel("Seleccionar Tabla: "));
        menuPanel.add(tablaComboBox);
        menuPanel.add(mostrarFormularioButton);

        // Crear el panel de cartas para los formularios
        cardLayout = new CardLayout();
        cards = new JPanel(cardLayout);

        // Inicializar el mapa
        panelMap = new HashMap<>();

        // Agregar paneles de formulario a la tarjeta con identificación y color de fondo
        agregarPanel(new JPanel(), "TABLA...", Color.LIGHT_GRAY);  // Panel por defecto
        agregarPanel(new Insertar_Color(), "COLOR", Color.LIGHT_GRAY);
        agregarPanel(new Insertar_Marca(), "MARCA", Color.LIGHT_GRAY);
        agregarPanel(new Insertar_Modelo(), "MODELO", Color.LIGHT_GRAY);
        agregarPanel(new Insertar_Mantenimiento(), "MANTENIMIENTO", Color.LIGHT_GRAY);
        agregarPanel(new Insertar_Direccion(), "DIRECCION", Color.LIGHT_GRAY);
        agregarPanel(new Insertar_Ruta(), "RUTA", Color.LIGHT_GRAY);
        agregarPanel(new Insertar_Persona(), "PERSONA", Color.LIGHT_GRAY);
        agregarPanel(new Insertar_Conductor(), "CONDUCTOR", Color.LIGHT_GRAY);
        agregarPanel(new Insertar_Pasajero(), "PASAJERO", Color.LIGHT_GRAY);
        agregarPanel(new Insertar_Matricula(), "MATRICULA", Color.LIGHT_GRAY);
        agregarPanel(new Insertar_Vehiculo(), "VEHICULO", Color.LIGHT_GRAY);
        agregarPanel(new Insertar_DetalleMantenimiento(), "DETALLE_MANTENIMIENTO", Color.LIGHT_GRAY);  // Agregar lógica según sea necesario
        agregarPanel(new Insertar_Pagos(), "PAGO", Color.LIGHT_GRAY);  // Agregar lógica según sea necesario

        // Resto del código...

        // Agregar botón "Regresar"
        JButton regresarButton = new JButton("Regresar");
        regresarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                regresarANuevaInterfaz();
            }
        });
        menuPanel.add(regresarButton, BorderLayout.EAST);

        personalizarBoton(mostrarFormularioButton);
        personalizarBoton(regresarButton);

        // Configurar el diseño principal
        setLayout(new BorderLayout());
        add(menuPanel, BorderLayout.NORTH);
        add(cards, BorderLayout.CENTER);
    }

    private void agregarPanel(JPanel panel, String identificacion, Color colorFondo) {
        panelMap.put(identificacion, panel);  // Agregar al mapa
        panel.setBackground(colorFondo);  // Establecer color de fondo
        cards.add(panel, identificacion);
    }

    private void mostrarFormulario(String tabla) {
        // Cambiar al panel correspondiente en el CardLayout
        cardLayout.show(cards, tabla);
    }

    // Método para personalizar un botón
    private void personalizarBoton(JButton boton) {
        boton.setBackground(new Color(50, 92, 140)); // Color de fondo
        boton.setForeground(Color.WHITE); // Color del texto
        boton.setFocusPainted(false); // Evitar que se pinte el borde al obtener el foco
        boton.setFont(new Font("Arial", Font.BOLD, 14)); // Fuente y tamaño del texto
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16)); // Márgenes internos
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR)); // Cambiar el cursor al pasar sobre el botón
    }

    // Método para personalizar un JComboBox
    private void personalizarComboBox(JComboBox<String> comboBox) {
        comboBox.setBackground(new Color(50, 92, 140)); // Color de fondo
        comboBox.setForeground(Color.WHITE); // Color del texto
        comboBox.setFont(new Font("Arial", Font.PLAIN, 14)); // Fuente y tamaño del texto
        comboBox.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); // Márgenes internos
    }

    private void regresarANuevaInterfaz() {
        // Cierra la interfaz actual
        dispose();

        // Abre la interfaz "NuevaInterfaz"
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new NuevaInterfaz().setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MainForm().setVisible(true);
            }
        });
    }
}
