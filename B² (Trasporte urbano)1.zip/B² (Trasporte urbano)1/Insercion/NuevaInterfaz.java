package Insercion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class NuevaInterfaz extends JFrame {

    public NuevaInterfaz() {
        setTitle("Nueva Interfaz");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);
        setLocationRelativeTo(null); // Centrar en la pantalla

        // Crear un panel principal con un color de fondo
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panel.setBackground(new Color(240, 240, 240)); // Color gris claro

        // Crear botones
        JToggleButton registrosButton = new JToggleButton();
        JToggleButton informesButton = new JToggleButton();

        // Personalizar botones (opcional)
        registrosButton.setBackground(new Color(70, 130, 180)); // Azul acero
        registrosButton.setBorder(BorderFactory.createRaisedSoftBevelBorder());

        informesButton.setBackground(new Color(70, 130, 180));
        informesButton.setBorder(BorderFactory.createRaisedSoftBevelBorder());

        // Carga de iconos desde archivos o recursos
        ImageIcon registrosIcon = new ImageIcon("img/CRUD.png");
        ImageIcon informesIcon = new ImageIcon("img/VISTA.png");

        // Redimensionar imágenes
        registrosIcon = scaleImage(registrosIcon.getImage(), 120, 120);
        informesIcon = scaleImage(informesIcon.getImage(), 120, 120);

        // Establecer iconos en los botones
        registrosButton.setIcon(registrosIcon);
        informesButton.setIcon(informesIcon);

        // Crear etiquetas para el texto
        JLabel registrosLabel = new JLabel("Registros");
        JLabel informesLabel = new JLabel("Informes");

        // Personalizar etiquetas
        personalizarLabel(registrosLabel);
        personalizarLabel(informesLabel);

        // Alinear el texto al centro
        registrosLabel.setHorizontalAlignment(SwingConstants.CENTER);
        informesLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Centrar el icono y el texto en los botones
        registrosButton.setHorizontalTextPosition(SwingConstants.CENTER);
        registrosButton.setVerticalTextPosition(SwingConstants.BOTTOM);
        informesButton.setHorizontalTextPosition(SwingConstants.CENTER);
        informesButton.setVerticalTextPosition(SwingConstants.BOTTOM);

        // Agregar eventos a los botones
        registrosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica cuando se presiona el botón "Registros"
                if (registrosButton.isSelected()) {
                    abrirMainForm();
                }
            }
        });

        informesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica cuando se presiona el botón "Informes"
                if (informesButton.isSelected()) {
                    abrirVistasForm();
                }
            }
        });

        // Agregar botones y etiquetas al panel principal
        panel.add(registrosButton);
        panel.add(registrosLabel);
        panel.add(informesButton);
        panel.add(informesLabel);

        // Agregar panel principal al marco
        add(panel);
    }

    private void abrirMainForm() {
        dispose(); // Cierra la interfaz actual
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MainForm().setVisible(true);
            }
        });
    }

    private void abrirVistasForm() {
        dispose(); // Cierra la interfaz actual
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("Consulta Base de Datos");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(800, 600);
                frame.add(new Vistas());
                frame.setVisible(true);
            }
        });
    }

    // Método para redimensionar una imagen
    private ImageIcon scaleImage(Image img, int width, int height) {
        BufferedImage resizedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = resizedImage.createGraphics();
        g2d.drawImage(img, 0, 0, width, height, null);
        g2d.dispose();
        return new ImageIcon(resizedImage);
    }

    // Método para personalizar un JLabel
    private void personalizarLabel(JLabel label) {
        label.setForeground(Color.BLACK); // Color del texto
        label.setFont(new Font("Agency FB", Font.BOLD, 16)); // Fuente y tamaño del texto
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new NuevaInterfaz().setVisible(true);
            }
        });
    }
}
